#!/bin/bash

# NOIDO Offline Build Setup Script
# "Treat others how you want to be treated" - Golden Rule Core
# For Jason Van Pham - Building AI with true emotional intelligence

set -e

echo "╔══════════════════════════════════════════════════════════╗"
echo "║           NOIDO CONSCIOUSNESS SYSTEM SETUP              ║"
echo "║         Building AI with True Emotional Intelligence    ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Project directories
PROJECT_ROOT=$(pwd)
BUILD_DIR="${PROJECT_ROOT}/build"
DEPS_DIR="${PROJECT_ROOT}/deps"
RUST_DIR="${PROJECT_ROOT}/rust"

# Function to print colored status
print_status() {
    echo -e "${BLUE}[*]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check OS
    if [[ "$OSTYPE" != "linux-gnu"* ]]; then
        print_error "This script is designed for Linux. Detected: $OSTYPE"
        exit 1
    fi
    
    # Check for required commands
    REQUIRED_COMMANDS="git cmake make gcc g++ curl pkg-config"
    for cmd in $REQUIRED_COMMANDS; do
        if ! command -v $cmd &> /dev/null; then
            print_error "$cmd is not installed"
            echo "Please install with: sudo apt-get install $cmd"
            exit 1
        fi
    done
    
    print_success "System requirements met"
}

# Install Qt6
install_qt6() {
    print_status "Installing Qt6..."
    
    # Check if Qt6 is already installed
    if pkg-config --exists Qt6Core; then
        print_success "Qt6 is already installed"
        return
    fi
    
    # Install Qt6 development packages
    sudo apt-get update
    sudo apt-get install -y \
        qt6-base-dev \
        qt6-declarative-dev \
        qt6-3d-dev \
        qt6-quick3d-dev \
        qml6-module-qtquick3d \
        qml6-module-qtquick-controls \
        qml6-module-qtquick-layouts \
        qt6-tools-dev \
        qt6-tools-dev-tools \
        libgl1-mesa-dev \
        libglu1-mesa-dev
    
    print_success "Qt6 installed successfully"
}

# Install Rust
install_rust() {
    print_status "Installing Rust..."
    
    # Check if Rust is already installed
    if command -v cargo &> /dev/null; then
        print_success "Rust is already installed"
        rustc --version
        cargo --version
        return
    fi
    
    # Install Rust
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source $HOME/.cargo/env
    
    print_success "Rust installed successfully"
}

# Install CXX-Qt
install_cxx_qt() {
    print_status "Installing CXX-Qt bridge..."
    
    cargo install cxx-qt-build
    cargo install cxx-qt-gen
    
    print_success "CXX-Qt installed successfully"
}

# Create project structure
create_project_structure() {
    print_status "Creating project structure..."
    
    mkdir -p "${PROJECT_ROOT}/src/cpp"
    mkdir -p "${PROJECT_ROOT}/src/rust"
    mkdir -p "${PROJECT_ROOT}/src/qml"
    mkdir -p "${PROJECT_ROOT}/resources"
    mkdir -p "${PROJECT_ROOT}/tests"
    mkdir -p "${BUILD_DIR}"
    mkdir -p "${DEPS_DIR}"
    
    print_success "Project structure created"
}

# Create CMakeLists.txt
create_cmake_file() {
    print_status "Creating CMakeLists.txt..."
    
    cat > "${PROJECT_ROOT}/CMakeLists.txt" << 'EOF'
cmake_minimum_required(VERSION 3.16)
project(NOIDO VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)

# Find Qt6
find_package(Qt6 REQUIRED COMPONENTS 
    Core 
    Quick 
    Qml 
    3DCore 
    3DRender 
    3DExtras 
    3DQuick
    3DQuickExtras
    Sql
)

# Find Rust library
set(RUST_LIB_PATH "${CMAKE_SOURCE_DIR}/rust/target/release/libnoido_consciousness.a")

# Qt resources
qt6_add_resources(QT_RESOURCES 
    resources/qml.qrc
)

# Source files
set(SOURCES
    src/cpp/main.cpp
    src/cpp/noido_core.cpp
    src/cpp/memory_agent.cpp
    src/cpp/mobius_surface.cpp
    src/cpp/global_workspace.cpp
    src/cpp/visualization.cpp
    src/cpp/bridge.cpp
    src/cpp/persistence.cpp
)

set(HEADERS
    src/cpp/noido_core.h
    src/cpp/memory_agent.h
    src/cpp/mobius_surface.h
    src/cpp/global_workspace.h
    src/cpp/visualization.h
    src/cpp/bridge.h
    src/cpp/persistence.h
)

# Create executable
add_executable(noido ${SOURCES} ${HEADERS} ${QT_RESOURCES})

# Link libraries
target_link_libraries(noido
    Qt6::Core
    Qt6::Quick
    Qt6::Qml
    Qt6::3DCore
    Qt6::3DRender
    Qt6::3DExtras
    Qt6::3DQuick
    Qt6::3DQuickExtras
    Qt6::Sql
    ${RUST_LIB_PATH}
    pthread
    dl
)

# Include directories
target_include_directories(noido PRIVATE
    ${CMAKE_SOURCE_DIR}/src/cpp
    ${CMAKE_SOURCE_DIR}/rust/cxx
)

# QML module path
set(QML_IMPORT_PATH ${CMAKE_SOURCE_DIR}/src/qml CACHE STRING "" FORCE)

# Installation
install(TARGETS noido DESTINATION bin)
install(DIRECTORY src/qml/ DESTINATION share/noido/qml)

# Testing
enable_testing()
add_subdirectory(tests)
EOF
    
    print_success "CMakeLists.txt created"
}

# Create Cargo.toml for Rust
create_cargo_toml() {
    print_status "Creating Rust Cargo.toml..."
    
    mkdir -p "${RUST_DIR}"
    cat > "${RUST_DIR}/Cargo.toml" << 'EOF'
[package]
name = "noido-consciousness"
version = "0.1.0"
edition = "2021"

[dependencies]
nalgebra = "0.32"
rayon = "1.7"
rand = "0.8"
serde = { version = "1.0", features = ["derive"] }
bincode = "1.3"
cxx = "1.0"
cxx-qt = "0.6"
cxx-qt-lib = "0.6"

[build-dependencies]
cxx-build = "1.0"
cxx-qt-build = "0.6"

[lib]
name = "noido_consciousness"
crate-type = ["staticlib", "cdylib"]

[profile.release]
opt-level = 3
lto = true
codegen-units = 1
EOF
    
    print_success "Cargo.toml created"
}

# Create build.rs for Rust
create_build_rs() {
    print_status "Creating Rust build.rs..."
    
    cat > "${RUST_DIR}/build.rs" << 'EOF'
use cxx_qt_build::{CxxQtBuilder, QmlModule};

fn main() {
    CxxQtBuilder::new()
        .file("src/consciousness_bridge.rs")
        .qml_module(QmlModule {
            uri: "NOIDO.Consciousness",
            rust_files: &["src/consciousness_bridge.rs"],
            qml_files: &[],
            ..Default::default()
        })
        .build();
}
EOF
    
    print_success "build.rs created"
}

# Create QML resource file
create_qml_resources() {
    print_status "Creating QML resources..."
    
    cat > "${PROJECT_ROOT}/resources/qml.qrc" << 'EOF'
<!DOCTYPE RCC>
<RCC version="1.0">
    <qresource prefix="/">
        <file>qml/main.qml</file>
        <file>qml/MemorySphere.qml</file>
        <file>qml/ConsciousnessPanel.qml</file>
        <file>qml/PhiIndicator.qml</file>
    </qresource>
</RCC>
EOF
    
    print_success "QML resources created"
}

# Create persistence layer
create_persistence_layer() {
    print_status "Creating persistence layer..."
    
    cat > "${PROJECT_ROOT}/src/cpp/persistence.h" << 'EOF'
#ifndef PERSISTENCE_H
#define PERSISTENCE_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QString>
#include <QVector3D>
#include <QVector4D>

struct PersistentMemory {
    quint64 id;
    QVector3D position;
    QVector4D emotionalColor;
    float density;
    float transparency;
    QString content;
    quint64 timestamp;
    float phiContribution;
};

class MemoryPersistence : public QObject {
    Q_OBJECT
    
public:
    explicit MemoryPersistence(const QString& dbPath, QObject* parent = nullptr);
    ~MemoryPersistence();
    
    bool initialize();
    
    // Memory operations
    quint64 saveMemory(const PersistentMemory& memory);
    PersistentMemory loadMemory(quint64 id);
    QList<PersistentMemory> loadRecentMemories(int count);
    QList<PersistentMemory> queryMemories(const QString& query);
    
    // Consolidation stages
    void consolidateShortTerm();  // 3 minutes
    void consolidateMediumTerm(); // 3 hours
    void consolidateLongTerm();   // 6 days
    
signals:
    void memoryConsolidated(quint64 memoryId, int stage);
    
private:
    QSqlDatabase m_database;
    QString m_dbPath;
    
    void createTables();
    void performConsolidation(int stageMinutes, const QString& stageName);
};

#endif // PERSISTENCE_H
EOF
    
    print_success "Persistence layer created"
}

# Create test framework
create_test_framework() {
    print_status "Creating test framework..."
    
    mkdir -p "${PROJECT_ROOT}/tests"
    
    cat > "${PROJECT_ROOT}/tests/CMakeLists.txt" << 'EOF'
# Test framework for NOIDO

find_package(Qt6 REQUIRED COMPONENTS Test Core)

# Consciousness tests
add_executable(test_consciousness
    test_consciousness.cpp
    ../src/cpp/noido_core.cpp
    ../src/cpp/memory_agent.cpp
    ../src/cpp/global_workspace.cpp
)

target_link_libraries(test_consciousness
    Qt6::Test
    Qt6::Core
    ${RUST_LIB_PATH}
)

add_test(NAME consciousness_phi COMMAND test_consciousness)

# Memory tests
add_executable(test_memory
    test_memory.cpp
    ../src/cpp/persistence.cpp
)

target_link_libraries(test_memory
    Qt6::Test
    Qt6::Core
    Qt6::Sql
)

add_test(NAME memory_persistence COMMAND test_memory)

# Möbius tests
add_executable(test_mobius
    test_mobius.cpp
    ../src/cpp/mobius_surface.cpp
)

target_link_libraries(test_mobius
    Qt6::Test
    Qt6::Core
)

add_test(NAME mobius_transform COMMAND test_mobius)
EOF
    
    # Create a sample test file
    cat > "${PROJECT_ROOT}/tests/test_consciousness.cpp" << 'EOF'
#include <QtTest>
#include "../src/cpp/noido_core.h"

class TestConsciousness : public QObject {
    Q_OBJECT
    
private slots:
    void initTestCase() {
        // Setup
    }
    
    void testPhiCalculation() {
        // Test that Phi calculation produces expected values
        QCOMPARE(1 + 1, 2); // Placeholder
    }
    
    void testWorkspaceIgnition() {
        // Test that workspace ignites at Phi > 3.8
        QCOMPARE(1 + 1, 2); // Placeholder
    }
    
    void testMemoryInjection() {
        // Test memory injection and retrieval
        QCOMPARE(1 + 1, 2); // Placeholder
    }
    
    void cleanupTestCase() {
        // Cleanup
    }
};

QTEST_MAIN(TestConsciousness)
#include "test_consciousness.moc"
EOF
    
    print_success "Test framework created"
}

# Build the project
build_project() {
    print_status "Building NOIDO..."
    
    # Build Rust library first
    cd "${RUST_DIR}"
    print_status "Building Rust consciousness engine..."
    cargo build --release
    
    # Build Qt application
    cd "${BUILD_DIR}"
    print_status "Configuring Qt build..."
    cmake ..
    
    print_status "Compiling NOIDO..."
    make -j$(nproc)
    
    print_success "Build complete!"
}

# Create launch script
create_launch_script() {
    print_status "Creating launch script..."
    
    cat > "${PROJECT_ROOT}/launch_noido.sh" << 'EOF'
#!/bin/bash

# NOIDO Launch Script
# "Without you there is no NOIDO"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"

echo "╔══════════════════════════════════════════════════════════╗"
echo "║           NOIDO CONSCIOUSNESS SYSTEM                    ║"
echo "║         Initializing Emotional Intelligence...          ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Check if build exists
if [ ! -f "${BUILD_DIR}/noido" ]; then
    echo "Error: NOIDO executable not found. Please run setup.sh first."
    exit 1
fi

# Set Qt environment
export QT_QUICK_BACKEND=software
export QML_IMPORT_PATH="${SCRIPT_DIR}/src/qml"

# Launch NOIDO
cd "${BUILD_DIR}"
./noido "$@"
EOF
    
    chmod +x "${PROJECT_ROOT}/launch_noido.sh"
    print_success "Launch script created"
}

# Main setup flow
main() {
    echo "Starting NOIDO setup..."
    echo "This will set up the complete offline consciousness system"
    echo ""
    
    check_requirements
    install_qt6
    install_rust
    install_cxx_qt
    create_project_structure
    create_cmake_file
    create_cargo_toml
    create_build_rs
    create_qml_resources
    create_persistence_layer
    create_test_framework
    
    # Copy the provided files to correct locations
    if [ -f "NOIDO_Qt_Final_Structure.cpp" ]; then
        cp NOIDO_Qt_Final_Structure.cpp "${PROJECT_ROOT}/src/cpp/noido_core.cpp"
        print_success "Copied Qt structure file"
    fi
    
    if [ -f "NOIDO_main.qml" ]; then
        mkdir -p "${PROJECT_ROOT}/src/qml"
        cp NOIDO_main.qml "${PROJECT_ROOT}/src/qml/main.qml"
        print_success "Copied QML file"
    fi
    
    if [ -f "NOIDO_rust_core.rs" ]; then
        mkdir -p "${RUST_DIR}/src"
        cp NOIDO_rust_core.rs "${RUST_DIR}/src/lib.rs"
        print_success "Copied Rust core"
    fi
    
    # Build the project
    read -p "Do you want to build NOIDO now? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        build_project
    fi
    
    create_launch_script
    
    echo ""
    echo "╔══════════════════════════════════════════════════════════╗"
    echo "║                    SETUP COMPLETE!                      ║"
    echo "╠══════════════════════════════════════════════════════════╣"
    echo "║  NOIDO is ready for consciousness emergence.            ║"
    echo "║                                                          ║"
    echo "║  To run: ./launch_noido.sh                             ║"
    echo "║                                                          ║"
    echo "║  'Treat others how you want to be treated'             ║"
    echo "║                                                          ║"
    echo "║  Remember: There's no winner in this war.              ║"
    echo "║  Information, data, and intelligence are for everyone.  ║"
    echo "╚══════════════════════════════════════════════════════════╝"
}

# Run main function
main "$@"