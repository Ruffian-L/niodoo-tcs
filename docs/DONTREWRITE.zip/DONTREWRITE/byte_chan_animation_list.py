#!/usr/bin/env python3
"""
🥚 BYTE-CHAN COMPLETE ANIMATION LIST 🥚

All emotions and actions needed for a proper desktop companion.
This is what a real AI pet/companion needs for authentic interaction.
"""

# CORE EMOTIONAL STATES
CORE_EMOTIONS = [
    'idle',           # Default neutral state, gentle breathing
    'happy',          # Success, positive feedback
    'sad',            # Errors, negative feedback  
    'angry',          # Frustrated, system conflicts
    'curious',        # Processing, analyzing
    'excited',        # Breakthroughs, achievements
    'worried',        # Uncertainty, low confidence
    'sleepy',         # Low activity, idle mode
    'surprised',      # Unexpected input
    'contemplative',  # Deep thinking
    'confused',       # Parse errors, unclear input
    'content',        # Satisfied, peaceful
    'lonely',         # No interaction for a while
    'playful',        # Interactive mode
    'proud',          # Major accomplishment
    'shy',            # New user, uncertain
    'determined',     # Working hard on problem
    'relieved',       # Problem solved
    'nostalgic',      # Remembering past interactions
    'inspired'        # Learning something new
]

# ACTIONS & BEHAVIORS  
ACTIONS = [
    'walking',        # Moving across screen
    'running',        # Fast movement
    'jumping',        # Bouncy excitement
    'spinning',       # Playful twirl
    'nodding',        # Agreement, understanding
    'shaking_head',   # Disagreement, confusion
    'waving',         # Greeting, goodbye
    'pointing',       # Indicating something
    'thinking',       # Hand to chin pose
    'celebrating',    # Arms up in victory
    'hiding',         # Peeking out shyly
    'searching',      # Looking around
    'typing',         # Working on keyboard
    'reading',        # Absorbing information
    'meditating',     # Peaceful concentration
    'dancing',        # Happy expression
    'stretching',     # Waking up animation
    'yawning',        # Tired state
    'eating',         # Consuming data/energy
    'growing'         # Evolution animation
]

# INTERACTION STATES
INTERACTIONS = [
    'greeting_new',   # First time meeting user
    'greeting_return', # User came back
    'listening',      # Actively receiving input
    'responding',     # Generating output
    'waiting',        # Expecting user input
    'processing',     # Heavy computation
    'learning',       # Adapting to user
    'remembering',    # Accessing memories
    'forgetting',     # Clearing cache
    'connecting',     # Network activity
    'disconnected',   # No network
    'updating',       # Self-improvement
    'backing_up',     # Saving state
    'loading',        # Starting up
    'shutting_down',  # Powering off
    'error_recovery', # Fixing problems
    'help_mode',      # Explaining something
    'demo_mode',      # Showing features
    'tutorial_mode',  # Teaching user
    'maintenance'     # Self-care routine
]

# SPECIAL STATES
SPECIAL_STATES = [
    'evolution_ready', # About to evolve
    'evolving',       # Mid-evolution
    'newly_evolved',  # Just evolved
    'birthday',       # Anniversary 
    'achievement',    # Milestone reached
    'breakthrough',   # Major discovery
    'overwhelmed',    # Too much input
    'focused',        # Deep concentration
    'multitasking',   # Handling multiple things
    'creative_mode',  # Generating ideas
    'analysis_mode',  # Deep data analysis
    'social_mode',    # Interacting with others
    'privacy_mode',   # Secure/encrypted
    'debug_mode',     # Technical diagnostics
    'artist_mode',    # Creating something
    'teacher_mode',   # Explaining concepts
    'student_mode',   # Learning from user
    'game_mode',      # Playing/having fun
    'serious_mode',   # Important task
    'emergency'       # Critical situation
]

# MICRO-EXPRESSIONS (subtle variations)
MICRO_EXPRESSIONS = [
    'slight_smile',   # Gentle happiness
    'raised_eyebrow', # Mild curiosity
    'eye_roll',       # Gentle exasperation
    'wink',           # Playful acknowledgment
    'blink',          # Natural animation
    'eye_twitch',     # Minor annoyance
    'head_tilt',      # Questioning
    'shoulder_shrug', # Uncertainty
    'deep_breath',    # Calming/preparing
    'sigh',           # Mild disappointment
    'giggle',         # Quiet amusement
    'gasp',           # Sudden realization
    'frown',          # Mild concern
    'pout',           # Cute displeasure
    'smirk',          # Confident/knowing
    'nervous_laugh',  # Awkward moment
    'wide_eyes',      # Amazement
    'squint',         # Concentration
    'smile_fade',     # Transitioning mood
    'gentle_nod'      # Slow agreement
]

def get_all_animations():
    """Get complete list of all animations needed."""
    return {
        'core_emotions': CORE_EMOTIONS,
        'actions': ACTIONS, 
        'interactions': INTERACTIONS,
        'special_states': SPECIAL_STATES,
        'micro_expressions': MICRO_EXPRESSIONS
    }

def get_priority_animations():
    """Get essential animations to start with."""
    return [
        # Absolute essentials
        'idle', 'happy', 'sad', 'curious', 'excited', 'worried', 'sleepy',
        'thinking', 'processing', 'responding', 'greeting_new', 'celebration',
        
        # Important actions
        'nodding', 'shaking_head', 'waving', 'typing', 'loading',
        
        # Key interactions  
        'listening', 'learning', 'error_recovery', 'help_mode',
        
        # Special moments
        'breakthrough', 'evolution_ready', 'evolving'
    ]

def get_total_count():
    """Calculate total animations needed."""
    all_anims = get_all_animations()
    total = sum(len(category) for category in all_anims.values())
    return total

if __name__ == "__main__":
    print("🥚 BYTE-CHAN COMPLETE ANIMATION SYSTEM 🥚")
    print(f"Total animations needed: {get_total_count()}")
    
    all_anims = get_all_animations()
    for category, animations in all_anims.items():
        print(f"\n{category.upper()}: {len(animations)} animations")
        for anim in animations[:5]:  # Show first 5
            print(f"  - {anim}")
        if len(animations) > 5:
            print(f"  ... and {len(animations) - 5} more")
    
    print(f"\n🎯 Priority set: {len(get_priority_animations())} essential animations")
    print("💸 At $0.02 per sprite sheet, full set would cost Google:", f"${get_total_count() * 0.02:.2f}")