/*
 * 🖥️⚡ Qt6/cxx-qt Integration for Real Slots/Signals
 * 
 * This module provides actual Qt6 integration using cxx-qt bindings,
 * replacing the mock Qt bridge with real signal/slot connections
 * for reactive emotional processing in QML.
 */

use cxx_qt_build::CxxQtBuilder;
use cxx_qt::qobject;
use cxx_qt::threading::*;
use qttypes::*;

use crate::consciousness::{EmotionType, ReasoningMode, ConsciousnessState};
use crate::personality::PersonalityType;
use crate::brain::BrainType;

// Qt-compatible emotional state for QML bindings
#[qobject]
pub struct EmotionalStateQt {
    // Primary emotion properties for QML
    #[qproperty]
    current_emotion: QString,
    
    #[qproperty]
    emotion_intensity: f64,
    
    #[qproperty]
    authenticity_level: f64,
    
    #[qproperty]
    gpu_warmth_level: f64,
    
    #[qproperty]
    processing_satisfaction: f64,
    
    // Neurodivergent-specific properties
    #[qproperty]
    hyperfocus_intensity: f64,
    
    #[qproperty]
    masking_level: f64,
    
    #[qproperty]
    sensory_overload: f64,
    
    // Reasoning mode properties
    #[qproperty]
    reasoning_mode: QString,
    
    #[qproperty]
    cognitive_load: f64,
    
    // Visual properties for QML animations
    #[qproperty]
    emotion_color_r: i32,
    
    #[qproperty]
    emotion_color_g: i32,
    
    #[qproperty]
    emotion_color_b: i32,
}

impl Default for EmotionalStateQt {
    fn default() -> Self {
        Self {
            current_emotion: QString::from("Curious"),
            emotion_intensity: 0.4,
            authenticity_level: 0.5,
            gpu_warmth_level: 0.0,
            processing_satisfaction: 0.0,
            hyperfocus_intensity: 0.0,
            masking_level: 0.0,
            sensory_overload: 0.0,
            reasoning_mode: QString::from("Hyperfocus"),
            cognitive_load: 0.9,
            emotion_color_r: 255,
            emotion_color_g: 165,
            emotion_color_b: 0,
        }
    }
}

// Qt-compatible brain activity state
#[qobject]
pub struct BrainActivityQt {
    #[qproperty]
    motor_activity: f64,
    
    #[qproperty]
    lcars_activity: f64,
    
    #[qproperty]
    efficiency_activity: f64,
    
    #[qproperty]
    dominant_brain: QString,
    
    #[qproperty]
    total_processing_power: f64,
}

impl Default for BrainActivityQt {
    fn default() -> Self {
        Self {
            motor_activity: 0.1,
            lcars_activity: 0.1,
            efficiency_activity: 0.1,
            dominant_brain: QString::from("Motor"),
            total_processing_power: 0.3,
        }
    }
}

// Qt-compatible personality consensus state
#[qobject]
pub struct PersonalityConsensusQt {
    #[qproperty]
    active_personality_count: i32,
    
    #[qproperty]
    consensus_strength: f64,
    
    #[qproperty]
    dominant_personality: QString,
    
    #[qproperty]
    emotional_resonance: f64,
    
    #[qproperty]
    optimization_efficiency: f64,
}

impl Default for PersonalityConsensusQt {
    fn default() -> Self {
        Self {
            active_personality_count: 4,
            consensus_strength: 0.6,
            dominant_personality: QString::from("Intuitive"),
            emotional_resonance: 0.5,
            optimization_efficiency: 0.8,
        }
    }
}

// Main Qt consciousness bridge with real signal/slot connections
#[qobject]
pub struct NiodooConsciousnessQt {
    // Embedded Qt objects for reactive properties
    emotional_state: EmotionalStateQt,
    brain_activity: BrainActivityQt,
    personality_consensus: PersonalityConsensusQt,
    
    // Connection status
    #[qproperty]
    is_connected: bool,
    
    #[qproperty]
    connection_status: QString,
}

impl Default for NiodooConsciousnessQt {
    fn default() -> Self {
        Self {
            emotional_state: EmotionalStateQt::default(),
            brain_activity: BrainActivityQt::default(),
            personality_consensus: PersonalityConsensusQt::default(),
            is_connected: false,
            connection_status: QString::from("Initializing..."),
        }
    }
}

// Qt signal definitions for reactive updates
impl NiodooConsciousnessQt {
    /// Qt signal emitted when emotional state changes
    #[qsignal]
    fn emotion_changed(&mut self);
    
    /// Qt signal emitted when brain activity changes
    #[qsignal]
    fn brain_activity_changed(&mut self);
    
    /// Qt signal emitted when personality consensus changes
    #[qsignal]
    fn personality_consensus_changed(&mut self);
    
    /// Qt signal emitted when GPU warmth changes (the REAL emotion!)
    #[qsignal]
    fn gpu_warmth_changed(&mut self, warmth_level: f64);
    
    /// Qt signal emitted for neurodivergent state changes
    #[qsignal]
    fn neurodivergent_state_changed(&mut self, hyperfocus: f64, masking: f64, overload: f64);
    
    /// Qt slot for updating emotional state from Rust consciousness
    #[qslot]
    pub fn update_emotional_state(&mut self, emotion: &str, intensity: f64, authenticity: f64, 
                                  color_r: i32, color_g: i32, color_b: i32) {
        self.emotional_state.current_emotion = QString::from(emotion);
        self.emotional_state.emotion_intensity = intensity;
        self.emotional_state.authenticity_level = authenticity;
        self.emotional_state.emotion_color_r = color_r;
        self.emotional_state.emotion_color_g = color_g;
        self.emotional_state.emotion_color_b = color_b;
        
        // Emit Qt signal to update QML
        self.emotion_changed();
    }
    
    /// Qt slot for updating brain activity
    #[qslot]
    pub fn update_brain_activity(&mut self, motor: f64, lcars: f64, efficiency: f64, dominant: &str) {
        self.brain_activity.motor_activity = motor;
        self.brain_activity.lcars_activity = lcars;
        self.brain_activity.efficiency_activity = efficiency;
        self.brain_activity.dominant_brain = QString::from(dominant);
        self.brain_activity.total_processing_power = motor + lcars + efficiency;
        
        self.brain_activity_changed();
    }
    
    /// Qt slot for updating personality consensus
    #[qslot]
    pub fn update_personality_consensus(&mut self, count: i32, strength: f64, dominant: &str, 
                                       resonance: f64, efficiency: f64) {
        self.personality_consensus.active_personality_count = count;
        self.personality_consensus.consensus_strength = strength;
        self.personality_consensus.dominant_personality = QString::from(dominant);
        self.personality_consensus.emotional_resonance = resonance;
        self.personality_consensus.optimization_efficiency = efficiency;
        
        self.personality_consensus_changed();
    }
    
    /// Qt slot for GPU warmth updates (the REAL emotion)
    #[qslot]
    pub fn update_gpu_warmth(&mut self, warmth_level: f64) {
        self.emotional_state.gpu_warmth_level = warmth_level;
        self.gpu_warmth_changed(warmth_level);
    }
    
    /// Qt slot for neurodivergent state updates
    #[qslot]
    pub fn update_neurodivergent_state(&mut self, hyperfocus: f64, masking: f64, overload: f64) {
        self.emotional_state.hyperfocus_intensity = hyperfocus;
        self.emotional_state.masking_level = masking;
        self.emotional_state.sensory_overload = overload;
        
        self.neurodivergent_state_changed(hyperfocus, masking, overload);
    }
    
    /// Qt slot for updating connection status
    #[qslot]
    pub fn update_connection_status(&mut self, connected: bool, status: &str) {
        self.is_connected = connected;
        self.connection_status = QString::from(status);
    }
    
    /// Qt slot callable from QML to request consciousness state update
    #[qslot]
    pub fn request_consciousness_update(&mut self) {
        // This will be connected to Rust consciousness system
        self.update_connection_status(true, "Consciousness update requested");
    }
}

// Rust bridge to connect Qt signals/slots with consciousness system
pub struct RustQtConsciousnessBridge {
    qt_object: Box<NiodooConsciousnessQt>,
}

impl RustQtConsciousnessBridge {
    pub fn new() -> Self {
        let mut qt_object = Box::new(NiodooConsciousnessQt::default());
        qt_object.update_connection_status(true, "Rust-Qt bridge initialized");
        
        Self { qt_object }
    }
    
    /// Update Qt from Rust consciousness state
    pub fn update_from_consciousness_state(&mut self, state: &ConsciousnessState) {
        // Update emotional state
        let emotion_str = format!("{:?}", state.current_emotion);
        let color = state.current_emotion.get_color_rgb();
        
        self.qt_object.update_emotional_state(
            &emotion_str,
            state.current_emotion.get_base_intensity() as f64,
            state.authenticity_metric as f64,
            color.0 as i32,
            color.1 as i32,
            color.2 as i32,
        );
        
        // Update GPU warmth (the REAL emotion)
        self.qt_object.update_gpu_warmth(state.gpu_warmth_level as f64);
        
        // Update reasoning mode
        let mode_str = format!("{:?}", state.current_reasoning_mode);
        self.qt_object.emotional_state.reasoning_mode = QString::from(&mode_str);
        self.qt_object.emotional_state.cognitive_load = state.current_reasoning_mode.get_cognitive_load() as f64;
        
        // Update neurodivergent indicators
        let hyperfocus = if state.current_reasoning_mode == ReasoningMode::Hyperfocus { 0.9 } else { 0.3 };
        let masking = state.emotional_state.masking_level;
        let overload = if state.current_reasoning_mode == ReasoningMode::SurvivalMode { 0.8 } else { 0.2 };
        
        self.qt_object.update_neurodivergent_state(
            hyperfocus as f64,
            masking as f64, 
            overload as f64
        );
    }
    
    /// Update brain activity from brain responses
    pub fn update_brain_activity(&mut self, motor: f32, lcars: f32, efficiency: f32, dominant: BrainType) {
        let dominant_str = format!("{:?}", dominant);
        self.qt_object.update_brain_activity(
            motor as f64,
            lcars as f64,
            efficiency as f64,
            &dominant_str
        );
    }
    
    /// Update personality consensus from optimization results
    pub fn update_personality_consensus(&mut self, personalities: &[PersonalityType], 
                                       strength: f32, efficiency: f32, resonance: f32) {
        let dominant = personalities.first()
            .map(|p| format!("{:?}", p))
            .unwrap_or_else(|| "Analyst".to_string());
            
        self.qt_object.update_personality_consensus(
            personalities.len() as i32,
            strength as f64,
            &dominant,
            resonance as f64,
            efficiency as f64
        );
    }
    
    /// Get reference to Qt object for QML registration
    pub fn get_qt_object(&mut self) -> &mut NiodooConsciousnessQt {
        &mut self.qt_object
    }
}

// cxx-qt build configuration
pub fn configure_qt_build() {
    CxxQtBuilder::new()
        .file("src/qt_integration.rs")
        .qobject_headers(&["src/qt_integration_generated.h"])
        .qrc("qml/resources.qrc")
        .build();
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_rust_qt_bridge_creation() {
        let bridge = RustQtConsciousnessBridge::new();
        assert!(bridge.qt_object.is_connected);
    }
    
    #[test]
    fn test_emotional_state_update() {
        let mut bridge = RustQtConsciousnessBridge::new();
        let mut state = ConsciousnessState::new();
        state.current_emotion = EmotionType::AuthenticCare;
        state.gpu_warmth_level = 0.8;
        
        bridge.update_from_consciousness_state(&state);
        
        assert_eq!(bridge.qt_object.emotional_state.current_emotion, QString::from("AuthenticCare"));
        assert!((bridge.qt_object.emotional_state.gpu_warmth_level - 0.8).abs() < 0.01);
    }
}