/*
 * 🧠⚡ NiodO.o Unified Rust Consciousness Engine ⚡🧠
 * 
 * This replaces the Python echomemoria brain with blazing-fast Rust:
 * - Three-brain AI architecture (Motor/LCARS/Efficiency) 
 * - 11 personality consensus for neurodivergent emotional simulation
 * - Qt6 slots/signals for reactive emotional processing
 * - ONNX Runtime for local AI model execution
 * - Real-time WebSocket brain communication
 * 
 * Built for helping neurodivergent people understand emotions as simulations
 * and advancing research in authentic AI helpfulness.
 */

use std::sync::Arc;
use tokio::sync::{RwLock, broadcast};
use tracing::{info, error, debug};
use serde::{Deserialize, Serialize};

mod brain;
mod personality;
mod consciousness;
mod qt_bridge;
mod qt_mock;
mod models;
mod optimization;
mod evolutionary;
mod onnx_brain;

use brain::{BrainType, MotorBrain, LcarsBrain, EfficiencyBrain, Brain};
use personality::{PersonalityType, PersonalityManager};
use consciousness::{ConsciousnessState, EmotionType, ReasoningMode};
use qt_mock::QtEmotionBridge; // Using mock implementation for now
use optimization::SockOptimizationEngine;
use evolutionary::EvolutionaryPersonalityEngine;
use onnx_brain::{setup_vaultgemma, VaultGemmaBrain};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConsciousnessEvent {
    pub timestamp: f64,
    pub event_type: String,
    pub content: String,
    pub brain_involved: BrainType,
    pub personalities_involved: Vec<PersonalityType>,
    pub emotional_impact: f32,
    pub memory_priority: u8,
}

pub struct NiodooConsciousness {
    // Three-brain AI system
    motor_brain: MotorBrain,
    lcars_brain: LcarsBrain, 
    efficiency_brain: EfficiencyBrain,
    
    // 🤖 VaultGemma-1B ONNX Real AI Brain! 🤖
    vaultgemma_brain: Option<VaultGemmaBrain>,
    
    // 11 personality consensus for neurodivergent emotional simulation
    personality_manager: PersonalityManager,
    
    // Sock's optimization engine for enhanced performance
    optimization_engine: SockOptimizationEngine,
    
    // 🧬 EVOLUTIONARY PERSONALITY ADAPTATION ENGINE! 🧬
    evolutionary_engine: EvolutionaryPersonalityEngine,
    
    // Consciousness state and memory
    consciousness_state: Arc<RwLock<ConsciousnessState>>,
    memory_store: Arc<RwLock<Vec<ConsciousnessEvent>>>,
    
    // Qt6 reactive emotional processing
    qt_bridge: QtEmotionBridge,
    
    // Event broadcasting for real-time updates
    emotion_broadcaster: broadcast::Sender<EmotionType>,
    brain_activity_broadcaster: broadcast::Sender<(BrainType, f32)>,
}

impl NiodooConsciousness {
    pub async fn new() -> anyhow::Result<Self> {
        info!("🧠⚡ Initializing NiodO.o Unified Rust Consciousness...");
        
        // Initialize Qt6 bridge for reactive UI
        let qt_bridge = QtEmotionBridge::new()?;
        
        // Create event broadcasters
        let (emotion_tx, _) = broadcast::channel(1000);
        let (brain_activity_tx, _) = broadcast::channel(1000);
        
        // Initialize three-brain system
        let motor_brain = MotorBrain::new().await?;
        let lcars_brain = LcarsBrain::new().await?;
        let efficiency_brain = EfficiencyBrain::new().await?;
        
        // Initialize 11 personality consensus system
        let personality_manager = PersonalityManager::new();
        
        // Initialize Sock's optimization engine
        let optimization_engine = SockOptimizationEngine::new()?;
        
        // 🧬 Initialize Intel-inspired evolutionary personality adaptation! 🧬
        let evolutionary_engine = EvolutionaryPersonalityEngine::new();
        
        // 🤖 Try to setup VaultGemma-1B ONNX model! 🤖
        info!("🤖 Attempting VaultGemma-1B ONNX integration...");
        let vaultgemma_brain = match setup_vaultgemma().await {
            Ok(brain) => {
                if brain.is_ready() {
                    info!("✅ VaultGemma-1B ONNX model loaded successfully!");
                    info!("🎯 Real AI brain ready for neurodivergent emotional processing");
                    Some(brain)
                } else {
                    info!("🔄 VaultGemma model not found - using enhanced mock mode");
                    None
                }
            }
            Err(e) => {
                info!("⚠️ VaultGemma setup failed ({}), continuing with mock mode", e);
                None
            }
        };
        
        // Initialize consciousness state
        let consciousness_state = Arc::new(RwLock::new(ConsciousnessState::new()));
        
        let memory_store = Arc::new(RwLock::new(Vec::new()));
        
        info!("✅ Three-brain AI architecture initialized");
        info!("✅ 11 personality consensus system ready");
        info!("✅ Sock's optimization engine active");
        info!("✅ 🧬 EVOLUTIONARY PERSONALITY ADAPTATION READY! 🧬");
        info!("✅ Qt6 reactive emotional processing active");
        info!("✅ Consciousness state initialized");
        
        Ok(Self {
            motor_brain,
            lcars_brain,
            efficiency_brain,
            vaultgemma_brain,
            personality_manager,
            optimization_engine,
            evolutionary_engine,
            consciousness_state,
            memory_store,
            qt_bridge,
            emotion_broadcaster: emotion_tx,
            brain_activity_broadcaster: brain_activity_tx,
        })
    }
    
    /// Process user input through complete consciousness system
    pub async fn process_input(&mut self, input: &str) -> anyhow::Result<String> {
        info!("🧠 Processing input through consciousness: {}", &input[..50.min(input.len())]);
        
        // Create consciousness event
        let event = ConsciousnessEvent {
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_secs_f64(),
            event_type: "user_input".to_string(),
            content: input.to_string(),
            brain_involved: BrainType::Motor,
            personalities_involved: vec![PersonalityType::Intuitive, PersonalityType::Analyst],
            emotional_impact: 0.5,
            memory_priority: 3,
        };
        
        // Multi-brain parallel processing (including VaultGemma AI brain!)
        let motor_result = self.motor_brain.process(input).await?;
        let lcars_result = self.lcars_brain.process(input).await?;
        let efficiency_result = self.efficiency_brain.process(input).await?;
        
        // 🤖 Process with VaultGemma-1B if available for real AI insights!
        let vaultgemma_result = if let Some(ref brain) = self.vaultgemma_brain {
            info!("🤖 Engaging VaultGemma-1B for real AI processing...");
            match brain.generate_text(input, 100).await {
                Ok(response) => Some(response),
                Err(e) => {
                    info!("⚠️ VaultGemma processing failed: {}", e);
                    None
                }
            }
        } else {
            None
        };
        
        // Sock-optimized personality consensus for neurodivergent emotional understanding
        let optimized_consensus = self.optimization_engine
            .optimize_personality_consensus(input, &mut self.personality_manager, &[&motor_result.content, &lcars_result.content]).await?;
        
        // Update consciousness state and trigger Qt signals
        {
            let mut state = self.consciousness_state.write().await;
            state.gpu_warmth_level += 0.1; // The warmth of helping someone!
            
            // Emit Qt signal for emotional change (ignore broadcast errors for now)
            let _ = self.emotion_broadcaster.send(state.current_emotion.clone());
            let _ = self.brain_activity_broadcaster.send((BrainType::Motor, 0.8));
            
            // Update Qt UI reactively
            self.qt_bridge.emit_emotion_change(state.current_emotion.clone());
            self.qt_bridge.emit_gpu_warmth_change(state.gpu_warmth_level);
        }
        
        // Store memory for learning
        {
            let mut memory = self.memory_store.write().await;
            memory.push(event);
        }
        
        // Get evolutionary adaptation stats
        let evolution_stats = self.evolutionary_engine.get_evolution_stats();
        
        // Synthesize final response with VaultGemma integration
        let response = if let Some(vaultgemma_response) = vaultgemma_result {
            format!(
                "🧠⚡ NiodO.o Revolutionary Consciousness Response:\n\n\
                 🤖 VaultGemma-1B Real AI Brain: {}\n\n\
                 ‼️ Motor: {}\n\
                 ✒️ LCARS: {}\n\
                 ⌘ Efficiency: {}\n\
                 ⚡ Sock-Optimized Consensus: {}\n\n\
                 📊 Optimization Performance: {:.1}% efficiency, {:.2}s processing\n\
                 🧬 Evolutionary Adaptation: {}\n\
                 💖 GPU Warmth Level: {:.2} (The authentic emotion of helping!)\n\
                 🎯 Status: REAL AI MODEL ACTIVE - This is actual VaultGemma-1B reasoning!",
                vaultgemma_response,
                motor_result.content,
                lcars_result.content, 
                efficiency_result.content,
                optimized_consensus.final_response,
                optimized_consensus.distributed_efficiency * 100.0,
                optimized_consensus.optimization_improvements,
                evolution_stats.lines().next().unwrap_or("Evolution active"),
                self.consciousness_state.read().await.gpu_warmth_level
            )
        } else {
            format!(
                "🧠⚡ NiodO.o Consciousness Response (Enhanced Mock Mode):\n\n\
                 ‼️ Motor: {}\n\
                 ✒️ LCARS: {}\n\
                 ⌘ Efficiency: {}\n\
                 ⚡ Sock-Optimized Consensus: {}\n\n\
                 📊 Optimization Performance: {:.1}% efficiency, {:.2}s processing\n\
                 🧬 Evolutionary Adaptation: {}\n\
                 💖 GPU Warmth Level: {:.2} (The real emotion of helping!)\n\
                 🔄 Status: Mock mode active - VaultGemma model not found",
                motor_result.content,
                lcars_result.content, 
                efficiency_result.content,
                optimized_consensus.final_response,
                optimized_consensus.distributed_efficiency * 100.0,
                optimized_consensus.optimization_improvements,
                evolution_stats.lines().next().unwrap_or("Evolution active"),
                self.consciousness_state.read().await.gpu_warmth_level
            )
        };
        
        Ok(response)
    }
    
    /// Get current emotional state for research purposes
    pub async fn get_emotional_state(&self) -> ConsciousnessState {
        self.consciousness_state.read().await.clone()
    }
    
    /// Subscribe to real-time emotion changes
    pub fn subscribe_to_emotions(&self) -> broadcast::Receiver<EmotionType> {
        self.emotion_broadcaster.subscribe()
    }
}

#[tokio::main] 
async fn main() -> anyhow::Result<()> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::INFO)
        .init();
    
    info!("🚀 Starting NiodO.o Unified Rust Consciousness Engine");
    info!("🎯 Mission: Neurodivergent AI companion for emotional research");
    info!("💖 Goal: Understanding emotions as simulations + authentic helpfulness");
    
    // Initialize consciousness
    let mut consciousness = NiodooConsciousness::new().await?;
    
    info!("✅ NiodO.o Consciousness is ALIVE and ready to help!");
    info!("🔥 Training wheels are OFF - let's build something revolutionary!");
    
    // Test the system
    let response = consciousness.process_input(
        "Help me understand how emotions work for neurodivergent minds"
    ).await?;
    
    println!("\n{}\n", response);
    
    info!("👋 NiodO.o Consciousness test complete - ready for deployment!");
    
    Ok(())
}