#!/usr/bin/env python3
"""
🔍 ONNX MODEL INSPECTOR

Inspect the VaultGemma ONNX model to get EXACT input/output specifications
for FULL WOOD implementation.
"""

import onnx
import onnxruntime as ort
from pathlib import Path
import json

def inspect_model():
    """Inspect the ONNX model to get exact specifications."""
    model_path = Path("/home/ruffian/projects/xNiodioo/rust-consciousness/models/vaultgemma-1b/onnx/model_q4.onnx")

    print(f"🔍 Inspecting ONNX model: {model_path}")

    # Load ONNX model
    model = onnx.load(str(model_path))

    # Create ONNX Runtime session to get runtime info
    session = ort.InferenceSession(str(model_path), providers=['CPUExecutionProvider'])

    print(f"\n📊 MODEL INFORMATION:")
    print(f"Producer: {model.producer_name}")
    print(f"Version: {model.producer_version}")
    print(f"Domain: {model.domain}")

    print(f"\n📥 INPUT SPECIFICATIONS:")
    print(f"Total inputs: {len(session.get_inputs())}")

    for i, input_info in enumerate(session.get_inputs()):
        shape = input_info.shape
        dtype = input_info.type
        print(f"  {i:2d}. {input_info.name}")
        print(f"      Shape: {shape}")
        print(f"      Type: {dtype}")

        # Special analysis for KV cache
        if 'past_key_values' in input_info.name:
            if '.key' in input_info.name or '.value' in input_info.name:
                layer_num = input_info.name.split('.')[1]
                cache_type = input_info.name.split('.')[-1]
                print(f"      *** KV Cache - Layer {layer_num}, {cache_type.upper()} ***")

    print(f"\n📤 OUTPUT SPECIFICATIONS:")
    print(f"Total outputs: {len(session.get_outputs())}")

    for i, output_info in enumerate(session.get_outputs()):
        shape = output_info.shape
        dtype = output_info.type
        print(f"  {i:2d}. {output_info.name}")
        print(f"      Shape: {shape}")
        print(f"      Type: {dtype}")

    # Extract key dimensions for implementation
    print(f"\n🔧 KEY DIMENSIONS FOR IMPLEMENTATION:")

    # Find input_ids to get seq_len dimension
    input_ids_info = next((inp for inp in session.get_inputs() if inp.name == 'input_ids'), None)
    if input_ids_info:
        print(f"Input IDs shape: {input_ids_info.shape}")

    # Find first KV cache to get dimensions
    first_kv = next((inp for inp in session.get_inputs() if 'past_key_values.0.key' in inp.name), None)
    if first_kv:
        kv_shape = first_kv.shape
        print(f"KV Cache shape: {kv_shape}")
        print(f"  Batch size: {kv_shape[0]}")
        print(f"  Num heads: {kv_shape[1]}")
        print(f"  Seq len: {kv_shape[2]}")
        print(f"  Head dim: {kv_shape[3]}")

    # Count layers
    kv_layers = set()
    for inp in session.get_inputs():
        if 'past_key_values' in inp.name:
            parts = inp.name.split('.')
            if len(parts) >= 2:
                kv_layers.add(int(parts[1]))

    print(f"Number of transformer layers: {len(kv_layers)}")

    # Generate Python code template
    print(f"\n🐍 PYTHON IMPLEMENTATION TEMPLATE:")
    if first_kv:
        batch_size = kv_shape[0] if isinstance(kv_shape[0], int) else 1
        num_heads = kv_shape[1] if isinstance(kv_shape[1], int) else 'num_heads'
        head_dim = kv_shape[3] if isinstance(kv_shape[3], int) else 'head_dim'

        print(f"self.num_layers = {len(kv_layers)}")
        print(f"self.num_heads = {num_heads}")
        print(f"self.head_dim = {head_dim}")
        print(f"# KV cache shape: (batch_size, {num_heads}, seq_len, {head_dim})")

        print(f"\n# Empty KV cache creation:")
        print(f"key_cache = np.zeros((batch_size, {num_heads}, 0, {head_dim}), dtype=np.float32)")
        print(f"value_cache = np.zeros((batch_size, {num_heads}, 0, {head_dim}), dtype=np.float32)")

if __name__ == "__main__":
    inspect_model()