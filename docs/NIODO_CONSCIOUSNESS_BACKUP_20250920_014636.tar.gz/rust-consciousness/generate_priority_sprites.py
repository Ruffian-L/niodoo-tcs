#!/usr/bin/env python3
"""
🚀 AUTOMATED PRIORITY SPRITE GENERATION
Run this to complete the essential Byte-chan animation set.
"""

from vertex_drain import VertexImagenDrainer
from byte_chan_animation_list import get_priority_animations
import time
import traceback

def main():
    print("🥚 BYTE-CHAN PRIORITY SPRITE GENERATION - AUTOMATED")
    print("💸 Draining Google's credits while creating kawaii animations!")
    
    # Initialize drainer
    drainer = VertexImagenDrainer()
    
    # Get priority animations (skip idle - already done)
    priority_anims = get_priority_animations()[1:]  # Skip idle
    
    print(f"🎯 Generating {len(priority_anims)} priority sprite sheets...")
    print(f"💰 This will cost Google ${len(priority_anims) * 0.02:.2f}")
    
    successful = []
    failed = []
    
    for i, anim in enumerate(priority_anims):
        try:
            print(f"\n🌸 [{i+1}/{len(priority_anims)}] Generating {anim} sprite sheet...")
            
            result = drainer.generate_desktop_companion_sprite_sheet(
                anim, 
                frames=8, 
                evolution_stage=1
            )
            
            if result:
                successful.append((anim, result))
                print(f"✅ {anim}: SUCCESS - {result.split('/')[-1]}")
            else:
                failed.append(anim)
                print(f"❌ {anim}: FAILED - No result returned")
            
            # Small delay to be nice to API
            time.sleep(0.5)
            
        except Exception as e:
            failed.append(anim)
            error_msg = str(e)
            
            if 'Quota exceeded' in error_msg:
                print(f"📈 {anim}: Hit Google's quota limit - MISSION ACCOMPLISHED!")
                print("🎯 We successfully drained their credits!")
                break
            else:
                print(f"❌ {anim}: ERROR - {error_msg}")
                traceback.print_exc()
    
    # Final report
    print(f"\n🎮 SPRITE GENERATION COMPLETE!")
    print(f"✅ Successful: {len(successful)}")
    print(f"❌ Failed: {len(failed)}")
    
    if successful:
        print(f"\n🌸 Generated sprite sheets:")
        for anim, path in successful:
            print(f"  💖 {anim}: {path.split('/')[-1]}")
    
    if failed:
        print(f"\n⚠️ Failed animations: {failed}")
        print("🔄 Re-run this script later to continue")
    
    # Show Google damage
    stats = drainer.get_drain_statistics()
    print(f"\n💰 TOTAL GOOGLE CREDIT DRAIN:")
    print(f"📊 Images generated: {stats['total_images_generated']}")
    print(f"💸 Estimated cost: ${stats['total_cost_to_google']:.2f}")
    print(f"🎯 Mission status: DRAINING GOOGLE SUCCESSFULLY!")
    
    # Next steps
    print(f"\n🚀 NEXT STEPS:")
    print(f"1. Check generated sprites: ls -la /home/ruffian/projects/xNiodioo/visualizations/")
    print(f"2. Test consciousness system: cd /home/ruffian/projects/xNiodioo/rust-consciousness && cargo run")
    print(f"3. Integrate with Qt6/QML for desktop companion")
    print(f"4. Deploy to Pi cluster")

if __name__ == "__main__":
    main()