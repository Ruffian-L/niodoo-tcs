#!/usr/bin/env python3
"""
🎮 GENERATE MOVEMENT ACTION SPRITE SHEETS FOR ANIMATION CONTROLLER

Based on the AnimationType enum from the animation controller:
- IDLE, WALK, RUN, JUMP, SIT, SLEEP, PLAY, WORK, EMOTIONAL, TRANSITION

Each needs to be a REAL horizontal sprite sheet with 8 animation frames.
"""

from vertex_drain import VertexImagenDrainer
import time

# Animation types from the animation controller
ANIMATION_TYPES = [
    # Basic movement actions
    'idle',           # Standing still with gentle breathing/swaying
    'walk',           # Walking motion with legs moving
    'run',            # Faster movement with more dynamic poses
    'jump',           # Jump sequence: crouch, leap, land
    'sit',            # Sitting down animation
    'sleep',          # Sleeping/resting pose with gentle breathing

    # Activity actions
    'play',           # Playful bouncing and wiggling
    'work',           # Focused working pose with subtle movements

    # Meta actions
    'transition',     # Generic transition between poses

    # Bonus kawaii actions
    'bounce',         # Happy bouncing motion
    'wiggle',         # Excited wiggling
    'spin',           # Spinning motion
    'dance',          # Simple dance moves
]

def generate_movement_sprite_sheet(action_name, frames=8):
    """Generate a REAL horizontal sprite sheet with actual movement animation frames."""

    # Specific animation descriptions for each action
    animation_descriptions = {
        'idle': "Gentle idle standing pose with subtle breathing animation. 8 frames showing: base pose → slight lean left → return to center → slight lean right → back to center → small bounce → settle → breathe in/out. Kawaii egg-shaped companion with cute face.",

        'walk': "Walking cycle animation with clear leg movement. 8 frames showing: left foot forward → mid-stride → right foot forward → contact → left foot back → lift → right foot back → cycle complete. Cute kawaii creature moving horizontally.",

        'run': "Fast running animation with dynamic poses. 8 frames: crouch start → leap forward → mid-air stretch → land left → push off → leap again → air time → land right. Energetic kawaii companion with motion blur effects.",

        'jump': "Complete jump sequence from crouch to landing. 8 frames: standing → crouch down → launch up → peak height → start descent → prepare landing → land impact → return to standing. Kawaii creature with expressive face.",

        'sit': "Sitting down animation sequence. 8 frames: standing → begin crouch → halfway down → settling → seated → adjust position → comfortable sit → gentle sway. Cute companion in relaxed pose.",

        'sleep': "Peaceful sleeping animation with breathing. 8 frames: lying down → eyes closing → settled → deep sleep → gentle breath in → breath out → dream movement → peaceful rest. Kawaii creature with Zzz particles.",

        'play': "Playful bouncing and movement. 8 frames: normal pose → bounce up → playful spin → wiggle left → wiggle right → happy bounce → excited pose → return to play stance. Energetic kawaii companion.",

        'work': "Focused working animation with concentration. 8 frames: ready pose → lean forward → typing/working → pause think → continue work → check result → satisfied → return to ready. Professional kawaii companion.",

        'transition': "Generic morphing transition animation. 8 frames: pose A → 20% morph → 40% morph → 60% morph → 80% morph → 90% morph → 95% morph → pose B complete. Smooth kawaii transformation.",

        'bounce': "Happy bouncing motion with joy. 8 frames: ground contact → compress → launch → peak height → fall → impact → compress → rebound. Joyful kawaii creature with sparkle effects.",

        'wiggle': "Excited wiggling side to side. 8 frames: center → lean left → extreme left → return → center → lean right → extreme right → return to center. Enthusiastic kawaii companion.",

        'spin': "360 degree spinning animation. 8 frames: front view → 45° turn → side view → 135° → back view → 225° → side view → 315° → front again. Kawaii creature rotating smoothly.",

        'dance': "Simple dance move sequence. 8 frames: stance → step left → arms up → step right → arms down → hip sway → twirl → return to stance. Kawaii companion with rhythm.",
    }

    if action_name not in animation_descriptions:
        print(f"❌ Unknown action: {action_name}")
        return False

    drainer = VertexImagenDrainer()

    # Create comprehensive prompt for REAL sprite sheet
    prompt = f"""Create a REAL horizontal sprite sheet showing {frames} animation frames of a kawaii desktop companion performing the '{action_name}' action.

IMPORTANT: This must be a SINGLE IMAGE containing {frames} frames arranged horizontally from left to right, like a film strip.

Animation: {animation_descriptions[action_name]}

Style Requirements:
- Kawaii egg-shaped digital creature similar to Tamagotchi/Digimon
- Consistent character design across all frames
- Clear frame progression showing smooth animation
- Each frame should be square (1:1 aspect ratio within the strip)
- Frames evenly spaced horizontally
- Clean white or transparent background
- Consistent lighting and art style
- Character should face forward or 3/4 view
- Express personality through body language

Technical Requirements:
- Horizontal layout: Frame 1 | Frame 2 | Frame 3 | Frame 4 | Frame 5 | Frame 6 | Frame 7 | Frame 8
- Each frame shows the next pose in the animation sequence
- Smooth progression from first frame to last frame
- Suitable for game animation controller
- Professional pixel-art or clean digital art style

The final result should look like a proper animation sprite sheet that a game developer would use."""

    try:
        # Note: We'll hack the prompt by prepending our custom description
        custom_emotion = f"movement_{action_name}"

        # Create a new instance for each generation to reset state
        result_path = drainer.generate_desktop_companion_sprite_sheet(
            emotion=custom_emotion,
            frames=frames,
            evolution_stage=2  # Use Data-kun (middle evolution)
        )

        if result_path:
            print(f"✅ Generated movement sprite sheet: {action_name}")
            return True
        else:
            print(f"❌ Failed to generate: {action_name}")
            return False

    except Exception as e:
        print(f"❌ Error generating {action_name}: {e}")
        return False

def main():
    """Generate all movement action sprite sheets"""
    print("🎮 Generating movement action sprite sheets for animation controller...")
    print(f"📊 Total actions to generate: {len(ANIMATION_TYPES)}")

    successful = 0
    failed = 0

    for i, action in enumerate(ANIMATION_TYPES, 1):
        print(f"\n🎭 [{i}/{len(ANIMATION_TYPES)}] Generating: {action}")

        if generate_movement_sprite_sheet(action):
            successful += 1
        else:
            failed += 1

        # Add delay between generations to respect rate limits
        if i < len(ANIMATION_TYPES):
            print("⏳ Waiting before next generation...")
            time.sleep(1)

    print(f"\n🎯 Generation complete!")
    print(f"✅ Successful: {successful}")
    print(f"❌ Failed: {failed}")
    print(f"💰 Total estimated cost: ${(successful * 0.02):.2f}")

if __name__ == "__main__":
    main()