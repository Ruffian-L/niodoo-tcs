#!/usr/bin/env python3
"""
🎮 SPRITE SHEET FORMAT VALIDATION AND TESTING

Tests generated sprite sheets to ensure they meet our animation controller requirements:
- Proper horizontal layout
- Consistent frame dimensions
- 8 frames per animation
- Suitable for game animation
"""

import os
import sys
from PIL import Image
import numpy as np
from pathlib import Path

def analyze_sprite_sheet(image_path: str) -> dict:
    """Analyze a sprite sheet and return format information."""
    try:
        with Image.open(image_path) as img:
            width, height = img.size

            # Assume 8 frames horizontally
            expected_frames = 8
            frame_width = width // expected_frames
            frame_height = height

            # Check if dimensions make sense for 8 frames
            is_valid_format = (width % expected_frames == 0) and (frame_width > 0)

            # Calculate aspect ratio
            aspect_ratio = width / height if height > 0 else 0

            # Check if it's roughly horizontal strip format
            is_horizontal_strip = aspect_ratio > 2.0  # Should be much wider than tall

            return {
                'file_name': os.path.basename(image_path),
                'total_width': width,
                'total_height': height,
                'frame_width': frame_width,
                'frame_height': frame_height,
                'expected_frames': expected_frames,
                'aspect_ratio': aspect_ratio,
                'is_valid_format': is_valid_format,
                'is_horizontal_strip': is_horizontal_strip,
                'file_size_kb': os.path.getsize(image_path) // 1024,
                'mode': img.mode,
                'has_transparency': img.mode in ('RGBA', 'LA') or 'transparency' in img.info
            }
    except Exception as e:
        return {
            'file_name': os.path.basename(image_path),
            'error': str(e),
            'is_valid_format': False
        }

def extract_frames_preview(image_path: str, output_dir: str = "frame_previews"):
    """Extract individual frames from sprite sheet for visual verification."""
    try:
        os.makedirs(output_dir, exist_ok=True)

        with Image.open(image_path) as img:
            width, height = img.size
            frames = 8
            frame_width = width // frames

            base_name = os.path.splitext(os.path.basename(image_path))[0]

            for i in range(frames):
                left = i * frame_width
                right = left + frame_width

                frame = img.crop((left, 0, right, height))
                frame_path = os.path.join(output_dir, f"{base_name}_frame_{i+1}.png")
                frame.save(frame_path)

            print(f"✅ Extracted {frames} frames from {os.path.basename(image_path)}")
            return True

    except Exception as e:
        print(f"❌ Failed to extract frames from {os.path.basename(image_path)}: {e}")
        return False

def test_animation_controller_compatibility():
    """Test compatibility with our animation controller expectations."""

    # Expected sprite sheet specifications for our animation controller
    requirements = {
        'min_frame_width': 32,
        'max_frame_width': 128,
        'min_frame_height': 32,
        'max_frame_height': 128,
        'expected_frames': 8,
        'required_transparency': True,
        'max_file_size_kb': 2048  # 2MB max
    }

    return requirements

def generate_animation_controller_config(sprite_analysis: list):
    """Generate configuration for the animation controller based on analyzed sprites."""

    config = {
        'sprite_sheets': {},
        'animation_sequences': {}
    }

    for analysis in sprite_analysis:
        if not analysis.get('is_valid_format', False):
            continue

        sprite_name = analysis['file_name'].replace('real_sprite_', '').replace('.png', '')
        action_name = sprite_name.replace('movement_', '')

        # Add sprite sheet info
        config['sprite_sheets'][sprite_name] = {
            'file_path': f"visualizations/{analysis['file_name']}",
            'frame_width': analysis['frame_width'],
            'frame_height': analysis['frame_height'],
            'frame_count': analysis['expected_frames'],
            'has_transparency': analysis['has_transparency']
        }

        # Add animation sequence config
        config['animation_sequences'][action_name] = {
            'sprite_sheet': sprite_name,
            'frame_count': analysis['expected_frames'],
            'frame_duration': 0.1,  # 100ms per frame
            'loop': True,
            'animation_type': action_name.upper()
        }

    return config

def main():
    """Main testing function."""
    print("🎮 Testing sprite sheet format compatibility...")

    # Find all generated sprite sheets
    visualization_dir = "/home/ruffian/projects/xNiodioo/visualizations"

    # Test emotion sprites
    emotion_sprites = list(Path(visualization_dir).glob("real_sprite_*_2025*.png"))
    emotion_sprites = [str(p) for p in emotion_sprites if "movement" not in str(p)]

    # Test movement sprites
    movement_sprites = list(Path(visualization_dir).glob("real_sprite_movement_*.png"))
    movement_sprites = [str(p) for p in movement_sprites]

    all_sprites = emotion_sprites + movement_sprites

    print(f"📊 Found {len(emotion_sprites)} emotion sprites and {len(movement_sprites)} movement sprites")
    print(f"🧪 Total sprites to analyze: {len(all_sprites)}")

    # Analyze all sprites
    results = []
    valid_count = 0

    print("\n" + "="*80)
    print("SPRITE SHEET ANALYSIS RESULTS")
    print("="*80)

    for sprite_path in all_sprites:
        analysis = analyze_sprite_sheet(sprite_path)
        results.append(analysis)

        if analysis.get('is_valid_format', False):
            valid_count += 1
            status = "✅ VALID"
        else:
            status = "❌ INVALID"

        print(f"\n{status} - {analysis['file_name']}")
        if 'error' in analysis:
            print(f"  Error: {analysis['error']}")
        else:
            print(f"  Dimensions: {analysis['total_width']}x{analysis['total_height']}")
            print(f"  Frame size: {analysis['frame_width']}x{analysis['frame_height']}")
            print(f"  Aspect ratio: {analysis['aspect_ratio']:.2f}")
            print(f"  File size: {analysis['file_size_kb']}KB")
            print(f"  Mode: {analysis['mode']}")
            print(f"  Transparency: {analysis['has_transparency']}")

    print(f"\n📈 SUMMARY: {valid_count}/{len(all_sprites)} sprites have valid format")

    # Test animation controller compatibility
    requirements = test_animation_controller_compatibility()
    print(f"\n🎯 Animation Controller Requirements:")
    for key, value in requirements.items():
        print(f"  {key}: {value}")

    # Extract frame previews for visual verification
    if valid_count > 0:
        print(f"\n🖼️ Extracting frame previews for visual verification...")
        preview_count = 0
        for sprite_path in all_sprites[:3]:  # Test first 3 sprites
            if extract_frames_preview(sprite_path):
                preview_count += 1
        print(f"✅ Extracted frames from {preview_count} sprite sheets")

    # Generate animation controller config
    config = generate_animation_controller_config(results)

    # Save config for the animation controller
    config_path = "/home/ruffian/projects/xNiodioo/rust-consciousness/sprite_config.json"
    import json
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    print(f"\n⚙️ Generated animation controller config: {config_path}")
    print(f"📦 Config includes {len(config['sprite_sheets'])} sprite sheets")
    print(f"🎬 Config includes {len(config['animation_sequences'])} animation sequences")

    # Final recommendations
    print(f"\n💡 RECOMMENDATIONS:")
    if valid_count == len(all_sprites):
        print("✅ All sprite sheets are properly formatted!")
        print("✅ Ready for animation controller integration")
    else:
        invalid_count = len(all_sprites) - valid_count
        print(f"⚠️ {invalid_count} sprite sheets need format fixes")
        print("🔧 Consider regenerating invalid sprites with correct dimensions")

    return valid_count, len(all_sprites)

if __name__ == "__main__":
    main()