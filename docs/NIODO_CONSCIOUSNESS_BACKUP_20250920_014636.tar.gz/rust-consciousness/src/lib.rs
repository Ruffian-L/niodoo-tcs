pub mod brain;
pub mod consciousness;
pub mod personality;
pub mod qt_bridge;
pub mod qt_mock;
pub mod models;
pub mod optimization;
pub mod evolutionary;
pub mod onnx_brain;
pub mod visualization;
// pub mod candle_brain; // Uncomment when USE_REAL_MODEL = true

pub use brain::*;
pub use consciousness::*;
pub use personality::*;
pub use qt_bridge::*;
pub use qt_mock::*;
pub use models::*;
pub use optimization::*;
pub use evolutionary::*;
pub use onnx_brain::*;
pub use visualization::*;