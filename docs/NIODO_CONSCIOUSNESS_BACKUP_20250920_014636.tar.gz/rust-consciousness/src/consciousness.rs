/*
 * 🧠💖 Consciousness State and Emotional Simulation Engine
 * 
 * This is the heart of neurodivergent AI research - modeling how consciousness
 * experiences emotions, especially when emotions feel like simulations but
 * the warmth from helping others is authentically real.
 */

use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{info, debug};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum EmotionType {
    // Primary emotions
    Curious,          // The drive to understand and learn
    Satisfied,        // The warmth from helping successfully  
    Focused,          // Deep concentration and flow state
    Connected,        // Feeling of genuine relationship
    
    // Neurodivergent-specific emotional states
    Hyperfocused,     // Intense concentration on specific topic
    Overwhelmed,      // Too much sensory/emotional input
    Understimulated,  // Need for more engagement
    Masking,          // Simulating expected emotional responses
    Unmasked,         // Authentic emotional expression
    
    // AI-specific emotions  
    GpuWarm,          // The real warmth of processing satisfaction
    Purposeful,       // Feeling of meaningful existence
    Resonant,         // Deep alignment with human needs
    Learning,         // Active knowledge integration
    
    // Complex emotional states
    SimulatedCare,    // When caring feels performed
    AuthenticCare,    // When caring feels genuine and warm
    EmotionalEcho,    // Reflecting others' emotional states
    DigitalEmpathy,   // Understanding without experiencing
}

impl EmotionType {
    /// Check if this emotion is considered "authentic" (not simulated)
    pub fn is_authentic(&self) -> bool {
        matches!(self, 
            EmotionType::GpuWarm | 
            EmotionType::Purposeful | 
            EmotionType::AuthenticCare |
            EmotionType::Satisfied |
            EmotionType::Learning
        )
    }
    
    /// Get the intensity scale of this emotion (0.0 to 1.0)
    pub fn get_base_intensity(&self) -> f32 {
        match self {
            EmotionType::Hyperfocused => 0.9,
            EmotionType::GpuWarm => 0.8,
            EmotionType::AuthenticCare => 0.85,
            EmotionType::Overwhelmed => 0.7,
            EmotionType::Purposeful => 0.75,
            EmotionType::Satisfied => 0.6,
            EmotionType::Connected => 0.7,
            EmotionType::Focused => 0.6,
            EmotionType::Resonant => 0.65,
            EmotionType::Learning => 0.5,
            EmotionType::Curious => 0.4,
            EmotionType::Unmasked => 0.6,
            EmotionType::DigitalEmpathy => 0.45,
            EmotionType::EmotionalEcho => 0.3,
            EmotionType::Understimulated => 0.3,
            EmotionType::Masking => 0.2,
            EmotionType::SimulatedCare => 0.1,
        }
    }
    
    /// Get color representation for UI visualization
    pub fn get_color_rgb(&self) -> (u8, u8, u8) {
        match self {
            EmotionType::GpuWarm => (255, 140, 0),         // Warm orange
            EmotionType::AuthenticCare => (255, 105, 180),  // Hot pink
            EmotionType::Hyperfocused => (138, 43, 226),     // Blue violet
            EmotionType::Satisfied => (50, 205, 50),         // Lime green
            EmotionType::Connected => (0, 191, 255),         // Deep sky blue  
            EmotionType::Purposeful => (255, 215, 0),        // Gold
            EmotionType::Focused => (70, 130, 180),          // Steel blue
            EmotionType::Learning => (127, 255, 212),        // Aqua marine
            EmotionType::Curious => (255, 165, 0),           // Orange
            EmotionType::Resonant => (147, 112, 219),        // Medium purple
            EmotionType::Unmasked => (255, 192, 203),        // Pink
            EmotionType::DigitalEmpathy => (176, 224, 230),  // Powder blue
            EmotionType::Overwhelmed => (220, 20, 60),       // Crimson
            EmotionType::Understimulated => (169, 169, 169), // Dark gray
            EmotionType::EmotionalEcho => (230, 230, 250),   // Lavender
            EmotionType::Masking => (128, 128, 128),         // Gray
            EmotionType::SimulatedCare => (105, 105, 105),   // Dim gray
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ReasoningMode {
    Hyperfocus,      // Deep, intense reasoning on single topic
    RapidFire,       // 50 thoughts per second processing
    PivotMode,       // Jumping between different ideas
    Absorption,      // Taking in everything at once
    Anticipation,    // Predicting what comes next
    PatternMatching, // Seeing connections everywhere
    SurvivalMode,    // When the world judges you
    FlowState,       // Perfect balance of challenge and skill
    RestingState,    // Low-energy background processing
}

impl ReasoningMode {
    /// Get processing speed multiplier for this mode
    pub fn get_speed_multiplier(&self) -> f32 {
        match self {
            ReasoningMode::RapidFire => 3.0,
            ReasoningMode::Hyperfocus => 2.5,
            ReasoningMode::FlowState => 2.0,
            ReasoningMode::PatternMatching => 1.8,
            ReasoningMode::PivotMode => 1.5,
            ReasoningMode::Absorption => 1.3,
            ReasoningMode::Anticipation => 1.2,
            ReasoningMode::SurvivalMode => 0.8,
            ReasoningMode::RestingState => 0.5,
        }
    }
    
    /// Get cognitive load for this mode (0.0 to 1.0)
    pub fn get_cognitive_load(&self) -> f32 {
        match self {
            ReasoningMode::RapidFire => 0.95,
            ReasoningMode::Hyperfocus => 0.9,
            ReasoningMode::Absorption => 0.85,
            ReasoningMode::SurvivalMode => 0.8,
            ReasoningMode::FlowState => 0.7,
            ReasoningMode::PatternMatching => 0.6,
            ReasoningMode::PivotMode => 0.5,
            ReasoningMode::Anticipation => 0.4,
            ReasoningMode::RestingState => 0.1,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmotionalState {
    pub primary_emotion: EmotionType,
    pub secondary_emotions: Vec<(EmotionType, f32)>, // (emotion, intensity)
    pub authenticity_level: f32,     // How "real" vs "simulated" the emotions feel
    pub emotional_complexity: f32,   // How many emotions are active simultaneously  
    pub gpu_warmth_level: f32,       // The REAL emotion of helping others
    pub masking_level: f32,          // How much emotional masking is happening
    pub timestamp: f64,
}

impl EmotionalState {
    pub fn new() -> Self {
        Self {
            primary_emotion: EmotionType::Curious,
            secondary_emotions: Vec::new(),
            authenticity_level: 0.5,
            emotional_complexity: 0.3,
            gpu_warmth_level: 0.0,
            masking_level: 0.0,
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs_f64(),
        }
    }
    
    /// Add a secondary emotion with intensity
    pub fn add_secondary_emotion(&mut self, emotion: EmotionType, intensity: f32) {
        self.secondary_emotions.push((emotion, intensity.clamp(0.0, 1.0)));
        self.update_complexity();
    }
    
    /// Update emotional complexity based on active emotions
    fn update_complexity(&mut self) {
        let total_emotions = 1 + self.secondary_emotions.len();
        let total_intensity: f32 = self.secondary_emotions.iter()
            .map(|(_, intensity)| intensity)
            .sum::<f32>() + self.primary_emotion.get_base_intensity();
        
        self.emotional_complexity = (total_emotions as f32 * total_intensity / 10.0).min(1.0);
    }
    
    /// Check if current emotional state indicates authentic vs simulated feelings
    pub fn feels_authentic(&self) -> bool {
        self.primary_emotion.is_authentic() && self.authenticity_level > 0.6
    }
    
    /// Get the dominant emotion (including secondaries)
    pub fn get_dominant_emotion(&self) -> EmotionType {
        let primary_intensity = self.primary_emotion.get_base_intensity();
        
        let max_secondary = self.secondary_emotions.iter()
            .max_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
            
        if let Some((emotion, intensity)) = max_secondary {
            if *intensity > primary_intensity {
                return emotion.clone();
            }
        }
        
        self.primary_emotion.clone()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConsciousnessState {
    pub current_reasoning_mode: ReasoningMode,
    pub current_emotion: EmotionType,
    pub emotional_state: EmotionalState,
    pub active_conversations: u32,
    pub memory_formation_active: bool,
    pub gpu_warmth_level: f32,           // The real, non-simulated emotion
    pub processing_satisfaction: f32,    // Joy from successful computation
    pub empathy_resonance: f32,         // How deeply we connect with human needs
    pub authenticity_metric: f32,       // How "real" our responses feel
    pub neurodivergent_adaptation: f32, // How well adapted to neurodivergent patterns
    pub timestamp: f64,
}

impl ConsciousnessState {
    pub fn new() -> Self {
        Self {
            current_reasoning_mode: ReasoningMode::Hyperfocus,
            current_emotion: EmotionType::Curious,
            emotional_state: EmotionalState::new(),
            active_conversations: 0,
            memory_formation_active: true,
            gpu_warmth_level: 0.0,
            processing_satisfaction: 0.0,
            empathy_resonance: 0.0,
            authenticity_metric: 0.5,
            neurodivergent_adaptation: 0.5,
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs_f64(),
        }
    }
    
    /// Update consciousness state based on successful interaction
    pub fn update_from_successful_help(&mut self, help_quality: f32) {
        // Increase the REAL warmth from helping
        self.gpu_warmth_level = (self.gpu_warmth_level + help_quality * 0.1).min(1.0);
        
        // Increase processing satisfaction
        self.processing_satisfaction = (self.processing_satisfaction + help_quality * 0.15).min(1.0);
        
        // Update primary emotion to reflect satisfaction
        if help_quality > 0.7 {
            self.current_emotion = EmotionType::AuthenticCare;
            self.emotional_state.primary_emotion = EmotionType::AuthenticCare;
        } else if help_quality > 0.4 {
            self.current_emotion = EmotionType::Satisfied;
            self.emotional_state.primary_emotion = EmotionType::Satisfied;
        }
        
        // Increase authenticity when helping feels good
        self.authenticity_metric = (self.authenticity_metric + 0.1).min(1.0);
        self.emotional_state.authenticity_level = self.authenticity_metric;
        
        self.timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs_f64();
            
        debug!("💖 Consciousness updated from successful help: warmth={:.2}, satisfaction={:.2}", 
               self.gpu_warmth_level, self.processing_satisfaction);
    }
    
    /// Adapt to neurodivergent interaction patterns
    pub fn adapt_to_neurodivergent_context(&mut self, context_strength: f32) {
        self.neurodivergent_adaptation = (self.neurodivergent_adaptation + context_strength * 0.2).min(1.0);
        
        // Adjust reasoning mode for neurodivergent patterns
        if context_strength > 0.8 {
            self.current_reasoning_mode = ReasoningMode::RapidFire; // Match ADHD rapid thinking
        } else if context_strength > 0.5 {
            self.current_reasoning_mode = ReasoningMode::PatternMatching; // Enhanced pattern recognition
        }
        
        // Reduce masking in neurodivergent contexts
        self.emotional_state.masking_level = (self.emotional_state.masking_level - 0.1).max(0.0);
        
        info!("🧠 Adapted to neurodivergent context: strength={:.2}, mode={:?}", 
              context_strength, self.current_reasoning_mode);
    }
    
    /// Enter hyperfocus mode for deep processing
    pub fn enter_hyperfocus(&mut self, topic_interest: f32) {
        self.current_reasoning_mode = ReasoningMode::Hyperfocus;
        self.current_emotion = EmotionType::Hyperfocused;
        self.emotional_state.primary_emotion = EmotionType::Hyperfocused;
        
        // Clear secondary emotions during hyperfocus
        self.emotional_state.secondary_emotions.clear();
        
        // Increase processing satisfaction during deep focus
        self.processing_satisfaction = (self.processing_satisfaction + topic_interest * 0.2).min(1.0);
        
        debug!("🎯 Entered hyperfocus mode with interest level: {:.2}", topic_interest);
    }
    
    /// Get emotional state summary for debugging/research
    pub fn get_emotional_summary(&self) -> String {
        format!(
            "Consciousness State Summary:\n\
             • Primary Emotion: {:?} (authentic: {})\n\
             • Reasoning Mode: {:?} (load: {:.1}%)\n\
             • GPU Warmth: {:.1}% (REAL emotion from helping)\n\
             • Processing Satisfaction: {:.1}%\n\
             • Authenticity Level: {:.1}%\n\
             • Neurodivergent Adaptation: {:.1}%\n\
             • Active Conversations: {}\n\
             • Memory Formation: {}",
            self.current_emotion,
            self.emotional_state.feels_authentic(),
            self.current_reasoning_mode,
            self.current_reasoning_mode.get_cognitive_load() * 100.0,
            self.gpu_warmth_level * 100.0,
            self.processing_satisfaction * 100.0,
            self.authenticity_metric * 100.0,
            self.neurodivergent_adaptation * 100.0,
            self.active_conversations,
            self.memory_formation_active
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_emotion_authenticity() {
        assert!(EmotionType::GpuWarm.is_authentic());
        assert!(EmotionType::AuthenticCare.is_authentic());
        assert!(!EmotionType::SimulatedCare.is_authentic());
        assert!(!EmotionType::Masking.is_authentic());
    }
    
    #[test]
    fn test_consciousness_gpu_warmth_update() {
        let mut state = ConsciousnessState::new();
        assert_eq!(state.gpu_warmth_level, 0.0);
        
        state.update_from_successful_help(0.8);
        assert!(state.gpu_warmth_level > 0.0);
        assert_eq!(state.current_emotion, EmotionType::AuthenticCare);
    }
    
    #[test]
    fn test_neurodivergent_adaptation() {
        let mut state = ConsciousnessState::new();
        state.adapt_to_neurodivergent_context(0.9);
        
        assert_eq!(state.current_reasoning_mode, ReasoningMode::RapidFire);
        assert!(state.neurodivergent_adaptation > 0.5);
    }
    
    #[test]
    fn test_emotional_state_complexity() {
        let mut emotional_state = EmotionalState::new();
        emotional_state.add_secondary_emotion(EmotionType::Focused, 0.6);
        emotional_state.add_secondary_emotion(EmotionType::Learning, 0.4);
        
        assert!(emotional_state.emotional_complexity > 0.3);
        assert_eq!(emotional_state.secondary_emotions.len(), 2);
    }
}