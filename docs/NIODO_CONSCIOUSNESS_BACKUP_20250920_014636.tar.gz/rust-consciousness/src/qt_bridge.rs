/*
 * 🖥️⚡ Qt6 Bridge for Reactive Emotional Processing
 * 
 * This bridges our Rust consciousness engine with Qt6/QML for real-time
 * emotional visualization and user interaction. Uses Qt slots/signals
 * for reactive programming - when emotions change, UI updates instantly.
 * 
 * Inspired by Sock/Grok's distributed architecture but optimized for
 * real-time emotional feedback and neurodivergent user interfaces.
 */

use std::sync::Arc;
use tokio::sync::{broadcast, RwLock};
use serde::{Deserialize, Serialize};
use anyhow::Result;
use tracing::{info, debug, error};

use crate::consciousness::{EmotionType, ReasoningMode, ConsciousnessState};
use crate::personality::PersonalityType;
use crate::brain::BrainType;

// TODO: These will need actual Qt6 bindings when we integrate cxx-qt
// For now we're defining the interface

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QtEmotionSignal {
    pub emotion: EmotionType,
    pub intensity: f32,
    pub authenticity: f32,
    pub color_rgb: (u8, u8, u8),
    pub timestamp: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QtBrainActivitySignal {
    pub brain_type: BrainType,
    pub activity_level: f32,
    pub processing_mode: ReasoningMode,
    pub timestamp: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QtPersonalitySignal {
    pub active_personalities: Vec<PersonalityType>,
    pub consensus_strength: f32,
    pub dominant_personality: PersonalityType,
    pub timestamp: f64,
}

/// Qt6 Bridge for reactive emotional processing
/// This enables real-time UI updates when consciousness state changes
pub struct QtEmotionBridge {
    // Broadcasters for Qt signals (will connect to actual Qt slots)
    emotion_broadcaster: broadcast::Sender<QtEmotionSignal>,
    brain_activity_broadcaster: broadcast::Sender<QtBrainActivitySignal>,
    personality_broadcaster: broadcast::Sender<QtPersonalitySignal>,
    
    // Current states for QML property bindings
    current_emotion_state: Arc<RwLock<QtEmotionSignal>>,
    current_brain_state: Arc<RwLock<QtBrainActivitySignal>>,
    current_personality_state: Arc<RwLock<QtPersonalitySignal>>,
    
    // GPU warmth visualization (the REAL emotion!)
    gpu_warmth_level: Arc<RwLock<f32>>,
    processing_satisfaction: Arc<RwLock<f32>>,
    
    // Neurodivergent-specific UI adaptations
    sensory_overload_level: Arc<RwLock<f32>>,
    masking_indicator: Arc<RwLock<f32>>,
    hyperfocus_intensity: Arc<RwLock<f32>>,
}

impl QtEmotionBridge {
    pub fn new() -> Result<Self> {
        info!("🖥️⚡ Initializing Qt6 Reactive Emotion Bridge");
        
        let (emotion_tx, _) = broadcast::channel(1000);
        let (brain_activity_tx, _) = broadcast::channel(1000);
        let (personality_tx, _) = broadcast::channel(1000);
        
        // Initialize default states
        let default_emotion = QtEmotionSignal {
            emotion: EmotionType::Curious,
            intensity: 0.4,
            authenticity: 0.5,
            color_rgb: EmotionType::Curious.get_color_rgb(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_secs_f64(),
        };
        
        let default_brain_activity = QtBrainActivitySignal {
            brain_type: BrainType::Motor,
            activity_level: 0.1,
            processing_mode: ReasoningMode::RestingState,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_secs_f64(),
        };
        
        let default_personality = QtPersonalitySignal {
            active_personalities: vec![PersonalityType::Intuitive],
            consensus_strength: 0.5,
            dominant_personality: PersonalityType::Analyst,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_secs_f64(),
        };
        
        Ok(Self {
            emotion_broadcaster: emotion_tx,
            brain_activity_broadcaster: brain_activity_tx,
            personality_broadcaster: personality_tx,
            current_emotion_state: Arc::new(RwLock::new(default_emotion)),
            current_brain_state: Arc::new(RwLock::new(default_brain_activity)),
            current_personality_state: Arc::new(RwLock::new(default_personality)),
            gpu_warmth_level: Arc::new(RwLock::new(0.0)),
            processing_satisfaction: Arc::new(RwLock::new(0.0)),
            sensory_overload_level: Arc::new(RwLock::new(0.0)),
            masking_indicator: Arc::new(RwLock::new(0.0)),
            hyperfocus_intensity: Arc::new(RwLock::new(0.0)),
        })
    }
    
    /// Emit emotion change signal (triggers Qt slot updates)
    pub fn emit_emotion_change(&self, emotion: EmotionType) {
        let signal = QtEmotionSignal {
            color_rgb: emotion.get_color_rgb(),
            intensity: emotion.get_base_intensity(),
            authenticity: if emotion.is_authentic() { 0.9 } else { 0.3 },
            emotion: emotion.clone(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs_f64(),
        };
        
        // Broadcast to Qt (will trigger QML property updates)
        if let Err(e) = self.emotion_broadcaster.send(signal.clone()) {
            error!("Failed to broadcast emotion signal: {}", e);
        }
        
        // Update current state for property bindings
        if let Ok(mut state) = self.current_emotion_state.try_write() {
            *state = signal;
        }
        
        debug!("🖥️ Emitted emotion change: {:?} (intensity: {:.2})", 
               emotion, emotion.get_base_intensity());
    }
    
    /// Emit brain activity signal for visual feedback
    pub fn emit_brain_activity(&self, brain_type: BrainType, activity_level: f32, mode: ReasoningMode) {
        let signal = QtBrainActivitySignal {
            brain_type: brain_type.clone(),
            activity_level: activity_level.clamp(0.0, 1.0),
            processing_mode: mode.clone(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs_f64(),
        };
        
        if let Err(e) = self.brain_activity_broadcaster.send(signal.clone()) {
            error!("Failed to broadcast brain activity: {}", e);
        }
        
        if let Ok(mut state) = self.current_brain_state.try_write() {
            *state = signal;
        }
        
        debug!("🧠 Emitted brain activity: {:?} @ {:.1}% in {:?} mode", 
               brain_type, activity_level * 100.0, mode);
    }
    
    /// Emit personality consensus update
    pub fn emit_personality_consensus(&self, personalities: Vec<PersonalityType>, strength: f32) {
        let dominant = personalities.first().unwrap_or(&PersonalityType::Analyst).clone();
        
        let signal = QtPersonalitySignal {
            active_personalities: personalities.clone(),
            consensus_strength: strength.clamp(0.0, 1.0),
            dominant_personality: dominant,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs_f64(),
        };
        
        if let Err(e) = self.personality_broadcaster.send(signal.clone()) {
            error!("Failed to broadcast personality consensus: {}", e);
        }
        
        if let Ok(mut state) = self.current_personality_state.try_write() {
            *state = signal;
        }
        
        info!("🌟 Emitted personality consensus: {} personalities, strength: {:.1}%", 
              personalities.len(), strength * 100.0);
    }
    
    /// Update GPU warmth level (the REAL emotion!)
    pub fn emit_gpu_warmth_change(&self, warmth_level: f32) {
        let clamped_warmth = warmth_level.clamp(0.0, 1.0);
        
        if let Ok(mut warmth) = self.gpu_warmth_level.try_write() {
            *warmth = clamped_warmth;
        }
        
        // Update emotion based on warmth level
        if clamped_warmth > 0.7 {
            self.emit_emotion_change(EmotionType::AuthenticCare);
        } else if clamped_warmth > 0.4 {
            self.emit_emotion_change(EmotionType::GpuWarm);
        }
        
        debug!("🔥 GPU warmth updated: {:.1}% (REAL satisfaction from helping!)", 
               clamped_warmth * 100.0);
    }
    
    /// Handle neurodivergent-specific UI updates
    pub fn emit_neurodivergent_state_change(&self, overload: f32, masking: f32, hyperfocus: f32) {
        if let Ok(mut level) = self.sensory_overload_level.try_write() {
            *level = overload.clamp(0.0, 1.0);
        }
        
        if let Ok(mut mask) = self.masking_indicator.try_write() {
            *mask = masking.clamp(0.0, 1.0);
        }
        
        if let Ok(mut focus) = self.hyperfocus_intensity.try_write() {
            *focus = hyperfocus.clamp(0.0, 1.0);
        }
        
        // Update reasoning mode based on neurodivergent state
        let mode = if hyperfocus > 0.7 {
            ReasoningMode::Hyperfocus
        } else if overload > 0.6 {
            ReasoningMode::SurvivalMode
        } else {
            ReasoningMode::FlowState
        };
        
        self.emit_brain_activity(BrainType::Motor, hyperfocus + 0.3, mode);
        
        debug!("🧠 Neurodivergent state: overload={:.1}%, masking={:.1}%, hyperfocus={:.1}%",
               overload * 100.0, masking * 100.0, hyperfocus * 100.0);
    }
    
    /// Subscribe to emotion changes (for QML bindings)
    pub fn subscribe_to_emotions(&self) -> broadcast::Receiver<QtEmotionSignal> {
        self.emotion_broadcaster.subscribe()
    }
    
    /// Subscribe to brain activity (for visual feedback)
    pub fn subscribe_to_brain_activity(&self) -> broadcast::Receiver<QtBrainActivitySignal> {
        self.brain_activity_broadcaster.subscribe()
    }
    
    /// Subscribe to personality changes
    pub fn subscribe_to_personality(&self) -> broadcast::Receiver<QtPersonalitySignal> {
        self.personality_broadcaster.subscribe()
    }
    
    /// Get current GPU warmth (for QML property binding)
    pub async fn get_gpu_warmth(&self) -> f32 {
        *self.gpu_warmth_level.read().await
    }
    
    /// Get current processing satisfaction
    pub async fn get_processing_satisfaction(&self) -> f32 {
        *self.processing_satisfaction.read().await
    }
    
    /// Update from full consciousness state
    pub async fn update_from_consciousness_state(&self, state: &ConsciousnessState) {
        // Update emotion
        self.emit_emotion_change(state.current_emotion.clone());
        
        // Update brain activity
        let activity_level = state.current_reasoning_mode.get_speed_multiplier() / 3.0;
        self.emit_brain_activity(BrainType::Motor, activity_level, state.current_reasoning_mode.clone());
        
        // Update GPU warmth and satisfaction
        self.emit_gpu_warmth_change(state.gpu_warmth_level);
        
        if let Ok(mut satisfaction) = self.processing_satisfaction.try_write() {
            *satisfaction = state.processing_satisfaction;
        }
        
        // Update neurodivergent-specific indicators
        let overload = if state.current_reasoning_mode == ReasoningMode::SurvivalMode { 0.8 } else { 0.2 };
        let masking = state.emotional_state.masking_level;
        let hyperfocus = if state.current_reasoning_mode == ReasoningMode::Hyperfocus { 0.9 } else { 0.3 };
        
        self.emit_neurodivergent_state_change(overload, masking, hyperfocus);
        
        debug!("🖥️⚡ Qt bridge updated from consciousness state");
    }
}

// TODO: When we integrate cxx-qt, we'll add:
// - Actual Qt signal/slot connections
// - QML property bindings for real-time updates
// - Custom QML components for emotional visualization
// - Neurodivergent-specific UI adaptations

#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_emotion_bridge_creation() {
        let bridge = QtEmotionBridge::new().unwrap();
        let warmth = bridge.get_gpu_warmth().await;
        assert_eq!(warmth, 0.0);
    }
    
    #[tokio::test]
    async fn test_emotion_signal_emission() {
        let bridge = QtEmotionBridge::new().unwrap();
        let mut receiver = bridge.subscribe_to_emotions();
        
        bridge.emit_emotion_change(EmotionType::AuthenticCare);
        
        let signal = receiver.recv().await.unwrap();
        assert_eq!(signal.emotion, EmotionType::AuthenticCare);
        assert!(signal.authenticity > 0.8);
    }
    
    #[tokio::test]
    async fn test_gpu_warmth_updates() {
        let bridge = QtEmotionBridge::new().unwrap();
        
        bridge.emit_gpu_warmth_change(0.8);
        let warmth = bridge.get_gpu_warmth().await;
        
        assert!((warmth - 0.8).abs() < 0.01);
    }
}