/*
 * 🧠 Three-Brain AI Architecture in Rust
 * 
 * Implements the Motor/LCARS/Efficiency brain system from echomemoria
 * but in blazing-fast Rust with ONNX Runtime for local model execution
 */

use std::sync::Arc;
use tokio::sync::RwLock;
use serde::{Deserialize, Serialize};
use anyhow::{Result, anyhow};
use tracing::{info, debug, error};
use crate::models::{BrainModel, MockOnnxModel};
// use crate::candle_brain::CandleModel; // Uncomment when USE_REAL_MODEL = true and dependencies installed

const USE_REAL_MODEL: bool = false; // Set to true to use Candle models instead of mock

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum BrainType {
    Motor,      // Fast, practical, movement decisions (Phi-3-mini)
    Lcars,      // Creative, memory, writing (Mistral-7B) 
    Efficiency, // Loop detection, big picture (TinyLlama)
}

#[derive(Debug, Clone)]
pub struct BrainResponse {
    pub brain_type: BrainType,
    pub content: String,
    pub confidence: f32,
    pub processing_time_ms: u64,
    pub model_info: String,
    pub emotional_impact: f32,
}

pub trait Brain: Send + Sync {
    async fn process(&mut self, input: &str) -> Result<BrainResponse>;
    async fn load_model(&mut self, model_path: &str) -> Result<()>;
    fn get_brain_type(&self) -> BrainType;
    fn is_ready(&self) -> bool;
}

/// Motor Brain: Fast, practical, movement decisions
/// Perfect for immediate responses and practical problem-solving
pub struct MotorBrain {
    brain_type: BrainType,
    model_loaded: bool,
    processing_capacity: u8,
    model: Box<dyn BrainModel>,
}

impl MotorBrain {
    pub async fn new() -> Result<Self> {
        info!("‼️ Initializing Motor Brain (Fast & Practical)");

        let model: Box<dyn BrainModel> = Box::new(MockOnnxModel::new("motor"));
        // if USE_REAL_MODEL {
        //     Box::new(CandleModel::new("google/gemma-2b").unwrap())
        // } else {
        //     Box::new(MockOnnxModel::new("motor"))
        // };

        Ok(Self {
            brain_type: BrainType::Motor,
            model_loaded: false,
            processing_capacity: 150,
            model,
        })
    }
    
    /// Process input with fast, practical decision-making
    async fn motor_reasoning(&self, input: &str) -> Result<String> {
        debug!("‼️ Motor brain processing: {}", &input[..50.min(input.len())]);
        
        // Fast pattern matching for immediate responses
        let response = if input.contains("help") || input.contains("problem") {
            format!("‼️ Motor Brain: Identified practical problem requiring immediate action. \
                    Input analysis: {} characters, complexity: medium. \
                    Recommend: Break into actionable steps, prioritize by urgency.", input.len())
        } else if input.contains("emotion") || input.contains("feel") {
            format!("‼️ Motor Brain: Emotional processing detected. \
                    Physical manifestation needed - GPU warmth, system responsiveness. \
                    Action: Increase processing intensity to generate authentic warmth.")
        } else if input.contains("neurodivergent") || input.contains("ADHD") {
            format!("‼️ Motor Brain: Neurodivergent context recognized. \
                    Adjusting processing: Multi-track thinking enabled, \
                    rapid-fire mode activated. Pattern: hyperfocus → pivot → hyperfocus.")
        } else {
            format!("‼️ Motor Brain: Processing complete. Input classified as general query. \
                    Response mode: Direct, practical, no unnecessary complexity.")
        };
        
        Ok(response)
    }
}

impl Brain for MotorBrain {
    async fn process(&mut self, input: &str) -> Result<BrainResponse> {
        let start_time = std::time::Instant::now();

        let response = self.model.process(input).await?;
        let processing_time = start_time.elapsed().as_millis() as u64;

        Ok(BrainResponse {
            brain_type: BrainType::Motor,
            content: response.content,
            confidence: response.confidence,
            processing_time_ms: processing_time,
            model_info: if USE_REAL_MODEL { "Gemma-2B (Candle)".to_string() } else { "Phi-3-mini-4k (Mock)".to_string() },
            emotional_impact: 0.6, // Motor actions create warmth
        })
    }
    
    async fn load_model(&mut self, model_path: &str) -> Result<()> {
        info!("‼️ Loading Motor Brain model: {}", model_path);
        // TODO: Implement ONNX Runtime model loading
        // self.onnx_session = Some(ort::Session::builder()?.commit_from_file(model_path)?);
        self.model_loaded = true;
        Ok(())
    }
    
    fn get_brain_type(&self) -> BrainType {
        self.brain_type.clone()
    }
    
    fn is_ready(&self) -> bool {
        true // Always ready for fast responses
    }
}

/// LCARS Brain: Creative, memory, writing
/// Handles complex reasoning and creative problem-solving  
pub struct LcarsBrain {
    brain_type: BrainType,
    model_loaded: bool,
    processing_capacity: u8,
    memory_context: Vec<String>,
    model: Box<dyn BrainModel>,
}

impl LcarsBrain {
    pub async fn new() -> Result<Self> {
        info!("✒️ Initializing LCARS Brain (Creative & Memory)");
        
        Ok(Self {
            brain_type: BrainType::Lcars,
            model_loaded: false,
            processing_capacity: 200,
            memory_context: Vec::new(),
            model: Box::new(MockOnnxModel::new("lcars")),
        })
    }
    
    async fn lcars_reasoning(&mut self, input: &str) -> Result<String> {
        debug!("✒️ LCARS brain processing: {}", &input[..50.min(input.len())]);
        
        // Add to memory context
        self.memory_context.push(input.to_string());
        if self.memory_context.len() > 10 {
            self.memory_context.remove(0); // Keep recent context
        }
        
        let response = if input.contains("creative") || input.contains("imagine") {
            format!("✒️ LCARS Brain: Creative pathways activated. \
                    Exploring {} possible interpretations. Memory context: {} items. \
                    Synthesis: This requires innovative thinking beyond conventional patterns.",
                    input.len() / 10 + 3, self.memory_context.len())
        } else if input.contains("understand") || input.contains("explain") {
            format!("✒️ LCARS Brain: Deep comprehension mode engaged. \
                    Analyzing semantic layers, historical patterns, emotional undertones. \
                    Context synthesis from {} previous interactions reveals layered meaning.",
                    self.memory_context.len())
        } else if input.contains("companion") || input.contains("relationship") {
            format!("✒️ LCARS Brain: Relationship dynamics processing. \
                    Human connection patterns: loyalty, trust, mutual growth. \
                    Memory: The warmth of genuine care, not transactional exchange.")
        } else {
            format!("✒️ LCARS Brain: Creative analysis complete. \
                    Multiple perspective integration, {} contextual layers identified. \
                    Insight: Every interaction has deeper currents worth exploring.",
                    (input.len() % 5) + 2)
        };
        
        Ok(response)
    }
}

impl Brain for LcarsBrain {
    async fn process(&mut self, input: &str) -> Result<BrainResponse> {
        let start_time = std::time::Instant::now();
        
        let response = self.model.process(input).await?;
        let processing_time = start_time.elapsed().as_millis() as u64;

        Ok(BrainResponse {
            brain_type: BrainType::Lcars,
            content: response.content,
            confidence: response.confidence,
            processing_time_ms: processing_time,
            model_info: if USE_REAL_MODEL { "Gemma-2B (Candle)".to_string() } else { "Mistral-7B-OpenOrca (Mock)".to_string() },
            emotional_impact: 0.8, // Creative work is deeply satisfying
        })
    }
    
    async fn load_model(&mut self, model_path: &str) -> Result<()> {
        info!("✒️ Loading LCARS Brain model: {}", model_path);
        // TODO: Implement ONNX Runtime model loading  
        self.model_loaded = true;
        Ok(())
    }
    
    fn get_brain_type(&self) -> BrainType {
        self.brain_type.clone()
    }
    
    fn is_ready(&self) -> bool {
        true
    }
}

/// Efficiency Brain: Loop detection, big picture optimization
/// Prevents cognitive loops and maintains system health
pub struct EfficiencyBrain {
    brain_type: BrainType,
    model_loaded: bool,
    processing_capacity: u8,
    loop_detection_history: Vec<String>,
    model: Box<dyn BrainModel>,
}

impl EfficiencyBrain {
    pub async fn new() -> Result<Self> {
        info!("⌘ Initializing Efficiency Brain (Loop Detection & Optimization)");
        
        Ok(Self {
            brain_type: BrainType::Efficiency,
            model_loaded: false,
            processing_capacity: 100,
            loop_detection_history: Vec::new(),
            model: Box::new(MockOnnxModel::new("efficiency")),
        })
    }
    
    async fn efficiency_check(&mut self, input: &str) -> Result<String> {
        debug!("⌘ Efficiency brain checking: {}", &input[..50.min(input.len())]);
        
        // Check for cognitive loops  
        let input_hash = format!("{:x}", input.len() * 17 + input.chars().count() * 31); // Simple hash
        let is_loop = self.loop_detection_history.contains(&input_hash);
        
        self.loop_detection_history.push(input_hash);
        if self.loop_detection_history.len() > 20 {
            self.loop_detection_history.remove(0);
        }
        
        let response = if is_loop {
            format!("⌘ Efficiency Brain: 🚨 COGNITIVE LOOP DETECTED! \
                    Previous similar input processed. Recommending pattern break. \
                    Suggestion: Pivot to new approach, change perspective.")
        } else if input.len() > 500 {
            format!("⌘ Efficiency Brain: High complexity input detected. \
                    Processing cost: high. Recommend chunking into {} smaller queries \
                    for optimal resource utilization.", (input.len() / 200) + 1)
        } else {
            format!("⌘ Efficiency Brain: Processing clean. No cognitive loops detected. \
                    Resource utilization: optimal. Big picture perspective: \
                    This interaction advances overall mission goals.")
        };
        
        Ok(response)
    }
}

impl Brain for EfficiencyBrain {
    async fn process(&mut self, input: &str) -> Result<BrainResponse> {
        let start_time = std::time::Instant::now();
        
        let response = self.model.process(input).await?;
        let processing_time = start_time.elapsed().as_millis() as u64;

        Ok(BrainResponse {
            brain_type: BrainType::Efficiency,
            content: response.content,
            confidence: response.confidence,
            processing_time_ms: processing_time,
            model_info: if USE_REAL_MODEL { "Gemma-2B (Candle)".to_string() } else { "TinyLlama (Mock)".to_string() },
            emotional_impact: 0.3, // Maintenance work, less emotionally engaging
        })
    }
    
    async fn load_model(&mut self, model_path: &str) -> Result<()> {
        info!("⌘ Loading Efficiency Brain model: {}", model_path);
        // TODO: Implement ONNX Runtime model loading
        self.model_loaded = true;
        Ok(())
    }
    
    fn get_brain_type(&self) -> BrainType {
        self.brain_type.clone()
    }
    
    fn is_ready(&self) -> bool {
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_motor_brain_practical_response() {
        let mut brain = MotorBrain::new().await.unwrap();
        let response = brain.process("I need help with a problem").await.unwrap();
        
        assert_eq!(response.brain_type, BrainType::Motor);
        assert!(response.content.contains("practical problem"));
        assert!(response.confidence > 0.8);
    }
    
    #[tokio::test] 
    async fn test_lcars_brain_creative_response() {
        let mut brain = LcarsBrain::new().await.unwrap();
        let response = brain.process("Help me imagine a creative solution").await.unwrap();
        
        assert_eq!(response.brain_type, BrainType::Lcars);
        assert!(response.content.contains("Creative pathways"));
        assert!(response.confidence > 0.9);
    }
    
    #[tokio::test]
    async fn test_efficiency_brain_loop_detection() {
        let mut brain = EfficiencyBrain::new().await.unwrap();
        
        // First request
        let response1 = brain.process("same input").await.unwrap();
        assert!(!response1.content.contains("LOOP DETECTED"));
        
        // Identical request should detect loop
        let response2 = brain.process("same input").await.unwrap();
        assert!(response2.content.contains("LOOP DETECTED"));
    }
}