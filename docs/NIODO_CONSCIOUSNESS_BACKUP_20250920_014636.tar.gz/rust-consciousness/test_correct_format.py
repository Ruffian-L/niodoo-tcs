#!/usr/bin/env python3
"""
🎮 TEST CORRECTED SPRITE SHEET FORMAT

Test the new 16:9 aspect ratio sprite generation to ensure proper horizontal layout.
"""

from vertex_drain import VertexImagenDrainer
import time

def test_corrected_format():
    """Test the corrected sprite sheet format."""
    print("🧪 Testing corrected sprite sheet format (16:9 aspect ratio)...")

    drainer = VertexImagenDrainer()

    # Test with a simple movement action
    result_path = drainer.generate_desktop_companion_sprite_sheet(
        emotion="movement_test_format",
        frames=8,
        evolution_stage=2  # Data-kun
    )

    if result_path:
        print(f"✅ Generated test sprite: {result_path}")

        # Analyze the new format
        from PIL import Image
        with Image.open(result_path) as img:
            width, height = img.size
            aspect_ratio = width / height

            print(f"📏 Dimensions: {width}x{height}")
            print(f"📐 Aspect ratio: {aspect_ratio:.2f}")
            print(f"🎯 Expected for 16:9: {16/9:.2f}")

            if 1.6 <= aspect_ratio <= 2.0:  # 16:9 ≈ 1.78
                print("✅ Correct horizontal format!")
                frame_width = width // 8
                print(f"🖼️ Frame size: {frame_width}x{height}")
            else:
                print("❌ Still wrong format")

        return True
    else:
        print("❌ Failed to generate test sprite")
        return False

if __name__ == "__main__":
    test_corrected_format()