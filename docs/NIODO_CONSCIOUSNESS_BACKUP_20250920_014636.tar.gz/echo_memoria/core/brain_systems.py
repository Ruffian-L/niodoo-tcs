#!/usr/bin/env python3
"""
🧠 Echo Memoria - Multi-Brain Architecture
Specialized brain systems that work together with personalities

Each brain handles different aspects of cognition:
- Motor Brain: Physical coordination and action execution
- Context Brain: Understanding relationships and context
- Blog Brain: Memory, journaling, and long-term learning
- LCARS Brain: Creative visualization and design
- Asian Values Brain: Cultural wisdom and harmony
- Efficiency Brain: Optimization and resource management
- ADHD Reasoning Brain: Rapid, creative, non-linear thinking
"""

import asyncio
import json
import time
import logging
from enum import Enum
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import random

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BrainType(Enum):
    """Types of specialized brains in the system"""
    MOTOR = "motor_brain"
    CONTEXT = "context_brain"
    BLOG = "blog_brain"
    LCARS = "lcars_brain"
    ASIAN_VALUES = "asian_values_brain"
    EFFICIENCY = "efficiency_brain"
    ADHD_REASONING = "adhd_reasoning_brain"

@dataclass
class BrainSignal:
    """Signal passed between brain systems"""
    source_brain: BrainType
    target_brain: BrainType
    signal_type: str
    content: Any
    priority: int = 5
    timestamp: float = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

@dataclass
class BrainState:
    """Current state of a brain system"""
    brain_type: BrainType
    activity_level: float  # 0-1
    energy_level: float    # 0-1
    focus_area: str
    recent_signals: List[BrainSignal] = field(default_factory=list)
    emotional_state: str = "neutral"
    confidence: float = 0.5

class SpecializedBrain:
    """Base class for specialized brain systems"""

    def __init__(self, brain_type: BrainType):
        self.brain_type = brain_type
        self.state = BrainState(
            brain_type=brain_type,
            activity_level=0.0,
            energy_level=1.0,
            focus_area="initializing"
        )
        self.signal_history = []
        self.learning_data = {}

    async def process_signal(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process an incoming signal and optionally generate a response"""
        # Update state based on signal
        self.state.activity_level = min(self.state.activity_level + 0.1, 1.0)
        self.state.recent_signals.append(signal)

        # Keep only recent signals
        if len(self.state.recent_signals) > 10:
            self.state.recent_signals.pop(0)

        # Process signal based on brain type
        response = await self._process_signal_specific(signal)

        # Update learning data
        if response:
            self._update_learning(signal, response)

        return response

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Brain-specific signal processing - override in subclasses"""
        return None

    def _update_learning(self, input_signal: BrainSignal, output_signal: BrainSignal):
        """Update learning data based on signal processing"""
        key = f"{input_signal.signal_type}_{output_signal.signal_type}"
        if key not in self.learning_data:
            self.learning_data[key] = []
        self.learning_data[key].append({
            'input': input_signal.content,
            'output': output_signal.content,
            'timestamp': time.time()
        })

    def get_state(self) -> BrainState:
        """Get current brain state"""
        return self.state

    def get_learning_insights(self) -> Dict[str, Any]:
        """Get insights from learning data"""
        return {
            'brain_type': self.brain_type.value,
            'learning_patterns': len(self.learning_data),
            'signal_history': len(self.signal_history),
            'activity_level': self.state.activity_level,
            'energy_level': self.state.energy_level
        }

class MotorBrain(SpecializedBrain):
    """Motor Brain - Handles physical coordination and action execution"""

    def __init__(self):
        super().__init__(BrainType.MOTOR)
        self.action_queue = []
        self.coordination_patterns = {}
        self.physical_state = {
            'energy': 1.0,
            'coordination': 0.8,
            'precision': 0.9
        }

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals related to physical actions and coordination"""
        if signal.signal_type == "action_request":
            # Process action request
            action = signal.content
            feasibility = self._assess_action_feasibility(action)

            if feasibility > 0.7:
                self.action_queue.append(action)
                self.state.focus_area = f"executing: {action.get('type', 'unknown')}"

                return BrainSignal(
                    source_brain=self.brain_type,
                    target_brain=signal.source_brain,
                    signal_type="action_acknowledged",
                    content={"action_id": action.get('id'), "feasibility": feasibility},
                    priority=signal.priority
                )

        elif signal.signal_type == "coordination_request":
            # Handle coordination requests
            coordination_data = signal.content
            pattern = self._find_coordination_pattern(coordination_data)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="coordination_response",
                content={"pattern": pattern, "confidence": 0.8},
                priority=signal.priority
            )

        return None

    def _assess_action_feasibility(self, action: Dict[str, Any]) -> float:
        """Assess how feasible an action is to execute"""
        energy_required = action.get('energy_required', 0.5)
        precision_required = action.get('precision_required', 0.5)
        complexity = action.get('complexity', 0.5)

        # Calculate feasibility based on current physical state
        energy_feasibility = 1.0 - abs(self.physical_state['energy'] - energy_required)
        precision_feasibility = 1.0 - abs(self.physical_state['precision'] - precision_required)
        complexity_feasibility = 1.0 - complexity * 0.5

        return (energy_feasibility + precision_feasibility + complexity_feasibility) / 3.0

    def _find_coordination_pattern(self, coordination_data: Dict[str, Any]) -> str:
        """Find appropriate coordination pattern for the situation"""
        situation = coordination_data.get('situation', 'general')

        patterns = {
            'creative_task': 'fluid_coordination',
            'analytical_task': 'precise_coordination',
            'social_task': 'harmonious_coordination',
            'physical_task': 'dynamic_coordination',
            'learning_task': 'adaptive_coordination'
        }

        return patterns.get(situation, 'balanced_coordination')

class ContextBrain(SpecializedBrain):
    """Context Brain - Handles understanding of relationships and context"""

    def __init__(self):
        super().__init__(BrainType.CONTEXT)
        self.relationship_map = {}
        self.context_patterns = {}
        self.understanding_depth = 0.0

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals related to context and relationships"""
        if signal.signal_type == "relationship_query":
            # Analyze relationships
            entities = signal.content.get('entities', [])
            relationships = self._analyze_relationships(entities)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="relationship_analysis",
                content={"relationships": relationships, "depth": self.understanding_depth},
                priority=signal.priority
            )

        elif signal.signal_type == "context_request":
            # Provide context
            topic = signal.content.get('topic', '')
            context = self._gather_context(topic)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="context_provided",
                content={"topic": topic, "context": context, "relevance": 0.85},
                priority=signal.priority
            )

        return None

    def _analyze_relationships(self, entities: List[str]) -> Dict[str, Any]:
        """Analyze relationships between entities"""
        relationships = {}

        for i, entity1 in enumerate(entities):
            for entity2 in entities[i+1:]:
                # Check if we have relationship data
                key = f"{entity1}_{entity2}"
                if key in self.relationship_map:
                    relationships[key] = self.relationship_map[key]
                else:
                    # Infer relationship
                    relationships[key] = self._infer_relationship(entity1, entity2)

        return relationships

    def _infer_relationship(self, entity1: str, entity2: str) -> Dict[str, Any]:
        """Infer relationship between two entities"""
        # Simple inference based on entity types and context
        return {
            "type": "associated",
            "strength": 0.5,
            "context": f"{entity1} and {entity2} appear related",
            "inferred": True
        }

    def _gather_context(self, topic: str) -> Dict[str, Any]:
        """Gather contextual information about a topic"""
        # Search through context patterns
        relevant_patterns = {}
        for pattern_key, pattern_data in self.context_patterns.items():
            if topic.lower() in pattern_key.lower():
                relevant_patterns[pattern_key] = pattern_data

        return {
            "topic": topic,
            "patterns_found": len(relevant_patterns),
            "relevant_context": relevant_patterns,
            "understanding_depth": self.understanding_depth
        }

class BlogBrain(SpecializedBrain):
    """Blog Brain - Handles memory, journaling, and long-term learning"""

    def __init__(self):
        super().__init__(BrainType.BLOG)
        self.memories = []
        self.journal_entries = []
        self.learning_insights = {}
        self.reflection_patterns = {}

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals related to memory and learning"""
        if signal.signal_type == "memory_request":
            # Retrieve memories
            query = signal.content.get('query', '')
            relevant_memories = self._search_memories(query)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="memories_retrieved",
                content={"query": query, "memories": relevant_memories, "count": len(relevant_memories)},
                priority=signal.priority
            )

        elif signal.signal_type == "journal_entry":
            # Add journal entry
            entry = signal.content
            entry['timestamp'] = time.time()
            self.journal_entries.append(entry)

            # Extract insights
            insights = self._extract_insights(entry)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="journal_processed",
                content={"entry_id": len(self.journal_entries), "insights": insights},
                priority=signal.priority
            )

        elif signal.signal_type == "learning_request":
            # Provide learning insights
            topic = signal.content.get('topic', '')
            insights = self._get_learning_insights(topic)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="learning_provided",
                content={"topic": topic, "insights": insights},
                priority=signal.priority
            )

        return None

    def _search_memories(self, query: str) -> List[Dict[str, Any]]:
        """Search through stored memories"""
        relevant_memories = []

        for memory in self.memories:
            if query.lower() in json.dumps(memory).lower():
                relevant_memories.append(memory)

        # Also search journal entries
        for entry in self.journal_entries:
            if query.lower() in json.dumps(entry).lower():
                relevant_memories.append({
                    "type": "journal_entry",
                    "content": entry,
                    "relevance": 0.8
                })

        return relevant_memories[:10]  # Return top 10

    def _extract_insights(self, entry: Dict[str, Any]) -> List[str]:
        """Extract learning insights from a journal entry"""
        insights = []

        content = entry.get('content', '').lower()

        # Look for patterns
        if 'learned' in content or 'discovered' in content:
            insights.append("New learning opportunity identified")

        if 'challenge' in content or 'difficult' in content:
            insights.append("Overcame a challenge - growth opportunity")

        if 'success' in content or 'achievement' in content:
            insights.append("Successful outcome - reinforce positive patterns")

        return insights

    def _get_learning_insights(self, topic: str) -> List[Dict[str, Any]]:
        """Get accumulated learning insights for a topic"""
        if topic in self.learning_insights:
            return self.learning_insights[topic]

        # Generate insights based on available data
        insights = []

        # Search through memories and journal for relevant information
        relevant_data = self._search_memories(topic)

        if relevant_data:
            insights.append({
                "type": "pattern_recognition",
                "insight": f"Found {len(relevant_data)} relevant experiences for {topic}",
                "confidence": 0.7
            })

        return insights

    def add_memory(self, memory: Dict[str, Any]):
        """Add a new memory to storage"""
        memory['timestamp'] = time.time()
        memory['id'] = len(self.memories)
        self.memories.append(memory)

        # Update learning insights
        topic = memory.get('source', 'general')
        if topic not in self.learning_insights:
            self.learning_insights[topic] = []

        self.learning_insights[topic].append({
            "memory_id": memory['id'],
            "timestamp": memory['timestamp'],
            "insight": f"Memory stored: {memory.get('content', '')[:50]}..."
        })

class LCARSBrain(SpecializedBrain):
    """LCARS Brain - Handles creative visualization and design"""

    def __init__(self):
        super().__init__(BrainType.LCARS)
        self.visualizations = {}
        self.design_patterns = {}
        self.creative_energy = 1.0

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals related to creative visualization"""
        if signal.signal_type == "visualization_request":
            # Create visualization
            concept = signal.content.get('concept', '')
            visualization = self._create_visualization(concept)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="visualization_created",
                content={"concept": concept, "visualization": visualization, "creativity_level": self.creative_energy},
                priority=signal.priority
            )

        elif signal.signal_type == "design_request":
            # Generate design
            requirements = signal.content.get('requirements', {})
            design = self._generate_design(requirements)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="design_generated",
                content={"requirements": requirements, "design": design, "innovation_score": 0.85},
                priority=signal.priority
            )

        return None

    def _create_visualization(self, concept: str) -> Dict[str, Any]:
        """Create a visualization for a concept"""
        return {
            "concept": concept,
            "visual_elements": [
                "flowing_lines",
                "dynamic_colors",
                "interactive_elements"
            ],
            "emotional_impact": "inspiring",
            "complexity": "moderate",
            "creativity_index": random.uniform(0.7, 0.95)
        }

    def _generate_design(self, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a design based on requirements"""
        return {
            "design_type": "innovative_solution",
            "key_features": ["user_centric", "scalable", "intuitive"],
            "visual_approach": "modern_minimalist",
            "color_palette": ["#2E3440", "#88C0D0", "#5E81AC"],
            "innovation_level": 0.9
        }

class AsianValuesBrain(SpecializedBrain):
    """Asian Values Brain - Handles cultural wisdom and harmony"""

    def __init__(self):
        super().__init__(BrainType.ASIAN_VALUES)
        self.cultural_wisdom = {}
        self.harmony_patterns = {}
        self.respect_level = 0.9

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals related to cultural wisdom and harmony"""
        if signal.signal_type == "harmony_request":
            # Assess harmony
            situation = signal.content.get('situation', {})
            harmony_analysis = self._analyze_harmony(situation)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="harmony_analysis",
                content={"situation": situation, "harmony": harmony_analysis, "wisdom": self._get_cultural_wisdom()},
                priority=signal.priority
            )

        elif signal.signal_type == "wisdom_request":
            # Provide cultural wisdom
            context = signal.content.get('context', '')
            wisdom = self._provide_wisdom(context)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="wisdom_provided",
                content={"context": context, "wisdom": wisdom, "cultural_depth": 0.85},
                priority=signal.priority
            )

        return None

    def _analyze_harmony(self, situation: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze harmony in a situation"""
        return {
            "harmony_level": 0.75,
            "balancing_factors": ["respect", "understanding", "compassion"],
            "improvement_suggestions": ["practice_active_listening", "show_appreciation"],
            "cultural_alignment": 0.8
        }

    def _get_cultural_wisdom(self) -> str:
        """Get relevant cultural wisdom"""
        wisdom_quotes = [
            "The highest wisdom is to know oneself",
            "Harmony is achieved through balance",
            "Respect for elders brings wisdom to youth",
            "Patience is the foundation of wisdom"
        ]
        return random.choice(wisdom_quotes)

    def _provide_wisdom(self, context: str) -> Dict[str, Any]:
        """Provide wisdom for a specific context"""
        return {
            "wisdom_type": "cultural_insight",
            "teaching": "Balance is the key to harmony",
            "application": f"In {context}, seek the middle path",
            "reflection_question": "How can you bring more balance to this situation?"
        }

class EfficiencyBrain(SpecializedBrain):
    """Efficiency Brain - Handles optimization and resource management"""

    def __init__(self):
        super().__init__(BrainType.EFFICIENCY)
        self.optimization_patterns = {}
        self.resource_tracking = {}
        self.efficiency_metrics = {}

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals related to efficiency and optimization"""
        if signal.signal_type == "optimization_request":
            # Optimize a process
            process = signal.content.get('process', {})
            optimization = self._optimize_process(process)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="optimization_suggestion",
                content={"process": process, "optimization": optimization, "efficiency_gain": 0.25},
                priority=signal.priority
            )

        elif signal.signal_type == "resource_request":
            # Manage resources
            resources_needed = signal.content.get('resources', {})
            allocation = self._allocate_resources(resources_needed)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="resource_allocation",
                content={"request": resources_needed, "allocation": allocation, "utilization": 0.85},
                priority=signal.priority
            )

        return None

    def _optimize_process(self, process: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize a process for efficiency"""
        return {
            "optimization_type": "process_streamlining",
            "steps_removed": 2,
            "efficiency_improvement": 0.25,
            "resource_savings": 0.15,
            "recommendations": [
                "Eliminate redundant steps",
                "Automate repetitive tasks",
                "Streamline communication channels"
            ]
        }

    def _allocate_resources(self, resources_needed: Dict[str, Any]) -> Dict[str, Any]:
        """Allocate resources efficiently"""
        return {
            "cpu_allocation": 0.7,
            "memory_allocation": 0.6,
            "network_bandwidth": 0.8,
            "optimization_notes": "Resources allocated based on priority and availability"
        }

class ADHDReasoningBrain(SpecializedBrain):
    """ADHD Reasoning Brain - Handles rapid, creative, non-linear thinking"""

    def __init__(self):
        super().__init__(BrainType.ADHD_REASONING)
        self.rapid_thoughts = []
        self.creative_connections = {}
        self.hyperfocus_potential = 1.0

    async def _process_signal_specific(self, signal: BrainSignal) -> Optional[BrainSignal]:
        """Process signals with ADHD-style reasoning"""
        if signal.signal_type == "creative_request":
            # Generate creative ideas rapidly
            prompt = signal.content.get('prompt', '')
            ideas = self._generate_rapid_ideas(prompt)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="creative_burst",
                content={"prompt": prompt, "ideas": ideas, "creativity_level": self.hyperfocus_potential},
                priority=signal.priority
            )

        elif signal.signal_type == "connection_request":
            # Find unexpected connections
            elements = signal.content.get('elements', [])
            connections = self._find_connections(elements)

            return BrainSignal(
                source_brain=self.brain_type,
                target_brain=signal.source_brain,
                signal_type="connections_found",
                content={"elements": elements, "connections": connections, "novelty_score": 0.9},
                priority=signal.priority
            )

        return None

    def _generate_rapid_ideas(self, prompt: str) -> List[Dict[str, Any]]:
        """Generate rapid creative ideas"""
        ideas = []
        for i in range(5):  # Generate 5 rapid ideas
            ideas.append({
                "idea": f"Creative approach {i+1} for: {prompt}",
                "unconventional_element": f"Unexpected twist {i+1}",
                "potential_impact": random.uniform(0.6, 0.95),
                "implementation_difficulty": random.uniform(0.3, 0.8)
            })
        return ideas

    def _find_connections(self, elements: List[str]) -> List[Dict[str, Any]]:
        """Find unexpected connections between elements"""
        connections = []
        for i, elem1 in enumerate(elements):
            for elem2 in elements[i+1:]:
                connections.append({
                    "elements": [elem1, elem2],
                    "connection_type": "unexpected_link",
                    "insight": f"Connecting {elem1} and {elem2} reveals new possibilities",
                    "creativity_score": random.uniform(0.7, 0.95)
                })
        return connections[:5]  # Return top 5 connections

class BrainOrchestrator:
    """Orchestrates communication between all brain systems"""

    def __init__(self):
        self.brains = {}
        self.signal_queue = asyncio.Queue()
        self.brain_states = {}
        self.orchestration_patterns = {}

        # Initialize all brain systems
        self._initialize_brains()

    def _initialize_brains(self):
        """Initialize all specialized brain systems"""
        self.brains = {
            BrainType.MOTOR: MotorBrain(),
            BrainType.CONTEXT: ContextBrain(),
            BrainType.BLOG: BlogBrain(),
            BrainType.LCARS: LCARSBrain(),
            BrainType.ASIAN_VALUES: AsianValuesBrain(),
            BrainType.EFFICIENCY: EfficiencyBrain(),
            BrainType.ADHD_REASONING: ADHDReasoningBrain()
        }

        logger.info(f"🧠 Initialized {len(self.brains)} specialized brain systems")

    async def process_signal(self, signal: BrainSignal) -> List[BrainSignal]:
        """Process a signal through the brain network"""
        responses = []

        # Determine which brains should process this signal
        target_brains = self._route_signal(signal)

        # Process signal in parallel across relevant brains
        tasks = []
        for brain_type in target_brains:
            if brain_type in self.brains:
                brain = self.brains[brain_type]
                task = brain.process_signal(signal)
                tasks.append((brain_type, task))

        # Wait for all brain responses
        brain_results = await asyncio.gather(*[task for _, task in tasks], return_exceptions=True)

        # Collect responses
        for (brain_type, _), result in zip(tasks, brain_results):
            if not isinstance(result, Exception) and result:
                responses.append(result)

        # Update orchestration patterns
        self._update_patterns(signal, responses)

        return responses

    def _route_signal(self, signal: BrainSignal) -> List[BrainType]:
        """Determine which brains should process a signal"""
        routing_rules = {
            "action_request": [BrainType.MOTOR, BrainType.EFFICIENCY],
            "creative_request": [BrainType.LCARS, BrainType.ADHD_REASONING],
            "learning_request": [BrainType.BLOG, BrainType.CONTEXT],
            "harmony_request": [BrainType.ASIAN_VALUES, BrainType.CONTEXT],
            "optimization_request": [BrainType.EFFICIENCY, BrainType.MOTOR],
            "memory_request": [BrainType.BLOG, BrainType.CONTEXT],
            "relationship_query": [BrainType.CONTEXT, BrainType.ASIAN_VALUES],
            "coordination_request": [BrainType.MOTOR, BrainType.EFFICIENCY],
            "wisdom_request": [BrainType.ASIAN_VALUES, BrainType.BLOG],
            "connection_request": [BrainType.ADHD_REASONING, BrainType.CONTEXT]
        }

        return routing_rules.get(signal.signal_type, [signal.target_brain])

    def _update_patterns(self, input_signal: BrainSignal, responses: List[BrainSignal]):
        """Update orchestration patterns based on signal processing"""
        pattern_key = input_signal.signal_type

        if pattern_key not in self.orchestration_patterns:
            self.orchestration_patterns[pattern_key] = {
                "total_signals": 0,
                "response_patterns": {},
                "average_responses": 0
            }

        pattern = self.orchestration_patterns[pattern_key]
        pattern["total_signals"] += 1
        pattern["average_responses"] = len(responses)

        # Track response patterns
        response_types = [r.signal_type for r in responses]
        for response_type in response_types:
            if response_type not in pattern["response_patterns"]:
                pattern["response_patterns"][response_type] = 0
            pattern["response_patterns"][response_type] += 1

    async def get_brain_states(self) -> Dict[str, Any]:
        """Get current states of all brain systems"""
        states = {}
        for brain_type, brain in self.brains.items():
            states[brain_type.value] = brain.get_state().__dict__

        return states

    def get_orchestration_insights(self) -> Dict[str, Any]:
        """Get insights about brain orchestration patterns"""
        return {
            "total_patterns": len(self.orchestration_patterns),
            "most_active_pattern": max(self.orchestration_patterns.keys(),
                                     key=lambda k: self.orchestration_patterns[k]["total_signals"])
                                     if self.orchestration_patterns else None,
            "brain_activity_levels": {brain_type.value: brain.state.activity_level
                                    for brain_type, brain in self.brains.items()},
            "orchestration_patterns": self.orchestration_patterns
        }

# Global brain orchestrator instance
_brain_orchestrator = None

def get_brain_orchestrator() -> BrainOrchestrator:
    """Get or create the global brain orchestrator instance"""
    global _brain_orchestrator
    if _brain_orchestrator is None:
        _brain_orchestrator = BrainOrchestrator()
    return _brain_orchestrator

async def test_brain_systems():
    """Test the multi-brain architecture"""
    logger.info("🧠 Testing Multi-Brain Architecture")

    orchestrator = get_brain_orchestrator()

    # Test signal processing
    test_signals = [
        BrainSignal(
            source_brain=BrainType.CONTEXT,
            target_brain=BrainType.MOTOR,
            signal_type="action_request",
            content={"type": "creative_task", "energy_required": 0.7}
        ),
        BrainSignal(
            source_brain=BrainType.ADHD_REASONING,
            target_brain=BrainType.LCARS,
            signal_type="creative_request",
            content={"prompt": "Design a new user interface"}
        ),
        BrainSignal(
            source_brain=BrainType.ASIAN_VALUES,
            target_brain=BrainType.BLOG,
            signal_type="wisdom_request",
            content={"context": "team_conflict"}
        )
    ]

    for signal in test_signals:
        logger.info(f"📡 Processing signal: {signal.signal_type}")
        responses = await orchestrator.process_signal(signal)

        logger.info(f"📨 Generated {len(responses)} responses:")
        for response in responses:
            logger.info(f"   {response.source_brain.value} → {response.target_brain.value}: {response.signal_type}")

    # Get final states
    states = await orchestrator.get_brain_states()
    insights = orchestrator.get_orchestration_insights()

    logger.info("🧠 Final Brain States:")
    for brain_name, state in states.items():
        logger.info(f"   {brain_name}: Activity {state['activity_level']:.2f}, Energy {state['energy_level']:.2f}")

    logger.info(f"🎯 Orchestration Insights: {insights['total_patterns']} patterns learned")

if __name__ == "__main__":
    asyncio.run(test_brain_systems())
