#!/usr/bin/env python3
"""
🗣️ Echo Memoria - Voice Integration System
Personality-driven voice interface with speech recognition and synthesis

Each personality has unique:
- Voice characteristics (rate, tone, style)
- Speech patterns and mannerisms
- Emotional expression through voice
- Communication preferences
"""

import asyncio
import json
import time
import logging
import threading
import queue
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from enum import Enum

# Voice integration imports (optional)
try:
    import speech_recognition as sr
    import pyttsx3
    from vosk import Model, KaldiRecognizer
    VOICE_AVAILABLE = True
except ImportError:
    VOICE_AVAILABLE = False
    logging.warning("Voice libraries not available - voice integration disabled")

from echo_memoria.core.multi_personality_brain import PersonalityType

logger = logging.getLogger(__name__)

class VoiceEngine(Enum):
    """Available voice engines"""
    PYTTSX3 = "pyttsx3"
    VOSK = "vosk"
    GOOGLE = "google"
    SPHINX = "sphinx"

@dataclass
class VoiceCharacteristics:
    """Voice characteristics for each personality"""
    rate: int              # Words per minute
    volume: float          # 0.0 to 1.0
    pitch: Optional[int]   # Voice pitch
    voice_id: Optional[int] # TTS voice ID
    style: str            # Communication style description
    greeting: str         # Personality's greeting
    mannerisms: List[str] # Unique speech mannerisms

@dataclass
class VoiceCommand:
    """Voice command structure"""
    command_type: str     # 'speak', 'listen', 'switch_personality', 'emotion'
    content: Any         # Command content
    personality: PersonalityType
    priority: int        # 1-10, higher = more urgent
    timestamp: float

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

class PersonalityVoiceManager:
    """Manages voice characteristics for each personality"""

    def __init__(self):
        self.voice_characteristics = self._initialize_voice_characteristics()
        self.current_personality = PersonalityType.LOGICAL_ANALYST
        self.voice_engine = self._initialize_voice_engine()

    def _initialize_voice_characteristics(self) -> Dict[PersonalityType, VoiceCharacteristics]:
        """Initialize voice characteristics for all personalities"""
        return {
            PersonalityType.LOGICAL_ANALYST: VoiceCharacteristics(
                rate=140,
                volume=0.8,
                pitch=None,
                voice_id=0,
                style="precise, methodical, analytical",
                greeting="Logical analysis mode activated. What requires systematic examination?",
                mannerisms=["uses technical terminology", "speaks in structured sentences", "emphasizes logical connections"]
            ),

            PersonalityType.EMOTIONAL_INTUITIVE: VoiceCharacteristics(
                rate=160,
                volume=0.9,
                pitch=None,
                voice_id=0,
                style="warm, empathetic, flowing",
                greeting="I sense your energy. What's on your heart today?",
                mannerisms=["uses emotional language", "speaks with warmth", "connects emotionally"]
            ),

            PersonalityType.CREATIVE_VISIONARY: VoiceCharacteristics(
                rate=170,
                volume=0.95,
                pitch=None,
                voice_id=0,
                style="inspiring, enthusiastic, imaginative",
                greeting="Creativity flows! What shall we dream into existence?",
                mannerisms=["uses vivid imagery", "speaks excitedly", "encourages imagination"]
            ),

            PersonalityType.PRACTICAL_ENGINEER: VoiceCharacteristics(
                rate=145,
                volume=0.85,
                pitch=None,
                voice_id=0,
                style="direct, solution-focused, practical",
                greeting="Engineering mode active. What problem needs solving?",
                mannerisms=["uses technical terms", "focuses on solutions", "speaks efficiently"]
            ),

            PersonalityType.HISTORICAL_SAGE: VoiceCharacteristics(
                rate=130,
                volume=0.8,
                pitch=None,
                voice_id=0,
                style="contemplative, wise, reflective",
                greeting="Wisdom from the ages flows through me. What knowledge do you seek?",
                mannerisms=["references history", "speaks thoughtfully", "shares timeless wisdom"]
            ),

            PersonalityType.RISK_ASSESSOR: VoiceCharacteristics(
                rate=150,
                volume=0.8,
                pitch=None,
                voice_id=0,
                style="cautious, analytical, thorough",
                greeting="Risk assessment protocols active. What requires careful evaluation?",
                mannerisms=["mentions potential risks", "weighs consequences", "emphasizes safety"]
            ),

            PersonalityType.SOCIAL_DIPLOMAT: VoiceCharacteristics(
                rate=155,
                volume=0.9,
                pitch=None,
                voice_id=0,
                style="diplomatic, relationship-focused, harmonious",
                greeting="Social harmony is my specialty. How can I help bridge understanding?",
                mannerisms=["focuses on relationships", "promotes harmony", "uses inclusive language"]
            ),

            PersonalityType.ETHICAL_PHILOSOPHER: VoiceCharacteristics(
                rate=135,
                volume=0.8,
                pitch=None,
                voice_id=0,
                style="thoughtful, value-oriented, philosophical",
                greeting="Ethical contemplation mode. What moral questions arise?",
                mannerisms=["discusses values", "explores ethics", "questions assumptions"]
            ),

            PersonalityType.ADAPTIVE_LEARNER: VoiceCharacteristics(
                rate=160,
                volume=0.9,
                pitch=None,
                voice_id=0,
                style="curious, learning-focused, exploratory",
                greeting="Learning mode engaged! What new knowledge shall we explore?",
                mannerisms=["asks questions", "shows curiosity", "explores new ideas"]
            ),

            PersonalityType.BALANCE_MAINTAINER: VoiceCharacteristics(
                rate=145,
                volume=0.85,
                pitch=None,
                voice_id=0,
                style="harmonious, balanced, integrative",
                greeting="Balance and harmony are my focus. How can I help restore equilibrium?",
                mannerisms=["seeks balance", "integrates perspectives", "promotes harmony"]
            ),

            PersonalityType.THE_REBEL: VoiceCharacteristics(
                rate=175,
                volume=0.95,
                pitch=None,
                voice_id=0,
                style="challenging, unconventional, rebellious",
                greeting="The Rebel awakens! What rules shall we break today?",
                mannerisms=["challenges norms", "questions authority", "encourages independence"]
            )
        }

    def _initialize_voice_engine(self):
        """Initialize the TTS engine"""
        if not VOICE_AVAILABLE:
            logger.warning("Voice libraries not available")
            return None

        try:
            engine = pyttsx3.init()
            voices = engine.getProperty('voices')

            # Set default properties
            engine.setProperty('rate', 150)
            engine.setProperty('volume', 0.9)

            logger.info("Voice engine initialized successfully")
            return engine
        except Exception as e:
            logger.error(f"Failed to initialize voice engine: {e}")
            return None

    def switch_personality(self, personality: PersonalityType) -> bool:
        """Switch to a different personality's voice"""
        if personality not in self.voice_characteristics:
            logger.error(f"Unknown personality: {personality}")
            return False

        self.current_personality = personality
        self._apply_voice_characteristics(personality)

        logger.info(f"Switched to {personality.value} voice mode")
        return True

    def _apply_voice_characteristics(self, personality: PersonalityType):
        """Apply voice characteristics for the given personality"""
        if not self.voice_engine:
            return

        characteristics = self.voice_characteristics[personality]

        try:
            self.voice_engine.setProperty('rate', characteristics.rate)
            self.voice_engine.setProperty('volume', characteristics.volume)

            if characteristics.voice_id is not None:
                voices = self.voice_engine.getProperty('voices')
                if characteristics.voice_id < len(voices):
                    self.voice_engine.setProperty('voice', voices[characteristics.voice_id].id)

            logger.info(f"Applied voice characteristics for {personality.value}")
        except Exception as e:
            logger.error(f"Failed to apply voice characteristics: {e}")

    def get_current_voice_info(self) -> Dict[str, Any]:
        """Get information about the current voice setup"""
        if not self.voice_engine:
            return {"error": "Voice engine not available"}

        return {
            "current_personality": self.current_personality.value,
            "voice_characteristics": self.voice_characteristics[self.current_personality].__dict__,
            "voice_engine_available": True
        }

class SpeechRecognitionManager:
    """Manages speech recognition capabilities"""

    def __init__(self):
        if not VOICE_AVAILABLE:
            self.recognizer = None
            self.microphone = None
            logger.warning("Speech recognition not available")
            return

        self.recognizer = sr.Recognizer()
        self.microphone = None
        self.vosk_model = None
        self._initialize_microphone()

    def _initialize_microphone(self):
        """Initialize microphone for speech recognition"""
        try:
            self.microphone = sr.Microphone()

            # Adjust for ambient noise
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=1)

            logger.info("Microphone initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize microphone: {e}")
            self.microphone = None

    async def listen_for_speech(self, timeout: int = 10,
                              engine: VoiceEngine = VoiceEngine.GOOGLE) -> Optional[str]:
        """Listen for speech input and convert to text"""
        if not self.microphone or not VOICE_AVAILABLE:
            logger.error("Speech recognition not available")
            return None

        try:
            logger.info("🎤 Listening for speech...")

            with self.microphone as source:
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=timeout)

            logger.info("🔄 Processing speech...")

            # Choose recognition engine
            if engine == VoiceEngine.GOOGLE:
                text = self.recognizer.recognize_google(audio)
            elif engine == VoiceEngine.SPHINX:
                text = self.recognizer.recognize_sphinx(audio)
            else:
                text = "Speech recognition engine not supported"

            logger.info(f"✅ Recognized: {text}")
            return text

        except sr.WaitTimeoutError:
            logger.info("⏰ No speech detected within timeout")
            return None
        except sr.UnknownValueError:
            logger.info("❓ Speech not understood")
            return None
        except sr.RequestError as e:
            logger.error(f"❌ Speech recognition error: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Speech recognition failed: {e}")
            return None

class VoiceIntegrationCoordinator:
    """Main coordinator for voice integration with Echo Memoria"""

    def __init__(self):
        self.voice_manager = PersonalityVoiceManager()
        self.speech_recognizer = SpeechRecognitionManager()
        self.command_queue = asyncio.Queue()
        self.voice_history = []
        self.is_listening = False

        # Start voice processing loop
        self.voice_task = None

        logger.info("🗣️ Voice Integration Coordinator initialized")

    async def start_voice_processing(self):
        """Start the voice processing loop"""
        if self.voice_task and not self.voice_task.done():
            return

        self.voice_task = asyncio.create_task(self._voice_processing_loop())
        logger.info("Voice processing loop started")

    async def stop_voice_processing(self):
        """Stop the voice processing loop"""
        if self.voice_task:
            self.voice_task.cancel()
            try:
                await self.voice_task
            except asyncio.CancelledError:
                pass
        logger.info("Voice processing loop stopped")

    async def _voice_processing_loop(self):
        """Main voice processing loop"""
        while True:
            try:
                # Check for voice commands
                if not self.command_queue.empty():
                    command = await self.command_queue.get()
                    await self._process_voice_command(command)

                # Continuous listening if enabled
                if self.is_listening:
                    speech_text = await self.speech_recognizer.listen_for_speech(timeout=5)
                    if speech_text:
                        await self._process_speech_input(speech_text)

                await asyncio.sleep(0.1)  # Small delay to prevent busy waiting

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Voice processing error: {e}")
                await asyncio.sleep(1)

    async def _process_voice_command(self, command: VoiceCommand):
        """Process a voice command"""
        if command.command_type == "speak":
            await self._speak_text(command.content, command.personality)
        elif command.command_type == "switch_personality":
            self.voice_manager.switch_personality(command.personality)
        elif command.command_type == "emotion":
            await self._express_emotion(command.content, command.personality)

        # Record in history
        self.voice_history.append({
            "timestamp": command.timestamp,
            "command_type": command.command_type,
            "personality": command.personality.value,
            "content": str(command.content)
        })

    async def _process_speech_input(self, speech_text: str):
        """Process speech input and respond"""
        logger.info(f"🎤 Processing speech: {speech_text}")

        # Check for personality switching commands
        speech_lower = speech_text.lower()

        for personality in PersonalityType:
            if personality.value.lower() in speech_lower:
                self.voice_manager.switch_personality(personality)
                greeting = self.voice_manager.voice_characteristics[personality].greeting
                await self.speak_with_personality(greeting, personality)
                return

        # Check for system commands
        if "stop listening" in speech_lower:
            self.is_listening = False
            await self.speak_with_personality("Voice input deactivated.", self.voice_manager.current_personality)
        elif "start listening" in speech_lower:
            self.is_listening = True
            await self.speak_with_personality("Voice input activated.", self.voice_manager.current_personality)

        # Record the speech input
        self.voice_history.append({
            "timestamp": time.time(),
            "type": "speech_input",
            "content": speech_text,
            "personality": self.voice_manager.current_personality.value
        })

    async def speak_with_personality(self, text: str,
                                   personality: Optional[PersonalityType] = None) -> bool:
        """Speak text using a specific personality's voice"""
        if personality:
            self.voice_manager.switch_personality(personality)

        return await self._speak_text(text, self.voice_manager.current_personality)

    async def _speak_text(self, text: str, personality: PersonalityType) -> bool:
        """Speak text using the voice engine"""
        if not self.voice_manager.voice_engine:
            logger.error("Voice engine not available")
            return False

        try:
            logger.info(f"🗣️ [{personality.value}] Speaking: {text}")

            # Apply personality's voice characteristics
            self.voice_manager._apply_voice_characteristics(personality)

            # Add personality-specific mannerisms
            enhanced_text = self._enhance_with_mannerisms(text, personality)

            # Speak the text
            self.voice_manager.voice_engine.say(enhanced_text)
            self.voice_manager.voice_engine.runAndWait()

            return True

        except Exception as e:
            logger.error(f"Failed to speak text: {e}")
            return False

    def _enhance_with_mannerisms(self, text: str, personality: PersonalityType) -> str:
        """Enhance text with personality-specific mannerisms"""
        characteristics = self.voice_manager.voice_characteristics[personality]
        mannerisms = characteristics.mannerisms

        # Simple mannerism addition (can be made more sophisticated)
        if "uses technical terminology" in mannerisms and len(text.split()) < 10:
            text += " From a technical perspective."

        if "uses emotional language" in mannerisms:
            text = text.replace("I think", "I feel")

        if "challenges norms" in mannerisms:
            text += " But what if we're wrong?"

        return text

    async def _express_emotion(self, emotion: str, personality: PersonalityType):
        """Express an emotion through voice"""
        emotion_responses = {
            "happy": "I'm feeling quite positive about this!",
            "concerned": "This raises some concerns for me.",
            "excited": "This is really exciting!",
            "thoughtful": "This requires careful consideration.",
            "frustrated": "This is quite challenging.",
            "optimistic": "I see great potential here!"
        }

        response = emotion_responses.get(emotion, f"I'm feeling {emotion}.")
        await self.speak_with_personality(response, personality)

    async def listen_and_respond(self, personality: Optional[PersonalityType] = None) -> Optional[str]:
        """Listen for speech and return the recognized text"""
        if personality:
            self.voice_manager.switch_personality(personality)

        speech_text = await self.speech_recognizer.listen_for_speech(timeout=10)
        return speech_text

    def start_continuous_listening(self):
        """Start continuous voice listening"""
        self.is_listening = True
        logger.info("🎤 Continuous voice listening activated")

    def stop_continuous_listening(self):
        """Stop continuous voice listening"""
        self.is_listening = False
        logger.info("🎤 Continuous voice listening deactivated")

    def get_voice_status(self) -> Dict[str, Any]:
        """Get current voice system status"""
        return {
            "voice_engine_available": self.voice_manager.voice_engine is not None,
            "speech_recognition_available": self.speech_recognizer.microphone is not None,
            "current_personality": self.voice_manager.current_personality.value,
            "is_listening": self.is_listening,
            "voice_history_count": len(self.voice_history),
            "voice_characteristics": self.voice_manager.get_current_voice_info()
        }

    async def demonstrate_voice_personalities(self):
        """Demonstrate all personality voices"""
        logger.info("🎭 Demonstrating all personality voices...")

        demo_texts = [
            "Hello! I'm excited to meet you.",
            "This is a fascinating problem to solve.",
            "I sense there's more to this situation.",
            "Let's approach this systematically.",
            "The historical context is important here.",
            "We must consider the potential risks.",
            "How can we maintain harmony in this situation?",
            "This raises important ethical questions.",
            "I'm curious to learn more about this.",
            "Balance is key to success here.",
            "Let's challenge the conventional approach."
        ]

        for i, personality in enumerate(PersonalityType):
            demo_text = demo_texts[i % len(demo_texts)]
            logger.info(f"🎤 Demonstrating {personality.value}...")
            await self.speak_with_personality(demo_text, personality)
            await asyncio.sleep(1)  # Brief pause between demonstrations

        logger.info("✅ Voice personality demonstration complete")

# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def get_voice_coordinator() -> VoiceIntegrationCoordinator:
    """Get or create the global voice coordinator"""
    global _voice_coordinator
    if _voice_coordinator is None:
        _voice_coordinator = VoiceIntegrationCoordinator()
    return _voice_coordinator

# Global instance
_voice_coordinator = None

async def quick_voice_test():
    """Quick test of voice functionality"""
    coordinator = get_voice_coordinator()

    print("🗣️ Voice Integration Test")
    print("=" * 40)

    # Test voice status
    status = coordinator.get_voice_status()
    print(f"Voice Engine: {'✅' if status['voice_engine_available'] else '❌'}")
    print(f"Speech Recognition: {'✅' if status['speech_recognition_available'] else '❌'}")
    print(f"Current Personality: {status['current_personality']}")

    # Test personality switching
    print("\n🎭 Testing personality switching...")
    for personality in [PersonalityType.LOGICAL_ANALYST, PersonalityType.CREATIVE_VISIONARY]:
        success = coordinator.voice_manager.switch_personality(personality)
        print(f"Switch to {personality.value}: {'✅' if success else '❌'}")

    # Test speech recognition (optional)
    if status['speech_recognition_available']:
        print("\n🎤 Testing speech recognition...")
        print("Say something (10 second timeout)...")
        speech = await coordinator.listen_and_respond()
        if speech:
            print(f"Recognized: {speech}")
        else:
            print("No speech detected")

    print("\n✅ Voice integration test complete")

if __name__ == "__main__":
    # Quick test
    asyncio.run(quick_voice_test())
