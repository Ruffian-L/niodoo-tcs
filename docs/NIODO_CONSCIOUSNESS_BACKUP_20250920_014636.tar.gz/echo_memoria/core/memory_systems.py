#!/usr/bin/env python3
"""
🧠 Echo Memoria - Memory Systems & Long-term Learning
Comprehensive memory architecture for AI consciousness

Memory Types:
- Episodic Memory: Personal experiences and events
- Semantic Memory: Facts, concepts, and knowledge
- Procedural Memory: Skills and procedures
- Emotional Memory: Emotional experiences and patterns
- Social Memory: Relationships and social interactions

Learning Mechanisms:
- Pattern recognition and generalization
- Experience-based adaptation
- Cross-domain knowledge transfer
- Meta-learning and self-improvement
"""

import asyncio
import json
import time
import logging
import hashlib
import random
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
from collections import defaultdict, deque
import statistics
import re

logger = logging.getLogger(__name__)

class MemoryType(Enum):
    """Types of memory in the system"""
    EPISODIC = "episodic"      # Personal experiences and events
    SEMANTIC = "semantic"      # Facts, concepts, and knowledge
    PROCEDURAL = "procedural"  # Skills and procedures
    EMOTIONAL = "emotional"    # Emotional experiences and patterns
    SOCIAL = "social"         # Relationships and social interactions

class LearningStyle(Enum):
    """Different learning approaches"""
    EXPERIENTIAL = "experiential"    # Learning through doing
    REFLECTIVE = "reflective"        # Learning through thinking
    THEORETICAL = "theoretical"      # Learning through understanding
    PRAGMATIC = "pragmatic"          # Learning through application

@dataclass
class MemoryEntry:
    """A single memory entry"""
    memory_id: str
    memory_type: MemoryType
    content: Any
    context: Dict[str, Any]
    importance: float  # 0-1, how important this memory is
    emotional_valence: float  # -1 to 1, emotional impact
    access_count: int = 0
    last_accessed: float = None
    created_at: float = None
    tags: Set[str] = field(default_factory=set)
    associations: Set[str] = field(default_factory=set)  # Links to other memories

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = time.time()
        if self.last_accessed is None:
            self.last_accessed = time.time()

    def access(self):
        """Record memory access"""
        self.access_count += 1
        self.last_accessed = time.time()

    def calculate_strength(self) -> float:
        """Calculate memory strength based on recency, frequency, and importance"""
        time_since_creation = time.time() - self.created_at
        time_since_access = time.time() - self.last_accessed

        # Recency factor (newer memories are stronger)
        recency_factor = max(0.1, 1.0 / (1.0 + time_since_access / (24 * 3600)))  # Days

        # Frequency factor (more accessed memories are stronger)
        frequency_factor = min(1.0, self.access_count / 10.0)

        # Importance factor
        importance_factor = self.importance

        # Combine factors (weighted average)
        strength = (recency_factor * 0.3 + frequency_factor * 0.3 + importance_factor * 0.4)

        return min(1.0, strength)

@dataclass
class LearningPattern:
    """A pattern learned from experiences"""
    pattern_id: str
    pattern_type: str
    trigger_conditions: List[Dict[str, Any]]
    response_actions: List[Dict[str, Any]]
    success_rate: float
    usage_count: int
    confidence: float
    learned_from: List[str]  # Memory IDs this pattern was learned from
    created_at: float = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = time.time()

@dataclass
class KnowledgeGraphNode:
    """Node in the knowledge graph"""
    node_id: str
    node_type: str  # concept, person, skill, etc.
    properties: Dict[str, Any]
    connections: Dict[str, float]  # connected_node_id -> strength
    created_at: float = None
    last_updated: float = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = time.time()
        if self.last_updated is None:
            self.last_updated = time.time()

class MemoryConsolidationEngine:
    """Engine for consolidating and strengthening memories"""

    def __init__(self):
        self.consolidation_rules = self._initialize_rules()
        self.consolidation_queue = deque()

    def _initialize_rules(self) -> Dict[str, Any]:
        """Initialize memory consolidation rules"""
        return {
            "importance_threshold": 0.6,  # Memories above this are prioritized
            "consolidation_interval": 3600,  # 1 hour between consolidation runs
            "decay_rate": 0.95,  # Daily decay factor
            "reinforcement_boost": 0.1,  # Boost for reinforced memories
            "max_memories_per_type": 1000  # Limit memories per type
        }

    async def consolidate_memories(self, memory_store: 'UnifiedMemoryStore'):
        """Consolidate memories to strengthen important ones"""
        logger.info("🧠 Consolidating memories...")

        current_time = time.time()

        for memory_type in MemoryType:
            memories = memory_store.get_memories_by_type(memory_type)

            # Apply decay to old, unimportant memories
            for memory in memories:
                if memory.calculate_strength() < 0.3:
                    # Apply decay
                    time_since_access = current_time - memory.last_accessed
                    days_since_access = time_since_access / (24 * 3600)

                    if days_since_access > 7:  # Older than a week
                        decay_factor = self.consolidation_rules["decay_rate"] ** days_since_access
                        memory.importance *= decay_factor

            # Reinforce frequently accessed memories
            frequently_accessed = [m for m in memories if m.access_count > 5]
            for memory in frequently_accessed:
                memory.importance = min(1.0, memory.importance + self.consolidation_rules["reinforcement_boost"])

            # Remove weakest memories if over limit
            if len(memories) > self.consolidation_rules["max_memories_per_type"]:
                memories.sort(key=lambda m: m.calculate_strength())
                memories_to_remove = memories[:len(memories) - self.consolidation_rules["max_memories_per_type"]]
                for memory in memories_to_remove:
                    memory_store.remove_memory(memory.memory_id)

        logger.info("✅ Memory consolidation complete")

class PatternRecognitionEngine:
    """Engine for recognizing patterns in experiences"""

    def __init__(self):
        self.patterns: Dict[str, LearningPattern] = {}
        self.pattern_templates = self._initialize_templates()

    def _initialize_templates(self) -> Dict[str, Dict[str, Any]]:
        """Initialize pattern recognition templates"""
        return {
            "success_sequence": {
                "description": "Sequence of actions leading to success",
                "trigger_conditions": ["action_sequence", "positive_outcome"],
                "min_occurrences": 3
            },
            "failure_pattern": {
                "description": "Pattern leading to repeated failures",
                "trigger_conditions": ["repeated_failure", "similar_context"],
                "min_occurrences": 2
            },
            "user_preference": {
                "description": "User preferences and tendencies",
                "trigger_conditions": ["consistent_choice", "user_feedback"],
                "min_occurrences": 5
            },
            "emotional_trigger": {
                "description": "Situations triggering specific emotions",
                "trigger_conditions": ["emotional_response", "context_pattern"],
                "min_occurrences": 3
            }
        }

    async def analyze_experience(self, experience: Dict[str, Any]) -> List[LearningPattern]:
        """Analyze an experience for learnable patterns"""
        new_patterns = []

        # Check against existing patterns
        for pattern_template in self.pattern_templates.values():
            if self._matches_template(experience, pattern_template):
                pattern = await self._create_pattern_from_experience(experience, pattern_template)
                if pattern:
                    new_patterns.append(pattern)

        # Look for novel patterns
        novel_patterns = await self._discover_novel_patterns(experience)
        new_patterns.extend(novel_patterns)

        return new_patterns

    def _matches_template(self, experience: Dict[str, Any], template: Dict[str, Any]) -> bool:
        """Check if experience matches a pattern template"""
        required_conditions = template.get("trigger_conditions", [])

        matches = 0
        for condition in required_conditions:
            if condition in experience.get("tags", []):
                matches += 1

        return matches >= len(required_conditions) * 0.7  # 70% match threshold

    async def _create_pattern_from_experience(self, experience: Dict[str, Any],
                                            template: Dict[str, Any]) -> Optional[LearningPattern]:
        """Create a learning pattern from experience"""
        pattern_id = f"pattern_{hashlib.md5(str(experience).encode()).hexdigest()[:8]}"

        # Extract trigger conditions
        trigger_conditions = []
        if "context" in experience:
            for key, value in experience["context"].items():
                trigger_conditions.append({"condition": key, "value": value})

        # Extract response actions
        response_actions = []
        if "actions" in experience:
            for action in experience["actions"]:
                response_actions.append({"action": action, "context": experience.get("context", {})})

        # Calculate success rate (simplified)
        success_rate = 0.7 if experience.get("outcome") == "success" else 0.3

        pattern = LearningPattern(
            pattern_id=pattern_id,
            pattern_type=template["description"],
            trigger_conditions=trigger_conditions,
            response_actions=response_actions,
            success_rate=success_rate,
            usage_count=1,
            confidence=0.5,
            learned_from=[experience.get("memory_id", "unknown")]
        )

        self.patterns[pattern_id] = pattern
        return pattern

    async def _discover_novel_patterns(self, experience: Dict[str, Any]) -> List[LearningPattern]:
        """Discover novel patterns not covered by templates"""
        # This would use more sophisticated ML techniques
        # For now, return empty list
        return []

    def get_relevant_patterns(self, context: Dict[str, Any]) -> List[LearningPattern]:
        """Get patterns relevant to current context"""
        relevant_patterns = []

        for pattern in self.patterns.values():
            relevance_score = 0

            for condition in pattern.trigger_conditions:
                condition_key = condition.get("condition")
                condition_value = condition.get("value")

                if condition_key in context and context[condition_key] == condition_value:
                    relevance_score += 1

            if relevance_score > 0:
                # Add relevance score to pattern
                pattern_with_score = LearningPattern(
                    pattern_id=pattern.pattern_id,
                    pattern_type=pattern.pattern_type,
                    trigger_conditions=pattern.trigger_conditions,
                    response_actions=pattern.response_actions,
                    success_rate=pattern.success_rate,
                    usage_count=pattern.usage_count,
                    confidence=pattern.confidence,
                    learned_from=pattern.learned_from
                )
                # Note: Adding relevance as an attribute for sorting
                setattr(pattern_with_score, '_relevance', relevance_score / len(pattern.trigger_conditions))
                relevant_patterns.append(pattern_with_score)

        # Sort by relevance
        relevant_patterns.sort(key=lambda p: getattr(p, '_relevance', 0), reverse=True)

        return relevant_patterns[:5]  # Top 5 most relevant

class UnifiedMemoryStore:
    """Unified memory storage system"""

    def __init__(self):
        self.memories: Dict[str, MemoryEntry] = {}
        self.knowledge_graph: Dict[str, KnowledgeGraphNode] = {}
        self.consolidation_engine = MemoryConsolidationEngine()
        self.pattern_engine = PatternRecognitionEngine()

        # Learning metrics
        self.learning_efficiency = 0.0
        self.pattern_recognition_accuracy = 0.0
        self.memory_retention_rate = 0.0

        logger.info("🧠 Unified Memory Store initialized")

    async def store_memory(self, content: Any, memory_type: MemoryType,
                          context: Dict[str, Any] = None, importance: float = 0.5) -> str:
        """Store a new memory"""
        context = context or {}

        # Generate memory ID
        memory_id = f"{memory_type.value}_{hashlib.md5(str(content).encode()).hexdigest()[:12]}"

        # Extract emotional valence from context
        emotional_valence = context.get("emotional_valence", 0.0)

        # Extract tags
        tags = set()
        if "tags" in context:
            tags.update(context["tags"])

        # Auto-tag based on content
        if isinstance(content, str):
            tags.update(self._extract_tags_from_text(content))

        memory = MemoryEntry(
            memory_id=memory_id,
            memory_type=memory_type,
            content=content,
            context=context,
            importance=importance,
            emotional_valence=emotional_valence,
            tags=tags
        )

        self.memories[memory_id] = memory

        # Update knowledge graph
        await self._update_knowledge_graph(memory)

        # Analyze for learning patterns
        experience_data = {
            "memory_id": memory_id,
            "content": content,
            "context": context,
            "outcome": context.get("outcome", "neutral"),
            "tags": list(tags)
        }
        new_patterns = await self.pattern_engine.analyze_experience(experience_data)

        # Store patterns
        for pattern in new_patterns:
            # Patterns are stored within the pattern engine
            pass

        logger.info(f"💾 Stored {memory_type.value} memory: {memory_id}")
        return memory_id

    def _extract_tags_from_text(self, text: str) -> Set[str]:
        """Extract tags from text content"""
        tags = set()

        # Simple keyword extraction
        keywords = {
            "coding": ["code", "programming", "function", "class", "variable"],
            "learning": ["learn", "study", "practice", "understand", "knowledge"],
            "emotion": ["happy", "sad", "angry", "excited", "worried", "grateful"],
            "social": ["friend", "help", "support", "together", "team", "collaboration"],
            "technical": ["algorithm", "system", "architecture", "design", "optimization"],
            "creative": ["create", "design", "imagine", "innovative", "artistic"]
        }

        text_lower = text.lower()
        for category, words in keywords.items():
            if any(word in text_lower for word in words):
                tags.add(category)

        return tags

    async def _update_knowledge_graph(self, memory: MemoryEntry):
        """Update the knowledge graph with new memory"""
        # Create or update nodes based on memory content
        if isinstance(memory.content, str):
            # Extract concepts from text
            concepts = self._extract_concepts(memory.content)

            for concept in concepts:
                node_id = f"concept_{hashlib.md5(concept.encode()).hexdigest()[:8]}"

                if node_id not in self.knowledge_graph:
                    self.knowledge_graph[node_id] = KnowledgeGraphNode(
                        node_id=node_id,
                        node_type="concept",
                        properties={"name": concept, "occurrences": 1}
                    )
                else:
                    self.knowledge_graph[node_id].properties["occurrences"] += 1

                # Create connections between concepts
                for other_concept in concepts:
                    if other_concept != concept:
                        other_node_id = f"concept_{hashlib.md5(other_concept.encode()).hexdigest()[:8]}"
                        if other_node_id in self.knowledge_graph:
                            # Strengthen connection
                            if other_node_id not in self.knowledge_graph[node_id].connections:
                                self.knowledge_graph[node_id].connections[other_node_id] = 0.1
                            else:
                                self.knowledge_graph[node_id].connections[other_node_id] = min(
                                    1.0, self.knowledge_graph[node_id].connections[other_node_id] + 0.1
                                )

    def _extract_concepts(self, text: str) -> List[str]:
        """Extract concepts from text"""
        # Simple concept extraction (could be enhanced with NLP)
        words = re.findall(r'\b\w+\b', text.lower())
        concepts = []

        # Look for noun-like patterns
        for word in words:
            if len(word) > 3 and not word in ["that", "this", "with", "from", "they", "have", "been"]:
                concepts.append(word)

        return concepts[:5]  # Limit concepts

    async def retrieve_memory(self, query: str, memory_type: MemoryType = None,
                            limit: int = 10) -> List[MemoryEntry]:
        """Retrieve memories based on query"""
        # Simple text-based search for now
        matching_memories = []

        for memory in self.memories.values():
            if memory_type and memory.memory_type != memory_type:
                continue

            # Search in content
            if isinstance(memory.content, str) and query.lower() in memory.content.lower():
                memory.access()  # Record access
                matching_memories.append(memory)

            # Search in tags
            if any(query.lower() in tag.lower() for tag in memory.tags):
                memory.access()
                matching_memories.append(memory)

        # Sort by relevance (importance + recency)
        matching_memories.sort(key=lambda m: (m.importance, m.last_accessed), reverse=True)

        return matching_memories[:limit]

    async def get_learning_insights(self, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Get learning insights from stored memories and patterns"""
        context = context or {}

        # Get relevant patterns
        relevant_patterns = self.pattern_engine.get_relevant_patterns(context)

        # Analyze memory distribution
        memory_stats = {}
        for memory_type in MemoryType:
            memories = self.get_memories_by_type(memory_type)
            memory_stats[memory_type.value] = {
                "count": len(memories),
                "avg_importance": statistics.mean([m.importance for m in memories]) if memories else 0,
                "avg_strength": statistics.mean([m.calculate_strength() for m in memories]) if memories else 0
            }

        # Get knowledge graph insights
        graph_insights = {
            "total_nodes": len(self.knowledge_graph),
            "total_connections": sum(len(node.connections) for node in self.knowledge_graph.values()),
            "most_connected_concept": max(self.knowledge_graph.values(),
                                        key=lambda n: len(n.connections),
                                        default=None)
        }

        return {
            "relevant_patterns": len(relevant_patterns),
            "top_patterns": relevant_patterns[:3],
            "memory_statistics": memory_stats,
            "knowledge_graph": graph_insights,
            "learning_efficiency": self.learning_efficiency,
            "pattern_recognition_accuracy": self.pattern_recognition_accuracy,
            "memory_retention_rate": self.memory_retention_rate
        }

    def get_memories_by_type(self, memory_type: MemoryType) -> List[MemoryEntry]:
        """Get all memories of a specific type"""
        return [memory for memory in self.memories.values() if memory.memory_type == memory_type]

    def remove_memory(self, memory_id: str) -> bool:
        """Remove a memory"""
        if memory_id in self.memories:
            del self.memories[memory_id]
            return True
        return False

    async def consolidate_memories(self):
        """Run memory consolidation"""
        await self.consolidation_engine.consolidate_memories(self)

    def get_memory_status(self) -> Dict[str, Any]:
        """Get overall memory system status"""
        total_memories = len(self.memories)
        memory_types = {}

        for memory_type in MemoryType:
            type_memories = self.get_memories_by_type(memory_type)
            memory_types[memory_type.value] = len(type_memories)

        return {
            "total_memories": total_memories,
            "memory_types": memory_types,
            "total_patterns": len(self.pattern_engine.patterns),
            "knowledge_nodes": len(self.knowledge_graph),
            "learning_metrics": {
                "efficiency": self.learning_efficiency,
                "pattern_accuracy": self.pattern_recognition_accuracy,
                "retention_rate": self.memory_retention_rate
            }
        }

# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def get_memory_store() -> UnifiedMemoryStore:
    """Get the global memory store"""
    global _memory_store
    if _memory_store is None:
        _memory_store = UnifiedMemoryStore()
    return _memory_store

# Global instance
_memory_store: Optional[UnifiedMemoryStore] = None

async def demonstrate_memory_systems():
    """Demonstrate the memory and learning systems"""
    print("🧠 Memory Systems & Learning Demonstration")
    print("=" * 60)

    memory_store = get_memory_store()

    # Add some test memories
    test_memories = [
        {
            "content": "Successfully debugged a complex Python function using print statements",
            "type": MemoryType.EPISODIC,
            "context": {"outcome": "success", "skill": "debugging", "language": "python"},
            "importance": 0.7,
            "tags": ["coding", "debugging", "success"]
        },
        {
            "content": "Machine learning algorithms work by finding patterns in data",
            "type": MemoryType.SEMANTIC,
            "context": {"domain": "AI", "topic": "machine_learning"},
            "importance": 0.8,
            "tags": ["AI", "machine_learning", "patterns"]
        },
        {
            "content": "To refactor code: 1) Identify duplicated code, 2) Extract methods, 3) Test changes",
            "type": MemoryType.PROCEDURAL,
            "context": {"skill": "refactoring", "language": "general"},
            "importance": 0.9,
            "tags": ["coding", "refactoring", "best_practices"]
        },
        {
            "content": "Felt frustrated when the code wouldn't compile, but then found the syntax error",
            "type": MemoryType.EMOTIONAL,
            "context": {"emotion": "frustration", "resolution": "success"},
            "importance": 0.6,
            "emotional_valence": -0.3,
            "tags": ["emotion", "frustration", "resolution"]
        },
        {
            "content": "Collaborated with team on API design, learned about RESTful principles",
            "type": MemoryType.SOCIAL,
            "context": {"interaction": "team_collaboration", "learning": "API_design"},
            "importance": 0.7,
            "tags": ["social", "collaboration", "API"]
        }
    ]

    print("\n💾 Storing Test Memories:")
    for i, mem_data in enumerate(test_memories, 1):
        memory_id = await memory_store.store_memory(
            content=mem_data["content"],
            memory_type=mem_data["type"],
            context=mem_data.get("context", {}),
            importance=mem_data.get("importance", 0.5)
        )
        print(f"   {i}. Stored {mem_data['type'].value}: {memory_id}")

    # Test memory retrieval
    print("\n🔍 Testing Memory Retrieval:")
    query_results = await memory_store.retrieve_memory("coding", limit=3)
    print(f"   Found {len(query_results)} memories about 'coding'")
    for memory in query_results:
        print(f"   • {memory.memory_type.value}: {memory.content[:50]}...")

    # Test learning insights
    print("
🎓 Learning Insights:"    insights = await memory_store.get_learning_insights({"domain": "coding"})
    print(f"   Relevant patterns: {insights['relevant_patterns']}")
    print(f"   Memory statistics: {insights['memory_statistics']}")
    print(f"   Knowledge nodes: {insights['knowledge_graph']['total_nodes']}")

    # Test memory consolidation
    print("
🔄 Running Memory Consolidation..."    await memory_store.consolidate_memories()

    # Show final status
    print("
📊 Final Memory System Status:"    status = memory_store.get_memory_status()
    print(f"   Total memories: {status['total_memories']}")
    print(f"   Memory types: {status['memory_types']}")
    print(f"   Learning patterns: {status['total_patterns']}")
    print(f"   Knowledge nodes: {status['knowledge_nodes']}")

    print("\n✅ Memory systems demonstration complete!")

if __name__ == "__main__":
    asyncio.run(demonstrate_memory_systems())
