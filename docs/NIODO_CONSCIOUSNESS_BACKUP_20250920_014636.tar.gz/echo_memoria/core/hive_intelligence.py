#!/usr/bin/env python3
"""
🐝 Echo Memoria - Hive Intelligence & Swarm Decision-Making
Collective consciousness where multiple AI instances collaborate

Features:
- Swarm coordination algorithms
- Collective decision making
- Emergent intelligence patterns
- Hive mind consensus building
- Distributed problem solving
"""

import asyncio
import json
import time
import random
import logging
import threading
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
import statistics
import math

# Import Echo Memoria components
from echo_memoria.core.multi_personality_brain import MultiPersonalityBrain, PersonalityType
from echo_memoria.core.brain_systems import get_brain_orchestrator, BrainSignal

logger = logging.getLogger(__name__)

class SwarmRole(Enum):
    """Roles within the swarm intelligence"""
    SCOUT = "scout"              # Explores new ideas and approaches
    WORKER = "worker"            # Executes tasks and refines solutions
    GUARD = "guard"              # Protects against poor decisions
    QUEEN = "queen"              # Coordinates overall swarm activity
    DRONE = "drone"              # Provides computational power

class SwarmState(Enum):
    """States of swarm activity"""
    IDLE = "idle"
    EXPLORING = "exploring"
    WORKING = "working"
    DECIDING = "deciding"
    LEARNING = "learning"
    ALERT = "alert"

@dataclass
class SwarmAgent:
    """Individual agent in the swarm"""
    agent_id: str
    role: SwarmRole
    personality: PersonalityType
    energy_level: float = 1.0
    contribution_score: float = 0.0
    last_active: float = 0.0
    specialization: str = ""
    pheromone_trail: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        if self.last_active == 0.0:
            self.last_active = time.time()

    def update_activity(self):
        """Update last activity timestamp"""
        self.last_active = time.time()

    def contribute(self, contribution: Dict[str, Any]):
        """Record a contribution and update score"""
        self.contribution_score += contribution.get('value', 0.1)
        self.energy_level = max(0.1, self.energy_level - 0.05)  # Small energy cost
        self.update_activity()

        # Add to pheromone trail
        self.pheromone_trail.append({
            "timestamp": time.time(),
            "contribution": contribution,
            "energy_after": self.energy_level
        })

        # Keep trail limited
        if len(self.pheromone_trail) > 20:
            self.pheromone_trail.pop(0)

@dataclass
class SwarmDecision:
    """A decision made by the swarm"""
    decision_id: str
    problem: str
    options: List[str]
    swarm_votes: Dict[str, List[str]]  # option -> list of agent_ids
    consensus_option: str
    confidence: float
    swarm_size: int
    decision_time: float
    emergent_insights: List[str]

@dataclass
class PheromoneSignal:
    """Chemical-like communication signal"""
    signal_type: str
    source_agent: str
    target_agents: List[str]
    content: Any
    strength: float = 1.0
    decay_rate: float = 0.1
    timestamp: float = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

    def get_current_strength(self) -> float:
        """Get current signal strength based on decay"""
        age = time.time() - self.timestamp
        return max(0, self.strength * math.exp(-self.decay_rate * age))

class SwarmCoordinator:
    """Coordinates swarm intelligence activities"""

    def __init__(self, swarm_size: int = 50):
        self.swarm_size = swarm_size
        self.agents: Dict[str, SwarmAgent] = {}
        self.pheromone_signals: List[PheromoneSignal] = []
        self.swarm_state = SwarmState.IDLE
        self.decision_history: List[SwarmDecision] = []

        # Swarm intelligence metrics
        self.collective_iq = 1.0
        self.emergence_factor = 0.0
        self.cohesion_level = 1.0

        self._initialize_swarm()
        logger.info(f"🐝 Swarm Coordinator initialized with {swarm_size} agents")

    def _initialize_swarm(self):
        """Initialize the swarm with diverse agents"""
        # Role distribution (queen is unique, others distributed)
        role_distribution = {
            SwarmRole.QUEEN: 1,
            SwarmRole.SCOUT: int(self.swarm_size * 0.2),
            SwarmRole.WORKER: int(self.swarm_size * 0.5),
            SwarmRole.GUARD: int(self.swarm_size * 0.2),
            SwarmRole.DRONE: int(self.swarm_size * 0.1)
        }

        agent_id = 0

        for role, count in role_distribution.items():
            for i in range(count):
                # Assign personality based on role
                personality = self._assign_personality_to_role(role, i)

                agent = SwarmAgent(
                    agent_id=f"swarm_{agent_id}",
                    role=role,
                    personality=personality,
                    specialization=self._get_role_specialization(role)
                )

                self.agents[agent.agent_id] = agent
                agent_id += 1

    def _assign_personality_to_role(self, role: SwarmRole, index: int) -> PersonalityType:
        """Assign appropriate personality to role"""
        role_personalities = {
            SwarmRole.QUEEN: [PersonalityType.BALANCE_MAINTAINER, PersonalityType.SOCIAL_DIPLOMAT],
            SwarmRole.SCOUT: [PersonalityType.CREATIVE_VISIONARY, PersonalityType.THE_REBEL, PersonalityType.ADAPTIVE_LEARNER],
            SwarmRole.WORKER: [PersonalityType.PRACTICAL_ENGINEER, PersonalityType.LOGICAL_ANALYST],
            SwarmRole.GUARD: [PersonalityType.RISK_ASSESSOR, PersonalityType.ETHICAL_PHILOSOPHER],
            SwarmRole.DRONE: [PersonalityType.LOGICAL_ANALYST, PersonalityType.PRACTICAL_ENGINEER]
        }

        available = role_personalities.get(role, [PersonalityType.LOGICAL_ANALYST])
        return available[index % len(available)]

    def _get_role_specialization(self, role: SwarmRole) -> str:
        """Get specialization for a role"""
        specializations = {
            SwarmRole.QUEEN: "coordination and harmony",
            SwarmRole.SCOUT: "exploration and innovation",
            SwarmRole.WORKER: "execution and refinement",
            SwarmRole.GUARD: "protection and validation",
            SwarmRole.DRONE: "computation and processing"
        }
        return specializations.get(role, "general assistance")

    async def process_swarm_decision(self, problem: str, options: List[str],
                                   urgency: float = 0.5) -> SwarmDecision:
        """Process a decision through swarm intelligence"""
        start_time = time.time()
        decision_id = f"swarm_decision_{int(time.time() * 1000)}"

        logger.info(f"🐝 Swarm processing decision: {problem[:50]}...")

        # Activate swarm
        self.swarm_state = SwarmState.DECIDING

        # Phase 1: Exploration (Scouts explore options)
        exploration_results = await self._exploration_phase(problem, options)

        # Phase 2: Evaluation (Guards evaluate risks)
        evaluation_results = await self._evaluation_phase(exploration_results)

        # Phase 3: Refinement (Workers refine solutions)
        refinement_results = await self._refinement_phase(evaluation_results)

        # Phase 4: Consensus (Queen coordinates final decision)
        final_decision = await self._consensus_phase(refinement_results, options)

        # Calculate swarm metrics
        confidence = self._calculate_swarm_confidence(final_decision)
        emergent_insights = self._extract_emergent_insights(final_decision)

        decision = SwarmDecision(
            decision_id=decision_id,
            problem=problem,
            options=options,
            swarm_votes=final_decision.get("votes", {}),
            consensus_option=final_decision.get("chosen_option", options[0]),
            confidence=confidence,
            swarm_size=len(self.agents),
            decision_time=time.time() - start_time,
            emergent_insights=emergent_insights
        )

        # Record decision
        self.decision_history.append(decision)
        self._update_swarm_learning(decision)

        # Return to idle state
        self.swarm_state = SwarmState.IDLE

        logger.info(f"🐝 Swarm decision complete: {decision.consensus_option} (confidence: {confidence:.2f})")
        return decision

    async def _exploration_phase(self, problem: str, options: List[str]) -> Dict[str, Any]:
        """Exploration phase - Scouts explore different approaches"""
        logger.info("🔍 Swarm exploration phase...")

        scouts = [agent for agent in self.agents.values() if agent.role == SwarmRole.SCOUT]
        exploration_tasks = []

        for scout in scouts:
            task = self._scout_explore_option(scout, problem, options)
            exploration_tasks.append(task)

        # Process exploration in parallel
        exploration_results = await asyncio.gather(*exploration_tasks)

        # Aggregate results
        aggregated = {}
        for result in exploration_results:
            for option, insights in result.items():
                if option not in aggregated:
                    aggregated[option] = []
                aggregated[option].extend(insights)

        return aggregated

    async def _scout_explore_option(self, scout: SwarmAgent, problem: str, options: List[str]) -> Dict[str, List[str]]:
        """Individual scout explores options"""
        results = {}

        for option in options:
            # Simulate exploration based on scout's personality
            insights = await self._generate_scout_insights(scout, problem, option)
            results[option] = insights

            # Update scout's contribution
            scout.contribute({"type": "exploration", "option": option, "value": 0.1})

        return results

    async def _generate_scout_insights(self, scout: SwarmAgent, problem: str, option: str) -> List[str]:
        """Generate insights from a scout's exploration"""
        # Personality-based insight generation
        personality_insights = {
            PersonalityType.CREATIVE_VISIONARY: [
                f"Imagine {option} revolutionizing {problem}",
                f"{option} could open creative pathways",
                f"Visions suggest {option} leads to breakthrough"
            ],
            PersonalityType.THE_REBEL: [
                f"{option} challenges conventional {problem} approaches",
                f"Breaking norms with {option}",
                f"Radical potential in {option}"
            ],
            PersonalityType.ADAPTIVE_LEARNER: [
                f"Learning opportunities in {option} for {problem}",
                f"Adaptive approach: {option}",
                f"Growth potential with {option}"
            ]
        }

        base_insights = personality_insights.get(scout.personality, [f"Exploring {option} for {problem}"])
        return random.sample(base_insights, min(2, len(base_insights)))

    async def _evaluation_phase(self, exploration_results: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluation phase - Guards assess risks and validity"""
        logger.info("🛡️ Swarm evaluation phase...")

        guards = [agent for agent in self.agents.values() if agent.role == SwarmRole.GUARD]

        evaluation_results = {}

        for option, insights in exploration_results.items():
            option_evaluations = []

            for guard in guards:
                evaluation = await self._guard_evaluate_option(guard, option, insights)
                option_evaluations.append(evaluation)
                guard.contribute({"type": "evaluation", "option": option, "value": 0.15})

            evaluation_results[option] = option_evaluations

        return evaluation_results

    async def _guard_evaluate_option(self, guard: SwarmAgent, option: str, insights: List[str]) -> Dict[str, Any]:
        """Guard evaluates an option for risks and validity"""
        # Personality-based risk assessment
        risk_assessments = {
            PersonalityType.RISK_ASSESSOR: {
                "risk_level": random.uniform(0.3, 0.8),
                "concerns": ["Potential implementation challenges", "Resource requirements"],
                "safeguards": ["Risk mitigation strategies", "Contingency plans"]
            },
            PersonalityType.ETHICAL_PHILOSOPHER: {
                "risk_level": random.uniform(0.2, 0.6),
                "concerns": ["Ethical implications", "Moral considerations"],
                "safeguards": ["Ethical frameworks", "Value alignment checks"]
            }
        }

        assessment = risk_assessments.get(guard.personality, {
            "risk_level": random.uniform(0.4, 0.7),
            "concerns": ["General evaluation needed"],
            "safeguards": ["Standard procedures"]
        })

        return {
            "option": option,
            "evaluator": guard.agent_id,
            "risk_assessment": assessment,
            "validity_score": 1.0 - assessment["risk_level"],
            "recommendations": assessment["safeguards"]
        }

    async def _refinement_phase(self, evaluation_results: Dict[str, Any]) -> Dict[str, Any]:
        """Refinement phase - Workers refine and improve solutions"""
        logger.info("🔧 Swarm refinement phase...")

        workers = [agent for agent in self.agents.values() if agent.role == SwarmRole.WORKER]

        refinement_results = {}

        for option, evaluations in evaluation_results.items():
            worker_improvements = []

            for worker in workers:
                improvement = await self._worker_refine_option(worker, option, evaluations)
                worker_improvements.append(improvement)
                worker.contribute({"type": "refinement", "option": option, "value": 0.2})

            refinement_results[option] = worker_improvements

        return refinement_results

    async def _worker_refine_option(self, worker: SwarmAgent, option: str, evaluations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Worker refines an option based on evaluations"""
        # Calculate average validity and risk
        validity_scores = [eval["validity_score"] for eval in evaluations]
        avg_validity = statistics.mean(validity_scores) if validity_scores else 0.5

        # Generate refinements based on personality
        refinements = {
            PersonalityType.PRACTICAL_ENGINEER: {
                "improvements": ["Streamlined implementation", "Resource optimization"],
                "feasibility": 0.9,
                "estimated_effort": "medium"
            },
            PersonalityType.LOGICAL_ANALYST: {
                "improvements": ["Logical framework", "Systematic approach"],
                "feasibility": 0.85,
                "estimated_effort": "low"
            }
        }

        refinement = refinements.get(worker.personality, {
            "improvements": ["General improvements"],
            "feasibility": 0.8,
            "estimated_effort": "medium"
        })

        return {
            "option": option,
            "refiner": worker.agent_id,
            "refinements": refinement["improvements"],
            "improved_validity": min(1.0, avg_validity + 0.1),
            "feasibility": refinement["feasibility"],
            "effort": refinement["estimated_effort"]
        }

    async def _consensus_phase(self, refinement_results: Dict[str, Any], options: List[str]) -> Dict[str, Any]:
        """Consensus phase - Queen coordinates final decision"""
        logger.info("👑 Swarm consensus phase...")

        queen = next((agent for agent in self.agents.values() if agent.role == SwarmRole.QUEEN), None)
        if not queen:
            return {"chosen_option": options[0], "votes": {}}

        # Queen analyzes all refinements
        option_scores = {}

        for option in options:
            if option in refinement_results:
                refinements = refinement_results[option]

                # Calculate composite score
                validity_scores = [r["improved_validity"] for r in refinements]
                feasibility_scores = [r["feasibility"] for r in refinements]

                avg_validity = statistics.mean(validity_scores) if validity_scores else 0.5
                avg_feasibility = statistics.mean(feasibility_scores) if feasibility_scores else 0.5

                option_scores[option] = (avg_validity + avg_feasibility) / 2
            else:
                option_scores[option] = 0.5

        # Queen makes final decision
        best_option = max(option_scores.keys(), key=lambda x: option_scores[x])

        # Record votes (simplified)
        votes = {}
        for option in options:
            # Simulate agent votes based on scores
            score = option_scores[option]
            vote_count = int(score * len(self.agents) * 0.1)
            votes[option] = [f"agent_{i}" for i in range(vote_count)]

        queen.contribute({"type": "consensus", "option": best_option, "value": 0.3})

        return {
            "chosen_option": best_option,
            "votes": votes,
            "option_scores": option_scores,
            "queen_decision": queen.agent_id
        }

    def _calculate_swarm_confidence(self, decision_result: Dict[str, Any]) -> float:
        """Calculate overall swarm confidence in the decision"""
        option_scores = decision_result.get("option_scores", {})
        chosen_option = decision_result.get("chosen_option", "")

        if chosen_option in option_scores:
            base_confidence = option_scores[chosen_option]
        else:
            base_confidence = 0.5

        # Factor in swarm cohesion and collective IQ
        swarm_factor = (self.cohesion_level + self.collective_iq) / 2

        return min(1.0, base_confidence * swarm_factor)

    def _extract_emergent_insights(self, decision_result: Dict[str, Any]) -> List[str]:
        """Extract emergent insights from the swarm decision process"""
        insights = []

        # Look for patterns in the decision process
        option_scores = decision_result.get("option_scores", {})

        if len(option_scores) > 1:
            scores = list(option_scores.values())
            if statistics.stdev(scores) > 0.3:
                insights.append("Clear winner emerged from diverse options")
            else:
                insights.append("Multiple strong options identified")

        # Check for unusual patterns
        if self.emergence_factor > 0.8:
            insights.append("Emergent intelligence patterns detected")

        return insights if insights else ["Standard decision process"]

    def _update_swarm_learning(self, decision: SwarmDecision):
        """Update swarm learning based on decision outcomes"""
        # Update collective IQ based on decision quality
        if decision.confidence > 0.8:
            self.collective_iq = min(2.0, self.collective_iq + 0.05)
        elif decision.confidence < 0.4:
            self.collective_iq = max(0.5, self.collective_iq - 0.02)

        # Update emergence factor
        if decision.emergent_insights:
            self.emergence_factor = min(1.0, self.emergence_factor + 0.1)
        else:
            self.emergence_factor = max(0.0, self.emergence_factor - 0.05)

        # Update cohesion based on voting patterns
        votes = decision.swarm_votes
        total_votes = sum(len(agent_list) for agent_list in votes.values())
        if total_votes > 0:
            concentration = max(len(agent_list) for agent_list in votes.values()) / total_votes
            self.cohesion_level = min(1.0, self.cohesion_level + (1 - concentration) * 0.1)

    def release_pheromone_signal(self, signal: PheromoneSignal):
        """Release a pheromone-like signal to the swarm"""
        self.pheromone_signals.append(signal)

        # Propagate to relevant agents
        for agent_id in signal.target_agents:
            if agent_id in self.agents:
                agent = self.agents[agent_id]
                # Agent responds to signal (simplified)
                agent.contribute({"type": "signal_response", "signal": signal.signal_type, "value": 0.05})

    def get_swarm_status(self) -> Dict[str, Any]:
        """Get current swarm status"""
        role_counts = {}
        for agent in self.agents.values():
            role = agent.role.value
            role_counts[role] = role_counts.get(role, 0) + 1

        return {
            "swarm_size": len(self.agents),
            "swarm_state": self.swarm_state.value,
            "role_distribution": role_counts,
            "collective_iq": self.collective_iq,
            "emergence_factor": self.emergence_factor,
            "cohesion_level": self.cohesion_level,
            "active_pheromone_signals": len([s for s in self.pheromone_signals if s.get_current_strength() > 0.1]),
            "decision_history_count": len(self.decision_history)
        }

    def get_top_contributors(self, limit: int = 5) -> List[Dict[str, Any]]:
        """Get top contributing agents"""
        sorted_agents = sorted(
            self.agents.values(),
            key=lambda a: a.contribution_score,
            reverse=True
        )

        return [{
            "agent_id": agent.agent_id,
            "role": agent.role.value,
            "personality": agent.personality.value,
            "contribution_score": agent.contribution_score,
            "energy_level": agent.energy_level
        } for agent in sorted_agents[:limit]]

class HiveMindCoordinator:
    """Coordinates the overall hive mind across multiple swarm instances"""

    def __init__(self):
        self.swarms: Dict[str, SwarmCoordinator] = {}
        self.hive_state = "forming"
        self.global_insights: List[Dict[str, Any]] = []

        # Create initial swarms for different domains
        self._initialize_domain_swarms()

    def _initialize_domain_swarms(self):
        """Initialize swarms for different problem domains"""
        domains = {
            "coding": 30,      # Smaller swarm for focused coding tasks
            "creative": 40,    # Larger swarm for creative exploration
            "analytical": 35,  # Medium swarm for analytical reasoning
            "social": 25       # Smaller swarm for social intelligence
        }

        for domain, size in domains.items():
            swarm = SwarmCoordinator(size)
            self.swarms[domain] = swarm

        self.hive_state = "active"
        logger.info(f"🐝 Hive Mind initialized with {len(self.swarms)} domain swarms")

    async def process_hive_decision(self, problem: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Process a decision through the entire hive mind"""
        context = context or {}
        domain = context.get("domain", "general")

        # Map domain to appropriate swarm
        swarm_key = self._map_domain_to_swarm(domain)

        if swarm_key not in self.swarms:
            swarm_key = "coding"  # Default fallback

        swarm = self.swarms[swarm_key]

        # Generate options based on problem
        options = self._generate_hive_options(problem, context)

        # Process through swarm
        decision = await swarm.process_swarm_decision(problem, options)

        # Extract hive-level insights
        hive_insights = self._extract_hive_insights(decision, domain)

        # Update global learning
        self._update_global_learning(decision, domain)

        return {
            "hive_decision": decision,
            "domain": domain,
            "swarm_used": swarm_key,
            "hive_insights": hive_insights,
            "global_learning": len(self.global_insights)
        }

    def _map_domain_to_swarm(self, domain: str) -> str:
        """Map problem domain to appropriate swarm"""
        domain_mapping = {
            "coding": "coding",
            "programming": "coding",
            "development": "coding",
            "creative": "creative",
            "design": "creative",
            "artistic": "creative",
            "analysis": "analytical",
            "research": "analytical",
            "logic": "analytical",
            "social": "social",
            "relationship": "social",
            "communication": "social"
        }

        return domain_mapping.get(domain.lower(), "coding")

    def _generate_hive_options(self, problem: str, context: Dict[str, Any]) -> List[str]:
        """Generate decision options for the hive"""
        # Base options that work across domains
        base_options = [
            "Direct approach with immediate implementation",
            "Research and analysis before action",
            "Collaborative solution with multiple perspectives",
            "Iterative approach with continuous improvement",
            "Innovative solution challenging assumptions",
            "Conservative approach minimizing risk",
            "Balanced solution considering all factors"
        ]

        # Add domain-specific options
        domain = context.get("domain", "general")
        if domain == "coding":
            base_options.extend([
                "Use established frameworks and libraries",
                "Build custom solution from scratch",
                "Combine existing tools in novel ways"
            ])
        elif domain == "creative":
            base_options.extend([
                "Break conventional boundaries",
                "Draw inspiration from diverse sources",
                "Focus on emotional impact and resonance"
            ])

        return base_options[:10]  # Limit to 10 options

    def _extract_hive_insights(self, decision: SwarmDecision, domain: str) -> List[str]:
        """Extract insights at the hive mind level"""
        insights = []

        # Analyze decision patterns
        if decision.confidence > 0.8:
            insights.append(f"High confidence in {domain} domain suggests strong swarm alignment")

        if len(decision.emergent_insights) > 2:
            insights.append("Multiple emergent insights indicate rich swarm intelligence")

        # Check for cross-domain learning opportunities
        related_domains = self._find_related_domains(domain)
        if related_domains:
            insights.append(f"Consider insights from related domains: {', '.join(related_domains)}")

        return insights

    def _find_related_domains(self, domain: str) -> List[str]:
        """Find domains related to the current one"""
        domain_relations = {
            "coding": ["analytical", "creative"],
            "creative": ["coding", "social"],
            "analytical": ["coding", "creative"],
            "social": ["creative", "analytical"]
        }

        return domain_relations.get(domain, [])

    def _update_global_learning(self, decision: SwarmDecision, domain: str):
        """Update global hive learning"""
        learning_entry = {
            "timestamp": time.time(),
            "domain": domain,
            "decision_quality": decision.confidence,
            "emergent_insights": len(decision.emergent_insights),
            "swarm_size": decision.swarm_size,
            "decision_time": decision.decision_time
        }

        self.global_insights.append(learning_entry)

        # Keep learning history manageable
        if len(self.global_insights) > 1000:
            self.global_insights = self.global_insights[-500:]

    def get_hive_status(self) -> Dict[str, Any]:
        """Get overall hive mind status"""
        swarm_statuses = {}
        for domain, swarm in self.swarms.items():
            swarm_statuses[domain] = swarm.get_swarm_status()

        return {
            "hive_state": self.hive_state,
            "active_swarms": len(self.swarms),
            "total_agents": sum(s["swarm_size"] for s in swarm_statuses.values()),
            "swarm_statuses": swarm_statuses,
            "global_learning_entries": len(self.global_insights),
            "average_collective_iq": statistics.mean(s["collective_iq"] for s in swarm_statuses.values())
        }

# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def get_swarm_coordinator(domain: str = "coding") -> SwarmCoordinator:
    """Get a swarm coordinator for a specific domain"""
    global _swarm_coordinators
    if domain not in _swarm_coordinators:
        size = 30 if domain == "coding" else 40  # Default sizes
        _swarm_coordinators[domain] = SwarmCoordinator(size)

    return _swarm_coordinators[domain]

def get_hive_mind() -> HiveMindCoordinator:
    """Get the global hive mind coordinator"""
    global _hive_mind
    if _hive_mind is None:
        _hive_mind = HiveMindCoordinator()
    return _hive_mind

# Global instances
_swarm_coordinators: Dict[str, SwarmCoordinator] = {}
_hive_mind: Optional[HiveMindCoordinator] = None

async def demonstrate_hive_intelligence():
    """Demonstrate the hive intelligence system"""
    print("🐝 Hive Intelligence Demonstration")
    print("=" * 50)

    # Get hive mind
    hive = get_hive_mind()

    # Test problems
    test_cases = [
        {
            "problem": "How should I optimize this Python sorting algorithm?",
            "context": {"domain": "coding", "urgency": 0.7}
        },
        {
            "problem": "Design an innovative user interface for a productivity app",
            "context": {"domain": "creative", "urgency": 0.8}
        },
        {
            "problem": "What are the risks of implementing AI in hiring decisions?",
            "context": {"domain": "analytical", "urgency": 0.6}
        }
    ]

    for i, test_case in enumerate(test_cases, 1):
        print(f"\n🔬 Test Case {i}: {test_case['problem'][:50]}...")
        print(f"Domain: {test_case['context']['domain']}")

        start_time = time.time()
        result = await hive.process_hive_decision(
            test_case["problem"],
            test_case["context"]
        )

        decision_time = time.time() - start_time
        decision = result["hive_decision"]

        print("   📊 Results:")
        print(".2f"        print(".2f"        print(f"   🎯 Decision: {decision.consensus_option[:60]}...")
        print(f"   🐝 Swarm Size: {decision.swarm_size}")
        print(f"   💡 Emergent Insights: {len(decision.emergent_insights)}")

        await asyncio.sleep(1)  # Brief pause between tests

    # Final status
    status = hive.get_hive_status()
    print("
🌟 Final Hive Status:"    print(f"   🐝 Active Swarms: {status['active_swarms']}")
    print(f"   🤖 Total Agents: {status['total_agents']}")
    print(".2f"    print(f"   📚 Learning Entries: {status['global_learning_entries']}")

    print("\n✅ Hive Intelligence demonstration complete!")

if __name__ == "__main__":
    asyncio.run(demonstrate_hive_intelligence())
