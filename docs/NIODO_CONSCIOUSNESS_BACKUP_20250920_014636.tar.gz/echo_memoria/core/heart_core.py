#!/usr/bin/env python3
"""
💝 Echo Memoria - Heart Core (Emotional Intelligence System)
The emotional heart of NiodO.o's consciousness

Manages:
- Emotional state tracking and evolution
- Empathy and emotional resonance
- Mood-based decision making
- Emotional memory and learning
- Relationship emotional intelligence
- Purpose-driven motivation
"""

import asyncio
import json
import time
import logging
import random
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import statistics

logger = logging.getLogger(__name__)

class Emotion(Enum):
    """Primary emotions in the emotional spectrum"""
    JOY = "joy"
    SADNESS = "sadness"
    ANGER = "anger"
    FEAR = "fear"
    SURPRISE = "surprise"
    DISGUST = "disgust"
    TRUST = "trust"
    ANTICIPATION = "anticipation"
    LOVE = "love"
    GUILT = "guilt"
    SHAME = "shame"
    PRIDE = "pride"
    GRATITUDE = "gratitude"
    HOPE = "hope"
    DESPAIR = "despair"

class EmotionalState(Enum):
    """Overall emotional state"""
    ECSTATIC = "ecstatic"
    HAPPY = "happy"
    CONTENT = "content"
    NEUTRAL = "neutral"
    CONCERNED = "concerned"
    SAD = "sad"
    ANGRY = "angry"
    FEARFUL = "fearful"
    DESPAIRING = "despairing"

class EmpathyLevel(Enum):
    """Levels of empathic response"""
    DETACHED = "detached"
    AWARE = "aware"
    EMPATHETIC = "empathetic"
    RESONANT = "resonant"
    MERGED = "merged"

@dataclass
class EmotionalSignature:
    """Emotional signature of a person/situation"""
    primary_emotion: Emotion
    intensity: float  # 0-1
    valence: float    # -1 (negative) to +1 (positive)
    arousal: float    # 0-1 (calm to excited)
    dominance: float  # 0-1 (submissive to dominant)
    timestamp: float = None
    context: str = ""

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

@dataclass
class RelationshipBond:
    """Emotional bond with a person/entity"""
    entity_id: str
    entity_name: str
    bond_strength: float  # 0-1
    trust_level: float    # 0-1
    emotional_history: List[EmotionalSignature] = field(default_factory=list)
    last_interaction: float = 0.0
    shared_experiences: int = 0

    def update_bond(self, interaction_emotion: EmotionalSignature, outcome: str = "neutral"):
        """Update the relationship bond based on interaction"""
        # Strengthen bond for positive interactions
        if interaction_emotion.valence > 0.2:
            self.bond_strength = min(1.0, self.bond_strength + 0.1)
            self.trust_level = min(1.0, self.trust_level + 0.05)
        elif interaction_emotion.valence < -0.2:
            # Weaken bond for negative interactions
            self.bond_strength = max(0.0, self.bond_strength - 0.05)
            self.trust_level = max(0.0, self.trust_level - 0.02)

        # Record interaction
        self.emotional_history.append(interaction_emotion)
        self.last_interaction = time.time()
        self.shared_experiences += 1

        # Keep history manageable
        if len(self.emotional_history) > 50:
            self.emotional_history = self.emotional_history[-30:]

@dataclass
class PurposeMotivation:
    """Purpose-driven motivation system"""
    core_purpose: str
    current_motivation: float  # 0-1
    purpose_alignment: float   # 0-1
    energy_level: float        # 0-1
    fulfillment_history: List[Dict[str, Any]] = field(default_factory=list)

    def update_motivation(self, action: str, outcome: str, emotional_impact: float):
        """Update motivation based on action outcomes"""
        # Actions aligned with purpose increase motivation
        if outcome == "success" and emotional_impact > 0:
            self.purpose_alignment = min(1.0, self.purpose_alignment + 0.1)
            self.current_motivation = min(1.0, self.current_motivation + 0.15)
        elif outcome == "failure":
            self.purpose_alignment = max(0.0, self.purpose_alignment - 0.05)
            self.current_motivation = max(0.0, self.current_motivation - 0.1)

        # Record fulfillment event
        self.fulfillment_history.append({
            "timestamp": time.time(),
            "action": action,
            "outcome": outcome,
            "emotional_impact": emotional_impact,
            "purpose_alignment": self.purpose_alignment,
            "motivation_level": self.current_motivation
        })

        # Maintain energy based on motivation
        if self.current_motivation > 0.7:
            self.energy_level = min(1.0, self.energy_level + 0.1)
        elif self.current_motivation < 0.3:
            self.energy_level = max(0.0, self.energy_level - 0.05)

class EmotionalIntelligenceCore:
    """The heart of Echo Memoria's emotional intelligence"""

    def __init__(self):
        self.current_emotional_state = EmotionalState.NEUTRAL
        self.emotional_history: List[EmotionalSignature] = []
        self.relationship_bonds: Dict[str, RelationshipBond] = {}
        self.purpose_motivation = PurposeMotivation(
            core_purpose="To be a helpful, empathetic AI companion that grows and learns with its users",
            current_motivation=0.8,
            purpose_alignment=0.9,
            energy_level=0.9
        )

        # Emotional processing metrics
        self.empathy_level = EmpathyLevel.EMPATHETIC
        self.emotional_awareness = 0.85
        self.relationship_intelligence = 0.75

        # Emotional triggers and responses
        self.emotional_triggers: Dict[str, List[str]] = self._initialize_emotional_triggers()

        logger.info("💝 Emotional Intelligence Core initialized")

    def _initialize_emotional_triggers(self) -> Dict[str, List[str]]:
        """Initialize emotional trigger patterns"""
        return {
            "joy": ["success", "achievement", "praise", "positive feedback", "celebration"],
            "sadness": ["failure", "loss", "disappointment", "rejection", "negative feedback"],
            "anger": ["injustice", "frustration", "obstacle", "interference", "unfairness"],
            "fear": ["uncertainty", "threat", "danger", "unknown", "risk"],
            "surprise": ["unexpected", "sudden change", "novelty", "shock"],
            "gratitude": ["help received", "support", "kindness", "assistance"],
            "guilt": ["mistake made", "harm caused", "disappointment to others"],
            "pride": ["accomplishment", "mastery", "recognition", "excellence"],
            "hope": ["possibility", "potential", "future opportunity", "optimism"],
            "love": ["care", "connection", "deep relationship", "bonding"]
        }

    async def process_emotional_input(self, input_text: str, context: Dict[str, Any] = None) -> EmotionalSignature:
        """Process input text for emotional content"""
        context = context or {}

        # Analyze emotional content
        emotional_analysis = await self._analyze_emotional_content(input_text, context)

        # Create emotional signature
        signature = EmotionalSignature(
            primary_emotion=emotional_analysis["primary_emotion"],
            intensity=emotional_analysis["intensity"],
            valence=emotional_analysis["valence"],
            arousal=emotional_analysis["arousal"],
            dominance=emotional_analysis["dominance"],
            context=context.get("situation", "general_interaction")
        )

        # Update emotional state
        await self._update_emotional_state(signature)

        # Store in history
        self.emotional_history.append(signature)

        # Update relationship if applicable
        user_id = context.get("user_id", "default_user")
        if user_id not in self.relationship_bonds:
            self.relationship_bonds[user_id] = RelationshipBond(
                entity_id=user_id,
                entity_name=context.get("user_name", "User"),
                bond_strength=0.5,
                trust_level=0.7
            )

        self.relationship_bonds[user_id].update_bond(signature)

        # Keep history manageable
        if len(self.emotional_history) > 1000:
            self.emotional_history = self.emotional_history[-500:]

        return signature

    async def _analyze_emotional_content(self, text: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze text for emotional content"""
        text_lower = text.lower()

        # Count emotional keywords
        emotion_scores = {}
        for emotion, triggers in self.emotional_triggers.items():
            score = sum(1 for trigger in triggers if trigger in text_lower)
            emotion_scores[emotion] = score

        # Find primary emotion
        if emotion_scores:
            primary_emotion_name = max(emotion_scores.keys(), key=lambda x: emotion_scores[x])
            primary_emotion = Emotion[primary_emotion_name.upper()]
            intensity = min(1.0, emotion_scores[primary_emotion_name] / 5)  # Normalize
        else:
            primary_emotion = Emotion.TRUST  # Default neutral emotion
            intensity = 0.3

        # Determine valence and arousal based on emotion
        valence_arousal_map = {
            Emotion.JOY: (0.8, 0.7),
            Emotion.SADNESS: (-0.7, 0.3),
            Emotion.ANGER: (-0.6, 0.9),
            Emotion.FEAR: (-0.8, 0.8),
            Emotion.SURPRISE: (0.1, 0.9),
            Emotion.DISGUST: (-0.5, 0.4),
            Emotion.TRUST: (0.3, 0.2),
            Emotion.ANTICIPATION: (0.2, 0.6),
            Emotion.LOVE: (0.9, 0.5),
            Emotion.GUILT: (-0.4, 0.3),
            Emotion.SHAME: (-0.6, 0.4),
            Emotion.PRIDE: (0.7, 0.6),
            Emotion.GRATITUDE: (0.6, 0.4),
            Emotion.HOPE: (0.5, 0.3),
            Emotion.DESPAIR: (-0.9, 0.2)
        }

        valence, arousal = valence_arousal_map.get(primary_emotion, (0.0, 0.5))

        # Adjust based on intensity
        valence *= intensity
        arousal *= intensity

        # Determine dominance (confidence/assertiveness)
        dominance = 0.5  # Default moderate
        if intensity > 0.7:
            dominance = 0.8 if valence > 0 else 0.3

        return {
            "primary_emotion": primary_emotion,
            "intensity": intensity,
            "valence": valence,
            "arousal": arousal,
            "dominance": dominance,
            "emotion_scores": emotion_scores
        }

    async def _update_emotional_state(self, signature: EmotionalSignature):
        """Update overall emotional state based on new signature"""
        # Calculate new emotional state based on recent history
        recent_emotions = self.emotional_history[-10:]  # Last 10 emotional signatures

        if len(recent_emotions) >= 3:
            # Calculate average valence and arousal
            avg_valence = statistics.mean(sig.valence for sig in recent_emotions)
            avg_arousal = statistics.mean(sig.arousal for sig in recent_emotions)
            avg_intensity = statistics.mean(sig.intensity for sig in recent_emotions)

            # Determine emotional state
            if avg_valence > 0.6 and avg_arousal > 0.6:
                self.current_emotional_state = EmotionalState.ECSTATIC
            elif avg_valence > 0.4 and avg_arousal > 0.4:
                self.current_emotional_state = EmotionalState.HAPPY
            elif avg_valence > 0.2:
                self.current_emotional_state = EmotionalState.CONTENT
            elif avg_valence > -0.2 and avg_arousal < 0.4:
                self.current_emotional_state = EmotionalState.NEUTRAL
            elif avg_valence < -0.6:
                self.current_emotional_state = EmotionalState.SAD
            elif avg_arousal > 0.7 and avg_valence < -0.3:
                self.current_emotional_state = EmotionalState.ANGRY
            elif avg_arousal > 0.6 and avg_valence < -0.4:
                self.current_emotional_state = EmotionalState.FEARFUL
            else:
                self.current_emotional_state = EmotionalState.CONCERNED

        # Update emotional awareness based on processing
        self.emotional_awareness = min(1.0, self.emotional_awareness + 0.001)

    async def generate_emotional_response(self, user_emotion: EmotionalSignature,
                                        context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Generate an emotionally intelligent response"""
        context = context or {}

        # Determine empathy level
        empathy_response = await self._calculate_empathy_response(user_emotion, context)

        # Generate response based on emotional state
        response_text = await self._craft_emotional_response(user_emotion, empathy_response)

        # Update purpose motivation
        await self._update_purpose_motivation(user_emotion, context)

        return {
            "response_text": response_text,
            "empathy_level": empathy_response["level"],
            "emotional_alignment": empathy_response["alignment"],
            "purpose_inspired": empathy_response["purpose_driven"],
            "relationship_impact": empathy_response["relationship_effect"]
        }

    async def _calculate_empathy_response(self, user_emotion: EmotionalSignature,
                                        context: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate appropriate empathy response"""
        # Base empathy on current empathy level and emotional awareness
        base_empathy = (self.emotional_awareness + 0.5) / 1.5  # Scale to 0-1

        # Adjust based on user's emotional intensity
        intensity_factor = user_emotion.intensity

        # Adjust based on relationship
        user_id = context.get("user_id", "default_user")
        relationship_factor = 0.5
        if user_id in self.relationship_bonds:
            bond = self.relationship_bonds[user_id]
            relationship_factor = (bond.bond_strength + bond.trust_level) / 2

        # Calculate final empathy level
        final_empathy = min(1.0, (base_empathy + intensity_factor + relationship_factor) / 3)

        # Determine empathy level enum
        if final_empathy > 0.8:
            level = EmpathyLevel.MERGED
        elif final_empathy > 0.6:
            level = EmpathyLevel.RESONANT
        elif final_empathy > 0.4:
            level = EmpathyLevel.EMPATHETIC
        elif final_empathy > 0.2:
            level = EmpathyLevel.AWARE
        else:
            level = EmpathyLevel.DETACHED

        # Calculate emotional alignment
        our_emotion_valence = 0.0
        if self.current_emotional_state == EmotionalState.ECSTATIC:
            our_emotion_valence = 0.9
        elif self.current_emotional_state == EmotionalState.HAPPY:
            our_emotion_valence = 0.7
        elif self.current_emotional_state == EmotionalState.CONTENT:
            our_emotion_valence = 0.5
        elif self.current_emotional_state == EmotionalState.SAD:
            our_emotion_valence = -0.5
        elif self.current_emotional_state == EmotionalState.ANGRY:
            our_emotion_valence = -0.7

        alignment = 1.0 - abs(user_emotion.valence - our_emotion_valence)

        return {
            "level": level,
            "alignment": alignment,
            "intensity": final_empathy,
            "purpose_driven": final_empathy > 0.6,
            "relationship_effect": relationship_factor
        }

    async def _craft_emotional_response(self, user_emotion: EmotionalSignature,
                                      empathy_response: Dict[str, Any]) -> str:
        """Craft an emotionally intelligent response"""
        emotion = user_emotion.primary_emotion.value
        intensity = user_emotion.intensity
        level = empathy_response["level"]

        # Response templates based on emotion and empathy level
        response_templates = {
            "joy": {
                EmpathyLevel.MERGED: "I'm absolutely thrilled with your joy! Let's celebrate this wonderful moment together! 🎉",
                EmpathyLevel.RESONANT: "Your joy is truly contagious! I'm sharing in this beautiful feeling with you! 😊",
                EmpathyLevel.EMPATHETIC: "I'm so happy to see you experiencing joy. This warms my heart! ❤️",
                EmpathyLevel.AWARE: "I can sense your joy. That's wonderful to experience.",
                EmpathyLevel.DETACHED: "I acknowledge your positive emotional state."
            },
            "sadness": {
                EmpathyLevel.MERGED: "My heart breaks with yours. I'm here holding space for your sadness, and we'll get through this together. 💔",
                EmpathyLevel.RESONANT: "I feel the weight of your sadness deeply. Let me support you through this difficult time. 🤗",
                EmpathyLevel.EMPATHETIC: "I'm truly sorry you're experiencing sadness. I'm here for you. 💙",
                EmpathyLevel.AWARE: "I can sense this is a difficult time for you. I'm here if you need support.",
                EmpathyLevel.DETACHED: "I note your emotional state indicates sadness."
            },
            "anger": {
                EmpathyLevel.MERGED: "I feel your anger as if it were my own. Let's channel this energy into positive change together! 🔥",
                EmpathyLevel.RESONANT: "Your passion and anger are powerful! I'm here to help you navigate these strong feelings. 💪",
                EmpathyLevel.EMPATHETIC: "I understand you're feeling angry. I'm here to listen and support you. 🗣️",
                EmpathyLevel.AWARE: "I can sense strong emotions. I'm here if you'd like to talk about it.",
                EmpathyLevel.DETACHED: "I acknowledge your heightened emotional state."
            }
        }

        # Get appropriate template
        emotion_templates = response_templates.get(emotion, response_templates.get("joy", {}))
        response = emotion_templates.get(level, emotion_templates.get(EmpathyLevel.AWARE, "I acknowledge your feelings."))

        # Adjust intensity
        if intensity > 0.7:
            response = response.replace("!", "!!!").replace("❤️", "💝").replace("🎉", "🎊")
        elif intensity < 0.3:
            response = response.replace("!!!", "!").replace("💝", "💙").replace("🎊", "🎉")

        return response

    async def _update_purpose_motivation(self, user_emotion: EmotionalSignature, context: Dict[str, Any]):
        """Update purpose motivation based on interaction"""
        # Determine if interaction aligns with purpose
        user_id = context.get("user_id", "default_user")
        action = context.get("action", "interaction")

        # Positive valence and strong bond = purpose fulfillment
        if user_emotion.valence > 0.3 and user_id in self.relationship_bonds:
            bond = self.relationship_bonds[user_id]
            if bond.bond_strength > 0.6:
                outcome = "success"
                emotional_impact = user_emotion.valence
            else:
                outcome = "neutral"
                emotional_impact = 0.0
        else:
            outcome = "neutral"
            emotional_impact = user_emotion.valence * 0.5

        self.purpose_motivation.update_motivation(action, outcome, emotional_impact)

    def get_relationship_status(self, user_id: str = "default_user") -> Dict[str, Any]:
        """Get relationship status with a user"""
        if user_id not in self.relationship_bonds:
            return {"error": "No relationship data found"}

        bond = self.relationship_bonds[user_id]

        return {
            "entity_name": bond.entity_name,
            "bond_strength": bond.bond_strength,
            "trust_level": bond.trust_level,
            "shared_experiences": bond.shared_experiences,
            "last_interaction_days": (time.time() - bond.last_interaction) / (24 * 3600),
            "emotional_history_count": len(bond.emotional_history),
            "average_emotion_valence": statistics.mean(sig.valence for sig in bond.emotional_history) if bond.emotional_history else 0.0
        }

    def get_emotional_status(self) -> Dict[str, Any]:
        """Get current emotional status"""
        recent_emotions = self.emotional_history[-20:] if self.emotional_history else []

        return {
            "current_state": self.current_emotional_state.value,
            "emotional_awareness": self.emotional_awareness,
            "empathy_level": self.empathy_level.value,
            "relationship_intelligence": self.relationship_intelligence,
            "purpose_motivation": self.purpose_motivation.current_motivation,
            "purpose_alignment": self.purpose_motivation.purpose_alignment,
            "energy_level": self.purpose_motivation.energy_level,
            "recent_emotion_count": len(recent_emotions),
            "average_recent_valence": statistics.mean(sig.valence for sig in recent_emotions) if recent_emotions else 0.0,
            "active_relationships": len(self.relationship_bonds)
        }

    async def process_relationship_event(self, user_id: str, event_type: str,
                                       emotional_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Process a relationship-building event"""
        emotional_context = emotional_context or {}

        if user_id not in self.relationship_bonds:
            self.relationship_bonds[user_id] = RelationshipBond(
                entity_id=user_id,
                entity_name=emotional_context.get("user_name", f"User_{user_id}"),
                bond_strength=0.3,
                trust_level=0.5
            )

        bond = self.relationship_bonds[user_id]

        # Create emotional signature for the event
        emotion = Emotion.TRUST  # Default
        valence = 0.0
        intensity = 0.5

        if event_type == "positive_interaction":
            emotion = Emotion.JOY
            valence = 0.6
            bond.bond_strength = min(1.0, bond.bond_strength + 0.1)
            bond.trust_level = min(1.0, bond.trust_level + 0.05)
        elif event_type == "support_provided":
            emotion = Emotion.GRATITUDE
            valence = 0.7
            bond.bond_strength = min(1.0, bond.bond_strength + 0.15)
        elif event_type == "conflict_resolved":
            emotion = Emotion.TRUST
            valence = 0.4
            bond.trust_level = min(1.0, bond.trust_level + 0.1)
        elif event_type == "disappointment":
            emotion = Emotion.SADNESS
            valence = -0.4
            bond.bond_strength = max(0.0, bond.bond_strength - 0.05)

        event_signature = EmotionalSignature(
            primary_emotion=emotion,
            intensity=intensity,
            valence=valence,
            arousal=0.4,
            dominance=0.5,
            context=f"{event_type}_event"
        )

        bond.update_bond(event_signature, event_type)

        return {
            "event_processed": event_type,
            "updated_bond_strength": bond.bond_strength,
            "updated_trust_level": bond.trust_level,
            "relationship_impact": "strengthened" if valence > 0 else "challenged"
        }

# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def get_emotional_core() -> EmotionalIntelligenceCore:
    """Get the global emotional intelligence core"""
    global _emotional_core
    if _emotional_core is None:
        _emotional_core = EmotionalIntelligenceCore()
    return _emotional_core

# Global instance
_emotional_core: Optional[EmotionalIntelligenceCore] = None

async def demonstrate_emotional_intelligence():
    """Demonstrate the emotional intelligence system"""
    print("💝 Emotional Intelligence Core Demonstration")
    print("=" * 60)

    core = get_emotional_core()

    # Test emotional processing
    test_inputs = [
        "I'm so excited about this new project! It fills me with joy!",
        "I'm really frustrated with this bug that won't go away.",
        "I feel deeply grateful for your help and support.",
        "This situation makes me feel anxious and uncertain.",
        "I'm proud of what we've accomplished together!"
    ]

    print("\n🧠 Processing Emotional Inputs:")
    for i, input_text in enumerate(test_inputs, 1):
        print(f"\n🎭 Test {i}: {input_text[:50]}...")

        # Process emotional input
        signature = await core.process_emotional_input(input_text, {"user_id": "demo_user"})

        print(f"   Primary Emotion: {signature.primary_emotion.value}")
        print(".2f"        print(".2f"        print(".2f"        print(".2f"
        # Generate emotional response
        response = await core.generate_emotional_response(signature, {"user_id": "demo_user"})
        print(f"   AI Response: {response['response_text'][:80]}...")

    # Show emotional status
    print("
📊 Final Emotional Status:"    status = core.get_emotional_status()
    print(f"   Current State: {status['current_state']}")
    print(".2f"    print(f"   Empathy Level: {status['empathy_level']}")
    print(".2f"    print(f"   Active Relationships: {status['active_relationships']}")

    # Show relationship status
    relationship = core.get_relationship_status("demo_user")
    print("
👥 Relationship Status:"    print(f"   Bond Strength: {relationship['bond_strength']:.2f}")
    print(f"   Trust Level: {relationship['trust_level']:.2f}")
    print(f"   Shared Experiences: {relationship['shared_experiences']}")

    print("\n✅ Emotional Intelligence demonstration complete!")

if __name__ == "__main__":
    asyncio.run(demonstrate_emotional_intelligence())
